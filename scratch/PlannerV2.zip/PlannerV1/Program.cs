using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace PlannerV1
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    class ProjectData
    {
        public string ProjectName { get; set; } = "";
        public List<string> Phases { get; set; } = new List<string>();
    }

    class MainForm : Form
    {
        private TextBox _txtProjectName;
        private TextBox _txtPhase;
        private ListBox _lstPhases;
        private Button _btnAddPhase;
        private Button _btnRemovePhase;
        private Button _btnSave;
        private Button _btnLoad;
        private Button _btnExportHtml;

        public MainForm()
        {
            Text = "Project Planner";
            Size = new System.Drawing.Size(420, 480);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            // Project Name
            var lblName = new Label { Text = "Project Name:", Left = 16, Top = 16, Width = 120 };
            _txtProjectName = new TextBox { Left = 16, Top = 36, Width = 370 };

            // Phases
            var lblPhases = new Label { Text = "Phases:", Left = 16, Top = 76, Width = 120 };
            _txtPhase = new TextBox { Left = 16, Top = 96, Width = 280 };
            _txtPhase.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) BtnAddPhase_Click(s, e); };

            _btnAddPhase = new Button { Text = "Add", Left = 304, Top = 94, Width = 82 };
            _btnAddPhase.Click += BtnAddPhase_Click;

            _lstPhases = new ListBox { Left = 16, Top = 130, Width = 370, Height = 180 };

            // Row 1 buttons: Remove / Save
            _btnRemovePhase = new Button { Text = "Remove Selected", Left = 16, Top = 322, Width = 150 };
            _btnRemovePhase.Click += BtnRemovePhase_Click;

            _btnSave = new Button { Text = "Save JSON", Left = 286, Top = 322, Width = 100 };
            _btnSave.Click += BtnSave_Click;

            // Row 2 buttons: Load / Export HTML
            _btnLoad = new Button { Text = "Load JSON", Left = 16, Top = 364, Width = 100 };
            _btnLoad.Click += BtnLoad_Click;

            _btnExportHtml = new Button { Text = "Export to HTML", Left = 236, Top = 364, Width = 150 };
            _btnExportHtml.Click += BtnExportHtml_Click;

            Controls.AddRange(new Control[] {
                lblName, _txtProjectName,
                lblPhases, _txtPhase, _btnAddPhase,
                _lstPhases,
                _btnRemovePhase, _btnSave,
                _btnLoad, _btnExportHtml
            });
        }

        private void BtnAddPhase_Click(object sender, EventArgs e)
        {
            string phase = _txtPhase.Text.Trim();
            if (string.IsNullOrEmpty(phase)) return;
            _lstPhases.Items.Add(phase);
            _txtPhase.Clear();
            _txtPhase.Focus();
        }

        private void BtnRemovePhase_Click(object sender, EventArgs e)
        {
            if (_lstPhases.SelectedIndex >= 0)
                _lstPhases.Items.RemoveAt(_lstPhases.SelectedIndex);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtProjectName.Text))
            {
                MessageBox.Show("Please enter a project name.", "Missing Name");
                return;
            }

            var data = BuildProjectData();
            var dlg = new SaveFileDialog
            {
                Filter = "JSON files|*.json",
                FileName = data.ProjectName + ".json"
            };

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(dlg.FileName, json);
                MessageBox.Show("Saved successfully!", "Done");
            }
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "JSON files|*.json" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                var json = File.ReadAllText(dlg.FileName);
                var data = JsonSerializer.Deserialize<ProjectData>(json);
                if (data == null) throw new Exception("Empty or invalid file.");

                _txtProjectName.Text = data.ProjectName;
                _lstPhases.Items.Clear();
                foreach (var phase in data.Phases)
                    _lstPhases.Items.Add(phase);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load file:\n" + ex.Message, "Error");
            }
        }

        private void BtnExportHtml_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtProjectName.Text))
            {
                MessageBox.Show("Please enter a project name.", "Missing Name");
                return;
            }

            var data = BuildProjectData();
            var dlg = new SaveFileDialog
            {
                Filter = "HTML files|*.html",
                FileName = data.ProjectName + "_plan.html"
            };

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(dlg.FileName, GenerateHtml(data), System.Text.Encoding.UTF8);
                if (MessageBox.Show("Exported! Open in browser?", "Done", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    Process.Start(new ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
            }
        }

        private ProjectData BuildProjectData()
        {
            var data = new ProjectData { ProjectName = _txtProjectName.Text.Trim() };
            foreach (var item in _lstPhases.Items)
                data.Phases.Add(item.ToString());
            return data;
        }

        private string GenerateHtml(ProjectData data)
        {
            var phases = new System.Text.StringBuilder();
            foreach (var phase in data.Phases)
            {
                phases.AppendLine($@"
                <div class=""phase"">
                    <div class=""phase-dot""></div>
                    <div class=""phase-name"">{Escape(phase)}</div>
                </div>");
            }

            return $@"<!DOCTYPE html>
<html lang=""en"">
<head>
    <meta charset=""UTF-8"">
    <title>{Escape(data.ProjectName)} — Project Plan</title>
    <style>
        body {{
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6fb;
            color: #1a1a2e;
            margin: 0; padding: 40px;
        }}
        .card {{
            background: white;
            border-radius: 12px;
            padding: 40px;
            max-width: 640px;
            margin: 0 auto;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        }}
        .label {{
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #6c63ff;
            margin-bottom: 8px;
        }}
        h1 {{
            font-size: 32px;
            font-weight: 800;
            margin: 0 0 32px 0;
            color: #1a1a2e;
        }}
        .phases-title {{
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #999;
            margin-bottom: 16px;
        }}
        .phase {{
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 0;
            border-bottom: 1px solid #f0f0f5;
        }}
        .phase:last-child {{ border-bottom: none; }}
        .phase-dot {{
            width: 12px; height: 12px;
            border-radius: 50%;
            background: #6c63ff;
            flex-shrink: 0;
        }}
        .phase-name {{ font-size: 16px; font-weight: 500; }}
        .footer {{
            text-align: center;
            margin-top: 32px;
            font-size: 12px;
            color: #bbb;
        }}
    </style>
</head>
<body>
    <div class=""card"">
        <div class=""label"">Project Plan</div>
        <h1>{Escape(data.ProjectName)}</h1>
        <div class=""phases-title"">Phases ({data.Phases.Count})</div>
        <div class=""phase-list"">
            {phases}
        </div>
    </div>
    <div class=""footer"">Generated on {DateTime.Now:MMMM d, yyyy}</div>
</body>
</html>";
        }

        private string Escape(string s) =>
            s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
    }
}
