using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace PlannerV1
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    // --- Simple model ---
    class ProjectData
    {
        public string ProjectName { get; set; } = "";
        public List<string> Phases { get; set; } = new List<string>();
    }

    // --- Main Form ---
    class MainForm : Form
    {
        private TextBox _txtProjectName;
        private TextBox _txtPhase;
        private ListBox _lstPhases;
        private Button _btnAddPhase;
        private Button _btnRemovePhase;
        private Button _btnSave;

        public MainForm()
        {
            Text = "Project Planner";
            Size = new System.Drawing.Size(420, 420);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            // Project Name label + textbox
            var lblName = new Label { Text = "Project Name:", Left = 16, Top = 16, Width = 120 };
            _txtProjectName = new TextBox { Left = 16, Top = 36, Width = 370 };

            // Phases label
            var lblPhases = new Label { Text = "Phases:", Left = 16, Top = 76, Width = 120 };

            // Phase input + Add button
            _txtPhase = new TextBox { Left = 16, Top = 96, Width = 280 };
            _btnAddPhase = new Button { Text = "Add", Left = 304, Top = 94, Width = 82 };
            _btnAddPhase.Click += BtnAddPhase_Click;

            // Phase list
            _lstPhases = new ListBox { Left = 16, Top = 130, Width = 370, Height = 180 };

            // Remove + Save buttons
            _btnRemovePhase = new Button { Text = "Remove Selected", Left = 16, Top = 322, Width = 150 };
            _btnRemovePhase.Click += BtnRemovePhase_Click;

            _btnSave = new Button { Text = "Save to JSON", Left = 286, Top = 322, Width = 100 };
            _btnSave.Click += BtnSave_Click;

            Controls.AddRange(new Control[] {
                lblName, _txtProjectName,
                lblPhases, _txtPhase, _btnAddPhase,
                _lstPhases,
                _btnRemovePhase, _btnSave
            });
        }

        private void BtnAddPhase_Click(object sender, EventArgs e)
        {
            string phase = _txtPhase.Text.Trim();
            if (string.IsNullOrEmpty(phase)) return;
            _lstPhases.Items.Add(phase);
            _txtPhase.Clear();
            _txtPhase.Focus();
        }

        private void BtnRemovePhase_Click(object sender, EventArgs e)
        {
            if (_lstPhases.SelectedIndex >= 0)
                _lstPhases.Items.RemoveAt(_lstPhases.SelectedIndex);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtProjectName.Text))
            {
                MessageBox.Show("Please enter a project name.", "Missing Name");
                return;
            }

            var data = new ProjectData { ProjectName = _txtProjectName.Text.Trim() };
            foreach (var item in _lstPhases.Items)
                data.Phases.Add(item.ToString());

            var dlg = new SaveFileDialog
            {
                Filter = "JSON files|*.json",
                FileName = data.ProjectName + ".json"
            };

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(dlg.FileName, json);
                MessageBox.Show("Saved successfully!", "Done");
            }
        }
    }
}
