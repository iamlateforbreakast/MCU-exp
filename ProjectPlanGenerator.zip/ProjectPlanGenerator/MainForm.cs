using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ProjectPlanGenerator
{
    public class MainForm : Form
    {
        private ProjectPlan _plan = new ProjectPlan();
        private TabControl _tabs;
        private Panel _sidebar;

        // Overview controls
        private TextBox _txtName, _txtDesc, _txtManager, _txtTeam, _txtBudget, _txtObjectives;
        private DateTimePicker _dtStart, _dtEnd;
        private ComboBox _cboStatus, _cboPriority;

        // Phases
        private ListBox _lstPhases;
        private Button _btnAddPhase, _btnRemovePhase, _btnEditPhase;

        // Milestones
        private ListView _lvMilestones;
        private Button _btnAddMilestone, _btnRemoveMilestone;

        // Risks
        private ListView _lvRisks;
        private Button _btnAddRisk, _btnRemoveRisk;

        private Button _btnGenerate, _btnPreview;
        private Panel _statusBar;
        private Label _lblStatus;

        public MainForm()
        {
            InitializeComponent();
            LoadSampleData();
            RefreshPhaseList();
            RefreshMilestoneList();
            RefreshRiskList();
        }

        private void InitializeComponent()
        {
            this.Text = "Project Plan Generator";
            this.Size = new Size(1100, 780);
            this.MinimumSize = new Size(900, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 9f);
            this.BackColor = Color.FromArgb(18, 20, 30);
            this.ForeColor = Color.FromArgb(220, 225, 240);

            // ---- HEADER ----
            var header = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = Color.FromArgb(12, 14, 22) };
            var lblApp = new Label {
                Text = "🗂  Project Plan Generator",
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = Color.FromArgb(200, 195, 255),
                AutoSize = true, Location = new Point(20, 16)
            };
            var lblSub = new Label {
                Text = "Generate beautiful HTML project plans",
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(100, 110, 140),
                AutoSize = true, Location = new Point(22, 40)
            };
            header.Controls.AddRange(new Control[] { lblApp, lblSub });

            // ---- STATUS BAR ----
            _statusBar = new Panel { Dock = DockStyle.Bottom, Height = 30, BackColor = Color.FromArgb(10, 12, 20) };
            _lblStatus = new Label { Text = "Ready", ForeColor = Color.FromArgb(0, 210, 170), AutoSize = true, Location = new Point(12, 7) };
            _statusBar.Controls.Add(_lblStatus);

            // ---- BOTTOM BUTTONS ----
            var btnPanel = new Panel { Dock = DockStyle.Bottom, Height = 56, BackColor = Color.FromArgb(14, 16, 26),
                Padding = new Padding(12, 10, 12, 10) };

            _btnGenerate = CreateButton("⚡  Generate & Save HTML", Color.FromArgb(108, 99, 255), Color.White);
            _btnGenerate.Dock = DockStyle.Right;
            _btnGenerate.Width = 220;
            _btnGenerate.Click += BtnGenerate_Click;

            _btnPreview = CreateButton("👁  Preview in Browser", Color.FromArgb(0, 170, 130), Color.White);
            _btnPreview.Dock = DockStyle.Right;
            _btnPreview.Width = 190;
            _btnPreview.Click += BtnPreview_Click;

            var btnLoadSample = CreateButton("📂  Load Sample", Color.FromArgb(40, 44, 70), Color.FromArgb(180, 185, 210));
            btnLoadSample.Dock = DockStyle.Left;
            btnLoadSample.Width = 140;
            btnLoadSample.Click += (s, e) => { LoadSampleData(); RefreshAll(); SetStatus("Sample project loaded."); };

            var btnClear = CreateButton("🗑  Clear All", Color.FromArgb(40, 44, 70), Color.FromArgb(180, 185, 210));
            btnClear.Dock = DockStyle.Left;
            btnClear.Width = 120;
            btnClear.Click += (s, e) => {
                if (MessageBox.Show("Clear all data?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                    _plan = new ProjectPlan(); RefreshAll(); SetStatus("Cleared.");
                }
            };

            btnPanel.Controls.AddRange(new Control[] { _btnGenerate, _btnPreview, btnClear, btnLoadSample });

            // ---- TAB CONTROL ----
            _tabs = new TabControl {
                Dock = DockStyle.Fill,
                Appearance = TabAppearance.Normal,
                Font = new Font("Segoe UI", 9.5f),
                Padding = new Point(16, 6)
            };
            StyleTabControl(_tabs);

            _tabs.TabPages.Add(BuildOverviewTab());
            _tabs.TabPages.Add(BuildPhasesTab());
            _tabs.TabPages.Add(BuildMilestonesTab());
            _tabs.TabPages.Add(BuildRisksTab());

            this.Controls.AddRange(new Control[] { _tabs, btnPanel, _statusBar, header });
        }

        // ===================== TAB: OVERVIEW =====================
        private TabPage BuildOverviewTab()
        {
            var tab = new TabPage("📋  Overview") { BackColor = Color.FromArgb(18, 20, 30), Padding = new Padding(0) };
            var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, BackColor = Color.FromArgb(18, 20, 30) };

            var layout = new TableLayoutPanel {
                ColumnCount = 2, RowCount = 10,
                Padding = new Padding(20),
                AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Width = 850
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            int row = 0;

            // Project Name
            layout.Controls.Add(CreateLabel("Project Name *"), 0, row); row++;
            _txtName = CreateTextBox(); _txtName.Text = _plan.ProjectName;
            _txtName.TextChanged += (s, e) => _plan.ProjectName = _txtName.Text;
            layout.Controls.Add(_txtName, 0, row);
            layout.SetColumnSpan(_txtName, 2); row++;

            // Description
            layout.Controls.Add(CreateLabel("Description"), 0, row); row++;
            _txtDesc = CreateTextBox(multiline: true); _txtDesc.Height = 70; _txtDesc.Text = _plan.Description;
            _txtDesc.TextChanged += (s, e) => _plan.Description = _txtDesc.Text;
            layout.Controls.Add(_txtDesc, 0, row);
            layout.SetColumnSpan(_txtDesc, 2); row++;

            // Objectives
            layout.Controls.Add(CreateLabel("Objectives"), 0, row); row++;
            _txtObjectives = CreateTextBox(multiline: true); _txtObjectives.Height = 60;
            _txtObjectives.TextChanged += (s, e) => _plan.Objectives = _txtObjectives.Text;
            layout.Controls.Add(_txtObjectives, 0, row);
            layout.SetColumnSpan(_txtObjectives, 2); row++;

            // Manager + Team
            var rowPanel = new TableLayoutPanel { ColumnCount = 2, RowCount = 2, Dock = DockStyle.Fill, AutoSize = true };
            rowPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            rowPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            rowPanel.Controls.Add(CreateLabel("Project Manager"), 0, 0);
            rowPanel.Controls.Add(CreateLabel("Team / Department"), 1, 0);
            _txtManager = CreateTextBox(); _txtManager.TextChanged += (s, e) => _plan.ProjectManager = _txtManager.Text;
            _txtTeam = CreateTextBox(); _txtTeam.TextChanged += (s, e) => _plan.Team = _txtTeam.Text;
            rowPanel.Controls.Add(_txtManager, 0, 1); rowPanel.Controls.Add(_txtTeam, 1, 1);
            layout.Controls.Add(rowPanel, 0, row); layout.SetColumnSpan(rowPanel, 2); row++;

            // Dates
            var datePanel = new TableLayoutPanel { ColumnCount = 2, RowCount = 2, Dock = DockStyle.Fill, AutoSize = true };
            datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            datePanel.Controls.Add(CreateLabel("Start Date"), 0, 0);
            datePanel.Controls.Add(CreateLabel("End Date"), 1, 0);
            _dtStart = CreateDatePicker(); _dtStart.Value = _plan.StartDate;
            _dtStart.ValueChanged += (s, e) => _plan.StartDate = _dtStart.Value;
            _dtEnd = CreateDatePicker(); _dtEnd.Value = _plan.EndDate;
            _dtEnd.ValueChanged += (s, e) => _plan.EndDate = _dtEnd.Value;
            datePanel.Controls.Add(_dtStart, 0, 1); datePanel.Controls.Add(_dtEnd, 1, 1);
            layout.Controls.Add(datePanel, 0, row); layout.SetColumnSpan(datePanel, 2); row++;

            // Status + Priority + Budget
            var spPanel = new TableLayoutPanel { ColumnCount = 3, RowCount = 2, Dock = DockStyle.Fill, AutoSize = true };
            spPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));
            spPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33));
            spPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33));
            spPanel.Controls.Add(CreateLabel("Status"), 0, 0);
            spPanel.Controls.Add(CreateLabel("Priority"), 1, 0);
            spPanel.Controls.Add(CreateLabel("Budget"), 2, 0);
            _cboStatus = CreateCombo(new[] { "Planning", "Active", "In Progress", "On Hold", "Completed", "Cancelled" });
            _cboStatus.SelectedItem = _plan.Status;
            _cboStatus.SelectedIndexChanged += (s, e) => _plan.Status = _cboStatus.SelectedItem?.ToString() ?? "";
            _cboPriority = CreateCombo(new[] { "Low", "Medium", "High", "Critical" });
            _cboPriority.SelectedItem = _plan.Priority;
            _cboPriority.SelectedIndexChanged += (s, e) => _plan.Priority = _cboPriority.SelectedItem?.ToString() ?? "";
            _txtBudget = CreateTextBox(); _txtBudget.TextChanged += (s, e) => _plan.Budget = _txtBudget.Text;
            spPanel.Controls.Add(_cboStatus, 0, 1); spPanel.Controls.Add(_cboPriority, 1, 1); spPanel.Controls.Add(_txtBudget, 2, 1);
            layout.Controls.Add(spPanel, 0, row); layout.SetColumnSpan(spPanel, 2);

            scroll.Controls.Add(layout);
            tab.Controls.Add(scroll);
            return tab;
        }

        // ===================== TAB: PHASES =====================
        private TabPage BuildPhasesTab()
        {
            var tab = new TabPage("🔷  Phases") { BackColor = Color.FromArgb(18, 20, 30) };
            var split = new SplitContainer { Dock = DockStyle.Fill, SplitterDistance = 260, BackColor = Color.FromArgb(18, 20, 30) };

            // Left: Phase list
            var leftPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12) };
            leftPanel.Controls.Add(CreateLabel("Phases"));

            _lstPhases = new ListBox {
                Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 22, 34),
                ForeColor = Color.FromArgb(200, 205, 225), BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 10f), ItemHeight = 28,
                Margin = new Padding(0, 20, 0, 0)
            };
            _lstPhases.SelectedIndexChanged += LstPhases_SelectedIndexChanged;

            var btnBar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, BackColor = Color.FromArgb(18, 20, 30), FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(0, 6, 0, 0) };
            _btnAddPhase = CreateSmallButton("+ Add Phase", Color.FromArgb(108, 99, 255));
            _btnRemovePhase = CreateSmallButton("Remove", Color.FromArgb(180, 40, 60));
            _btnEditPhase = CreateSmallButton("Edit", Color.FromArgb(50, 55, 80));
            _btnAddPhase.Click += (s, e) => AddPhase();
            _btnRemovePhase.Click += (s, e) => RemovePhase();
            _btnEditPhase.Click += (s, e) => EditPhase();
            btnBar.Controls.AddRange(new Control[] { _btnAddPhase, _btnRemovePhase, _btnEditPhase });
            leftPanel.Controls.Add(_lstPhases);
            leftPanel.Controls.Add(btnBar);

            // Right: Task list for selected phase
            var rightPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12), BackColor = Color.FromArgb(18, 20, 30) };
            var lblTasks = CreateLabel("Tasks in Selected Phase");
            rightPanel.Controls.Add(lblTasks);

            var lvTasks = new ListView {
                Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 22, 34),
                ForeColor = Color.FromArgb(200, 205, 225), BorderStyle = BorderStyle.None,
                View = View.Details, FullRowSelect = true, GridLines = false,
                Font = new Font("Segoe UI", 9f), Margin = new Padding(0, 20, 0, 0)
            };
            lvTasks.Columns.Add("Task", 200); lvTasks.Columns.Add("Assignee", 120);
            lvTasks.Columns.Add("Due", 90); lvTasks.Columns.Add("Priority", 70); lvTasks.Columns.Add("Status", 90);
            StyleListView(lvTasks);

            var btnBarTasks = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 42, BackColor = Color.FromArgb(18, 20, 30), FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(0, 6, 0, 0) };
            var btnAddTask = CreateSmallButton("+ Add Task", Color.FromArgb(0, 170, 130));
            var btnRemoveTask = CreateSmallButton("Remove Task", Color.FromArgb(180, 40, 60));
            btnAddTask.Click += (s, e) => AddTask(lvTasks);
            btnRemoveTask.Click += (s, e) => RemoveTask(lvTasks);
            btnBarTasks.Controls.AddRange(new Control[] { btnAddTask, btnRemoveTask });

            rightPanel.Controls.Add(lvTasks);
            rightPanel.Controls.Add(btnBarTasks);

            _lstPhases.SelectedIndexChanged += (s, e) => RefreshTaskList(lvTasks);

            split.Panel1.Controls.Add(leftPanel);
            split.Panel2.Controls.Add(rightPanel);
            tab.Controls.Add(split);
            return tab;
        }

        // ===================== TAB: MILESTONES =====================
        private TabPage BuildMilestonesTab()
        {
            var tab = new TabPage("🏁  Milestones") { BackColor = Color.FromArgb(18, 20, 30) };
            var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };

            var lbl = CreateLabel("Milestones — key dates and deliverables");
            panel.Controls.Add(lbl);

            _lvMilestones = new ListView {
                Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 22, 34),
                ForeColor = Color.FromArgb(200, 205, 225), BorderStyle = BorderStyle.None,
                View = View.Details, FullRowSelect = true, GridLines = false,
                Font = new Font("Segoe UI", 9.5f), Margin = new Padding(0, 24, 0, 0)
            };
            _lvMilestones.Columns.Add("Milestone Name", 340);
            _lvMilestones.Columns.Add("Date", 130);
            _lvMilestones.Columns.Add("Completed", 100);
            StyleListView(_lvMilestones);

            var btnBar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44, BackColor = Color.FromArgb(18, 20, 30), FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(0, 6, 0, 0) };
            _btnAddMilestone = CreateSmallButton("+ Add Milestone", Color.FromArgb(108, 99, 255));
            _btnRemoveMilestone = CreateSmallButton("Remove", Color.FromArgb(180, 40, 60));
            var btnToggle = CreateSmallButton("Toggle Complete", Color.FromArgb(0, 130, 100));
            _btnAddMilestone.Click += (s, e) => AddMilestone();
            _btnRemoveMilestone.Click += (s, e) => RemoveMilestone();
            btnToggle.Click += (s, e) => ToggleMilestone();
            btnBar.Controls.AddRange(new Control[] { _btnAddMilestone, _btnRemoveMilestone, btnToggle });

            panel.Controls.Add(_lvMilestones);
            panel.Controls.Add(btnBar);
            tab.Controls.Add(panel);
            return tab;
        }

        // ===================== TAB: RISKS =====================
        private TabPage BuildRisksTab()
        {
            var tab = new TabPage("⚠  Risks") { BackColor = Color.FromArgb(18, 20, 30) };
            var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };
            panel.Controls.Add(CreateLabel("Risk Register"));

            _lvRisks = new ListView {
                Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 22, 34),
                ForeColor = Color.FromArgb(200, 205, 225), BorderStyle = BorderStyle.None,
                View = View.Details, FullRowSelect = true, GridLines = false,
                Font = new Font("Segoe UI", 9.5f), Margin = new Padding(0, 24, 0, 0)
            };
            _lvRisks.Columns.Add("Risk Title", 220);
            _lvRisks.Columns.Add("Level", 80);
            _lvRisks.Columns.Add("Description", 240);
            _lvRisks.Columns.Add("Mitigation", 220);
            StyleListView(_lvRisks);

            var btnBar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44, BackColor = Color.FromArgb(18, 20, 30), FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(0, 6, 0, 0) };
            _btnAddRisk = CreateSmallButton("+ Add Risk", Color.FromArgb(200, 60, 60));
            _btnRemoveRisk = CreateSmallButton("Remove", Color.FromArgb(120, 40, 40));
            _btnAddRisk.Click += (s, e) => AddRisk();
            _btnRemoveRisk.Click += (s, e) => RemoveRisk();
            btnBar.Controls.AddRange(new Control[] { _btnAddRisk, _btnRemoveRisk });

            panel.Controls.Add(_lvRisks);
            panel.Controls.Add(btnBar);
            tab.Controls.Add(panel);
            return tab;
        }

        // ===================== ACTIONS =====================

        private void BtnGenerate_Click(object s, EventArgs e)
        {
            SyncOverviewToModel();
            if (string.IsNullOrWhiteSpace(_plan.ProjectName)) { MessageBox.Show("Please enter a project name.", "Validation"); return; }
            var dlg = new SaveFileDialog { Filter = "HTML files|*.html", FileName = SanitizeFilename(_plan.ProjectName) + "_plan.html", Title = "Save Project Plan" };
            if (dlg.ShowDialog() == DialogResult.OK) {
                File.WriteAllText(dlg.FileName, HtmlGenerator.Generate(_plan), System.Text.Encoding.UTF8);
                SetStatus($"Saved: {dlg.FileName}");
                if (MessageBox.Show("File saved! Open in browser?", "Success", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
            }
        }

        private void BtnPreview_Click(object s, EventArgs e)
        {
            SyncOverviewToModel();
            if (string.IsNullOrWhiteSpace(_plan.ProjectName)) { MessageBox.Show("Please enter a project name.", "Validation"); return; }
            var tmpFile = Path.Combine(Path.GetTempPath(), "project_plan_preview.html");
            File.WriteAllText(tmpFile, HtmlGenerator.Generate(_plan), System.Text.Encoding.UTF8);
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(tmpFile) { UseShellExecute = true });
            SetStatus("Preview opened in browser.");
        }

        private void SyncOverviewToModel()
        {
            _plan.ProjectName = _txtName?.Text ?? _plan.ProjectName;
            _plan.Description = _txtDesc?.Text ?? _plan.Description;
            _plan.ProjectManager = _txtManager?.Text ?? _plan.ProjectManager;
            _plan.Team = _txtTeam?.Text ?? _plan.Team;
            _plan.Budget = _txtBudget?.Text ?? _plan.Budget;
            _plan.Objectives = _txtObjectives?.Text ?? _plan.Objectives;
            if (_dtStart != null) _plan.StartDate = _dtStart.Value;
            if (_dtEnd != null) _plan.EndDate = _dtEnd.Value;
            if (_cboStatus?.SelectedItem != null) _plan.Status = _cboStatus.SelectedItem.ToString();
            if (_cboPriority?.SelectedItem != null) _plan.Priority = _cboPriority.SelectedItem.ToString();
        }

        // ---- PHASES ----
        private void AddPhase()
        {
            var dlg = new PhaseDialog(new Phase());
            if (dlg.ShowDialog() == DialogResult.OK) {
                _plan.Phases.Add(dlg.Phase); RefreshPhaseList(); SetStatus("Phase added.");
            }
        }
        private void RemovePhase()
        {
            int i = _lstPhases.SelectedIndex;
            if (i < 0) return;
            if (MessageBox.Show("Remove this phase?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                _plan.Phases.RemoveAt(i); RefreshPhaseList(); SetStatus("Phase removed.");
            }
        }
        private void EditPhase()
        {
            int i = _lstPhases.SelectedIndex;
            if (i < 0) return;
            var dlg = new PhaseDialog(_plan.Phases[i]);
            if (dlg.ShowDialog() == DialogResult.OK) {
                _plan.Phases[i] = dlg.Phase; RefreshPhaseList(); SetStatus("Phase updated.");
            }
        }
        private void LstPhases_SelectedIndexChanged(object s, EventArgs e) { }
        private void RefreshPhaseList()
        {
            _lstPhases.Items.Clear();
            foreach (var p in _plan.Phases) _lstPhases.Items.Add($"  {p.Name}  [{p.Status}]  {p.Progress}%");
        }
        private void RefreshTaskList(ListView lv)
        {
            lv.Items.Clear();
            int i = _lstPhases.SelectedIndex;
            if (i < 0 || i >= _plan.Phases.Count) return;
            foreach (var t in _plan.Phases[i].Tasks) {
                string pLabel = t.Priority == 1 ? "High" : t.Priority == 3 ? "Low" : "Medium";
                var item = new ListViewItem(new string[] { t.Name, t.Assignee, t.DueDate.ToString("MMM d, yyyy"), pLabel, t.Status });
                lv.Items.Add(item);
            }
        }
        private void AddTask(ListView lv)
        {
            int pi = _lstPhases.SelectedIndex;
            if (pi < 0) { MessageBox.Show("Select a phase first."); return; }
            var dlg = new TaskDialog(new TaskItem());
            if (dlg.ShowDialog() == DialogResult.OK) { _plan.Phases[pi].Tasks.Add(dlg.Task); RefreshTaskList(lv); SetStatus("Task added."); }
        }
        private void RemoveTask(ListView lv)
        {
            int pi = _lstPhases.SelectedIndex;
            if (pi < 0 || lv.SelectedIndices.Count == 0) return;
            int ti = lv.SelectedIndices[0];
            _plan.Phases[pi].Tasks.RemoveAt(ti); RefreshTaskList(lv); SetStatus("Task removed.");
        }

        // ---- MILESTONES ----
        private void AddMilestone()
        {
            var dlg = new MilestoneDialog(new Milestone());
            if (dlg.ShowDialog() == DialogResult.OK) { _plan.Milestones.Add(dlg.MilestoneItem); RefreshMilestoneList(); SetStatus("Milestone added."); }
        }
        private void RemoveMilestone()
        {
            if (_lvMilestones.SelectedIndices.Count == 0) return;
            _plan.Milestones.RemoveAt(_lvMilestones.SelectedIndices[0]); RefreshMilestoneList(); SetStatus("Milestone removed.");
        }
        private void ToggleMilestone()
        {
            if (_lvMilestones.SelectedIndices.Count == 0) return;
            int i = _lvMilestones.SelectedIndices[0];
            _plan.Milestones[i].Completed = !_plan.Milestones[i].Completed; RefreshMilestoneList();
        }
        private void RefreshMilestoneList()
        {
            _lvMilestones.Items.Clear();
            foreach (var m in _plan.Milestones) {
                var item = new ListViewItem(new string[] { m.Name, m.Date.ToString("MMM d, yyyy"), m.Completed ? "✓ Yes" : "No" });
                if (m.Completed) item.ForeColor = Color.FromArgb(0, 200, 160);
                else if (m.Date < DateTime.Today) item.ForeColor = Color.FromArgb(255, 100, 130);
                _lvMilestones.Items.Add(item);
            }
        }

        // ---- RISKS ----
        private void AddRisk()
        {
            var dlg = new RiskDialog(new Risk());
            if (dlg.ShowDialog() == DialogResult.OK) { _plan.Risks.Add(dlg.RiskItem); RefreshRiskList(); SetStatus("Risk added."); }
        }
        private void RemoveRisk()
        {
            if (_lvRisks.SelectedIndices.Count == 0) return;
            _plan.Risks.RemoveAt(_lvRisks.SelectedIndices[0]); RefreshRiskList(); SetStatus("Risk removed.");
        }
        private void RefreshRiskList()
        {
            _lvRisks.Items.Clear();
            foreach (var r in _plan.Risks) {
                var item = new ListViewItem(new string[] { r.Title, r.Level, r.Description, r.Mitigation });
                if (r.Level == "High") item.ForeColor = Color.FromArgb(255, 100, 130);
                else if (r.Level == "Medium") item.ForeColor = Color.FromArgb(255, 185, 80);
                else item.ForeColor = Color.FromArgb(0, 200, 160);
                _lvRisks.Items.Add(item);
            }
        }

        private void RefreshAll()
        {
            if (_txtName != null) _txtName.Text = _plan.ProjectName;
            if (_txtDesc != null) _txtDesc.Text = _plan.Description;
            if (_txtManager != null) _txtManager.Text = _plan.ProjectManager;
            if (_txtBudget != null) _txtBudget.Text = _plan.Budget;
            if (_txtObjectives != null) _txtObjectives.Text = _plan.Objectives;
            if (_dtStart != null) _dtStart.Value = _plan.StartDate;
            if (_dtEnd != null) _dtEnd.Value = _plan.EndDate;
            if (_cboStatus != null) _cboStatus.SelectedItem = _plan.Status;
            if (_cboPriority != null) _cboPriority.SelectedItem = _plan.Priority;
            RefreshPhaseList(); RefreshMilestoneList(); RefreshRiskList();
        }

        private void LoadSampleData()
        {
            _plan = new ProjectPlan {
                ProjectName = "E-Commerce Platform Redesign",
                Description = "Full redesign and rebuild of the customer-facing e-commerce platform to improve UX, performance and conversion rates.",
                ProjectManager = "Sarah Mitchell",
                Team = "Digital Products",
                StartDate = DateTime.Today.AddDays(-30),
                EndDate = DateTime.Today.AddMonths(5),
                Status = "Active",
                Priority = "High",
                Budget = "$145,000",
                Objectives = "Increase conversion rate by 25%, reduce page load time under 2s, improve mobile UX score to 90+, and launch new product discovery feature.",
                Phases = new List<Phase> {
                    new Phase {
                        Name = "Discovery & Research", Status = "Completed", Progress = 100,
                        StartDate = DateTime.Today.AddDays(-30), EndDate = DateTime.Today.AddDays(-10),
                        Description = "User research, competitor analysis, and requirements gathering.",
                        Tasks = new List<TaskItem> {
                            new TaskItem { Name = "User interviews", Assignee = "UX Team", Status = "Done", Priority = 1, DueDate = DateTime.Today.AddDays(-25) },
                            new TaskItem { Name = "Competitor analysis", Assignee = "Product", Status = "Done", Priority = 2, DueDate = DateTime.Today.AddDays(-20) },
                            new TaskItem { Name = "Requirements document", Assignee = "Sarah M.", Status = "Done", Priority = 1, DueDate = DateTime.Today.AddDays(-12) }
                        }
                    },
                    new Phase {
                        Name = "Design", Status = "In Progress", Progress = 60,
                        StartDate = DateTime.Today.AddDays(-10), EndDate = DateTime.Today.AddDays(25),
                        Description = "UI/UX design for all key flows: homepage, PDP, checkout, and account.",
                        Tasks = new List<TaskItem> {
                            new TaskItem { Name = "Wireframes", Assignee = "Anna K.", Status = "Done", Priority = 1, DueDate = DateTime.Today.AddDays(-5) },
                            new TaskItem { Name = "Design system", Assignee = "Anna K.", Status = "In Progress", Priority = 1, DueDate = DateTime.Today.AddDays(10) },
                            new TaskItem { Name = "Checkout flow design", Assignee = "Anna K.", Status = "Todo", Priority = 2, DueDate = DateTime.Today.AddDays(20) }
                        }
                    },
                    new Phase {
                        Name = "Development", Status = "Not Started", Progress = 0,
                        StartDate = DateTime.Today.AddDays(26), EndDate = DateTime.Today.AddMonths(4),
                        Description = "Frontend and backend development, API integration.",
                        Tasks = new List<TaskItem> {
                            new TaskItem { Name = "Frontend scaffold", Assignee = "Dev Team", Status = "Todo", Priority = 1, DueDate = DateTime.Today.AddDays(35) },
                            new TaskItem { Name = "Product API", Assignee = "Backend", Status = "Todo", Priority = 1, DueDate = DateTime.Today.AddDays(50) },
                            new TaskItem { Name = "Payment integration", Assignee = "Backend", Status = "Todo", Priority = 1, DueDate = DateTime.Today.AddDays(70) }
                        }
                    }
                },
                Milestones = new List<Milestone> {
                    new Milestone { Name = "Research Complete", Date = DateTime.Today.AddDays(-12), Completed = true },
                    new Milestone { Name = "Design Sign-off", Date = DateTime.Today.AddDays(26), Completed = false },
                    new Milestone { Name = "Dev Feature Freeze", Date = DateTime.Today.AddMonths(3), Completed = false },
                    new Milestone { Name = "Public Launch", Date = DateTime.Today.AddMonths(5), Completed = false }
                },
                Risks = new List<Risk> {
                    new Risk { Title = "Scope Creep", Level = "High", Description = "Stakeholders may add features mid-development.", Mitigation = "Strict change control process with formal approval." },
                    new Risk { Title = "3rd-party API Delay", Level = "Medium", Description = "Payment gateway integration may face delays.", Mitigation = "Identify backup provider and start integration early." },
                    new Risk { Title = "Budget Overrun", Level = "Medium", Description = "Unforeseen technical complexity.", Mitigation = "10% contingency buffer in budget." },
                    new Risk { Title = "Key Staff Turnover", Level = "Low", Description = "Loss of key designer or developer.", Mitigation = "Cross-training and thorough documentation." }
                }
            };
        }

        // ===================== HELPERS =====================
        private void SetStatus(string msg) { _lblStatus.Text = "  ✓  " + msg; }
        private string SanitizeFilename(string name) => System.Text.RegularExpressions.Regex.Replace(name, @"[^\w\-]", "_");

        private Label CreateLabel(string text) => new Label { Text = text, AutoSize = true, ForeColor = Color.FromArgb(130, 140, 180), Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Margin = new Padding(0, 12, 0, 4) };
        private TextBox CreateTextBox(bool multiline = false) => new TextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.FromArgb(210, 215, 235), BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10f), Multiline = multiline, ScrollBars = multiline ? ScrollBars.Vertical : ScrollBars.None, Margin = new Padding(0, 0, 8, 0) };
        private DateTimePicker CreateDatePicker() => new DateTimePicker { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short, CalendarMonthBackground = Color.FromArgb(22, 25, 40), CalendarForeColor = Color.White, Font = new Font("Segoe UI", 10f), Margin = new Padding(0, 0, 8, 0) };
        private ComboBox CreateCombo(string[] items) { var c = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.FromArgb(210, 215, 235), Font = new Font("Segoe UI", 10f), Margin = new Padding(0, 0, 8, 0) }; c.Items.AddRange(items); if (items.Length > 0) c.SelectedIndex = 0; return c; }
        private Button CreateButton(string text, Color bg, Color fg) { var b = new Button { Text = text, BackColor = bg, ForeColor = fg, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), Cursor = Cursors.Hand, Height = 36 }; b.FlatAppearance.BorderSize = 0; return b; }
        private Button CreateSmallButton(string text, Color bg) { var b = new Button { Text = text, BackColor = bg, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold), Cursor = Cursors.Hand, Height = 30, AutoSize = true, Padding = new Padding(8, 0, 8, 0) }; b.FlatAppearance.BorderSize = 0; return b; }
        private void StyleTabControl(TabControl tc) { tc.DrawMode = TabDrawMode.OwnerDrawFixed; tc.DrawItem += (s, e) => { var g = e.Graphics; var tab = tc.TabPages[e.Index]; var rect = e.Bounds; g.FillRectangle(new SolidBrush(e.Index == tc.SelectedIndex ? Color.FromArgb(25, 28, 45) : Color.FromArgb(14, 16, 26)), rect); g.DrawString(tab.Text, new Font("Segoe UI", 9f, e.Index == tc.SelectedIndex ? FontStyle.Bold : FontStyle.Regular), new SolidBrush(e.Index == tc.SelectedIndex ? Color.FromArgb(180, 175, 255) : Color.FromArgb(100, 110, 140)), rect, new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center }); }; }
        private void StyleListView(ListView lv) { lv.OwnerDraw = true; lv.DrawColumnHeader += (s, e) => { e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(14, 16, 26)), e.Bounds); e.Graphics.DrawString(e.Header.Text, new Font("Segoe UI", 8.5f, FontStyle.Bold), new SolidBrush(Color.FromArgb(100, 110, 150)), e.Bounds, new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center }); }; lv.DrawSubItem += (s, e) => { var bg = e.ItemIndex % 2 == 0 ? Color.FromArgb(20, 22, 34) : Color.FromArgb(24, 27, 42); e.Graphics.FillRectangle(new SolidBrush(bg), e.Bounds); e.Graphics.DrawString(e.SubItem.Text, new Font("Segoe UI", 9f), new SolidBrush(e.Item.ForeColor != Color.FromArgb(200, 205, 225) ? e.Item.ForeColor : Color.FromArgb(200, 205, 225)), new Rectangle(e.Bounds.X + 4, e.Bounds.Y, e.Bounds.Width - 4, e.Bounds.Height), new StringFormat { LineAlignment = StringAlignment.Center }); }; lv.DrawItem += (s, e) => { }; }
    }

    // ===================== DIALOGS =====================

    public class PhaseDialog : Form
    {
        public Phase Phase { get; private set; }
        private TextBox _name, _desc;
        private DateTimePicker _start, _end;
        private ComboBox _status;
        private NumericUpDown _progress;

        public PhaseDialog(Phase phase)
        {
            Phase = new Phase { Name = phase.Name, Description = phase.Description, StartDate = phase.StartDate, EndDate = phase.EndDate, Status = phase.Status, Progress = phase.Progress, Tasks = phase.Tasks };
            Text = "Edit Phase"; Size = new Size(460, 380); StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(18, 20, 30); ForeColor = Color.FromArgb(200, 210, 230);
            Font = new Font("Segoe UI", 9.5f);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 7, Padding = new Padding(20), AutoSize = false };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            layout.Controls.Add(Lbl("Phase Name"), 0, 0); layout.SetColumnSpan(Lbl(""), 0);
            _name = TB(); _name.Text = phase.Name; layout.Controls.Add(_name, 0, 1); layout.SetColumnSpan(_name, 2);
            layout.Controls.Add(Lbl("Description"), 0, 2); layout.SetColumnSpan(Lbl(""), 0);
            _desc = TB(true); _desc.Text = phase.Description; layout.Controls.Add(_desc, 0, 3); layout.SetColumnSpan(_desc, 2);
            layout.Controls.Add(Lbl("Start Date"), 0, 4); layout.Controls.Add(Lbl("End Date"), 1, 4);
            _start = DTP(); _start.Value = phase.StartDate; _end = DTP(); _end.Value = phase.EndDate;
            layout.Controls.Add(_start, 0, 5); layout.Controls.Add(_end, 1, 5);
            var p2 = new TableLayoutPanel { ColumnCount = 2, Dock = DockStyle.Fill, AutoSize = true };
            p2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50)); p2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            p2.Controls.Add(Lbl("Status"), 0, 0); p2.Controls.Add(Lbl("Progress %"), 1, 0);
            _status = Combo(new[] { "Not Started", "In Progress", "Completed", "On Hold" }); _status.SelectedItem = phase.Status;
            _progress = new NumericUpDown { Minimum = 0, Maximum = 100, Value = phase.Progress, Dock = DockStyle.Fill, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.White };
            p2.Controls.Add(_status, 0, 1); p2.Controls.Add(_progress, 1, 1);
            layout.Controls.Add(p2, 0, 6); layout.SetColumnSpan(p2, 2);

            var btnOk = new Button { Text = "Save Phase", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom, Height = 40, BackColor = Color.FromArgb(108, 99, 255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10f, FontStyle.Bold) };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => { Phase.Name = _name.Text; Phase.Description = _desc.Text; Phase.StartDate = _start.Value; Phase.EndDate = _end.Value; Phase.Status = _status.SelectedItem?.ToString() ?? ""; Phase.Progress = (int)_progress.Value; };
            Controls.Add(layout); Controls.Add(btnOk);
        }
        private Label Lbl(string t) => new Label { Text = t, AutoSize = true, ForeColor = Color.FromArgb(120, 130, 170), Font = new Font("Segoe UI", 8f, FontStyle.Bold), Margin = new Padding(0, 8, 0, 2) };
        private TextBox TB(bool ml = false) => new TextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Multiline = ml, Height = ml ? 54 : 24 };
        private DateTimePicker DTP() => new DateTimePicker { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short };
        private ComboBox Combo(string[] items) { var c = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.White }; c.Items.AddRange(items); if (items.Length > 0) c.SelectedIndex = 0; return c; }
    }

    public class TaskDialog : Form
    {
        public TaskItem Task { get; private set; }
        private TextBox _name, _assignee;
        private ComboBox _status, _priority;
        private DateTimePicker _due;

        public TaskDialog(TaskItem t)
        {
            Task = new TaskItem { Name = t.Name, Assignee = t.Assignee, Status = t.Status, Priority = t.Priority, DueDate = t.DueDate };
            Text = "Edit Task"; Size = new Size(420, 340); StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(18, 20, 30); ForeColor = Color.White; Font = new Font("Segoe UI", 9.5f);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 6, Padding = new Padding(16), AutoSize = false };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

            layout.Controls.Add(Lbl("Task Name"), 0, 0); layout.SetColumnSpan(layout.Controls[0], 2);
            _name = TB(); _name.Text = t.Name; layout.Controls.Add(_name, 0, 1); layout.SetColumnSpan(_name, 2);
            layout.Controls.Add(Lbl("Assignee"), 0, 2); layout.Controls.Add(Lbl("Due Date"), 1, 2);
            _assignee = TB(); _assignee.Text = t.Assignee; layout.Controls.Add(_assignee, 0, 3);
            _due = new DateTimePicker { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short, Value = t.DueDate }; layout.Controls.Add(_due, 1, 3);
            layout.Controls.Add(Lbl("Status"), 0, 4); layout.Controls.Add(Lbl("Priority"), 1, 4);
            _status = Combo(new[] { "Todo", "In Progress", "Done", "Blocked" }); _status.SelectedItem = t.Status;
            _priority = Combo(new[] { "High", "Medium", "Low" });
            _priority.SelectedIndex = t.Priority == 1 ? 0 : t.Priority == 3 ? 2 : 1;
            layout.Controls.Add(_status, 0, 5); layout.Controls.Add(_priority, 1, 5);

            var btnOk = new Button { Text = "Save Task", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom, Height = 40, BackColor = Color.FromArgb(0, 170, 130), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10f, FontStyle.Bold) };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => { Task.Name = _name.Text; Task.Assignee = _assignee.Text; Task.Status = _status.SelectedItem?.ToString() ?? "Todo"; Task.Priority = _priority.SelectedIndex == 0 ? 1 : _priority.SelectedIndex == 2 ? 3 : 2; Task.DueDate = _due.Value; };
            Controls.Add(layout); Controls.Add(btnOk);
        }
        private Label Lbl(string t) => new Label { Text = t, AutoSize = true, ForeColor = Color.FromArgb(120, 130, 170), Font = new Font("Segoe UI", 8f, FontStyle.Bold), Margin = new Padding(0, 8, 0, 2) };
        private TextBox TB() => new TextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
        private ComboBox Combo(string[] items) { var c = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Color.FromArgb(22, 25, 40), ForeColor = Color.White }; c.Items.AddRange(items); if (items.Length > 0) c.SelectedIndex = 0; return c; }
    }

    public class MilestoneDialog : Form
    {
        public Milestone MilestoneItem { get; private set; }
        private TextBox _name;
        private DateTimePicker _date;
        private CheckBox _done;

        public MilestoneDialog(Milestone m)
        {
            MilestoneItem = new Milestone { Name = m.Name, Date = m.Date, Completed = m.Completed };
            Text = "Edit Milestone"; Size = new Size(380, 240); StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(18, 20, 30); ForeColor = Color.White; Font = new Font("Segoe UI", 9.5f);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(16) };
            layout.Controls.Add(new Label { Text = "Milestone Name", AutoSize = true, ForeColor = Color.FromArgb(120,130,170), Font = new Font("Segoe UI", 8f, FontStyle.Bold) }, 0, 0);
            _name = new TextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(22,25,40), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Text = m.Name }; layout.Controls.Add(_name, 0, 1);
            layout.Controls.Add(new Label { Text = "Date", AutoSize = true, ForeColor = Color.FromArgb(120,130,170), Font = new Font("Segoe UI", 8f, FontStyle.Bold), Margin = new Padding(0,8,0,2) }, 0, 2);
            _date = new DateTimePicker { Dock = DockStyle.Fill, Format = DateTimePickerFormat.Short, Value = m.Date }; layout.Controls.Add(_date, 0, 3);
            _done = new CheckBox { Text = "Already completed", ForeColor = Color.FromArgb(0,200,160), Checked = m.Completed, Margin = new Padding(0,8,0,0), AutoSize = true }; layout.Controls.Add(_done, 0, 4);

            var btnOk = new Button { Text = "Save", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom, Height = 38, BackColor = Color.FromArgb(108,99,255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10f, FontStyle.Bold) };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => { MilestoneItem.Name = _name.Text; MilestoneItem.Date = _date.Value; MilestoneItem.Completed = _done.Checked; };
            Controls.Add(layout); Controls.Add(btnOk);
        }
    }

    public class RiskDialog : Form
    {
        public Risk RiskItem { get; private set; }
        private TextBox _title, _desc, _mitigation;
        private ComboBox _level;

        public RiskDialog(Risk r)
        {
            RiskItem = new Risk { Title = r.Title, Description = r.Description, Level = r.Level, Mitigation = r.Mitigation };
            Text = "Edit Risk"; Size = new Size(460, 380); StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(18, 20, 30); ForeColor = Color.White; Font = new Font("Segoe UI", 9.5f);

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 6, Padding = new Padding(16) };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

            layout.Controls.Add(Lbl("Risk Title"), 0, 0); layout.Controls.Add(Lbl("Level"), 1, 0);
            _title = TB(); _title.Text = r.Title; layout.Controls.Add(_title, 0, 1);
            _level = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList, BackColor = Color.FromArgb(22,25,40), ForeColor = Color.White };
            _level.Items.AddRange(new object[] { "Low", "Medium", "High" }); _level.SelectedItem = r.Level; layout.Controls.Add(_level, 1, 1);
            layout.Controls.Add(Lbl("Description"), 0, 2); layout.SetColumnSpan(layout.Controls[layout.Controls.Count-1], 2);
            _desc = TB(true); _desc.Text = r.Description; layout.Controls.Add(_desc, 0, 3); layout.SetColumnSpan(_desc, 2);
            layout.Controls.Add(Lbl("Mitigation Strategy"), 0, 4); layout.SetColumnSpan(layout.Controls[layout.Controls.Count-1], 2);
            _mitigation = TB(true); _mitigation.Text = r.Mitigation; layout.Controls.Add(_mitigation, 0, 5); layout.SetColumnSpan(_mitigation, 2);

            var btnOk = new Button { Text = "Save Risk", DialogResult = DialogResult.OK, Dock = DockStyle.Bottom, Height = 40, BackColor = Color.FromArgb(200,50,70), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10f, FontStyle.Bold) };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += (s, e) => { RiskItem.Title = _title.Text; RiskItem.Description = _desc.Text; RiskItem.Level = _level.SelectedItem?.ToString() ?? "Medium"; RiskItem.Mitigation = _mitigation.Text; };
            Controls.Add(layout); Controls.Add(btnOk);
        }
        private Label Lbl(string t) => new Label { Text = t, AutoSize = true, ForeColor = Color.FromArgb(120,130,170), Font = new Font("Segoe UI", 8f, FontStyle.Bold), Margin = new Padding(0,8,0,2) };
        private TextBox TB(bool ml = false) => new TextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(22,25,40), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Multiline = ml, Height = ml ? 54 : 24 };
    }
}
