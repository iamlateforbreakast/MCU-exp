using System;
using System.Text;

namespace ProjectPlanGenerator
{
    public static class HtmlGenerator
    {
        private static string EscapeHtml(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
        }

        private static string SummaryCard(string icon, string label, string value, string sub)
        {
            return $"      <div class=\"summary-card\"><div class=\"s-icon\">{icon}</div><div class=\"s-value\">{value}</div><div class=\"s-label\">{label}</div><div class=\"s-sub\">{sub}</div></div>";
        }

        public static string Generate(ProjectPlan plan)
        {
            int totalDays = Math.Max(1, (plan.EndDate - plan.StartDate).Days);
            int elapsedDays = (DateTime.Today - plan.StartDate).Days;
            int overallProgress = Math.Max(0, Math.Min(100, elapsedDays * 100 / totalDays));
            int daysLeft = Math.Max(0, (plan.EndDate - DateTime.Today).Days);

            int totalTasks = 0, doneTasks = 0;
            foreach (var p in plan.Phases) {
                totalTasks += p.Tasks.Count;
                foreach (var t in p.Tasks) if (t.Status == "Done") doneTasks++;
            }

            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html lang=\"en\"><head>");
            sb.AppendLine("<meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            sb.AppendLine($"<title>{EscapeHtml(plan.ProjectName)} — Project Plan</title>");
            sb.AppendLine("<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">");
            sb.AppendLine("<link href=\"https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap\" rel=\"stylesheet\">");
            sb.AppendLine(GetStyles());
            sb.AppendLine("</head><body>");

            // HEADER
            sb.AppendLine("<header class=\"site-header\"><div class=\"header-bg\"></div><div class=\"header-content\">");
            sb.AppendLine("<div class=\"header-eyebrow\">Project Plan</div>");
            sb.AppendLine($"<h1 class=\"project-title\">{EscapeHtml(plan.ProjectName)}</h1>");
            if (!string.IsNullOrWhiteSpace(plan.Description))
                sb.AppendLine($"<p class=\"project-desc\">{EscapeHtml(plan.Description)}</p>");
            sb.AppendLine("<div class=\"header-meta\">");
            if (!string.IsNullOrWhiteSpace(plan.ProjectManager))
                sb.AppendLine($"<span class=\"meta-chip\"><span class=\"meta-icon\">&#128100;</span>{EscapeHtml(plan.ProjectManager)}</span>");
            sb.AppendLine($"<span class=\"meta-chip\">&#128197; {plan.StartDate:MMM d, yyyy} &rarr; {plan.EndDate:MMM d, yyyy}</span>");
            sb.AppendLine($"<span class=\"meta-chip status-badge status-{EscapeHtml(plan.Status.ToLower().Replace(" ", "-"))}\">{EscapeHtml(plan.Status)}</span>");
            sb.AppendLine($"<span class=\"meta-chip priority-badge priority-{EscapeHtml(plan.Priority.ToLower())}\">{EscapeHtml(plan.Priority)} Priority</span>");
            sb.AppendLine("</div></div></header>");

            sb.AppendLine("<main class=\"main-content\">");

            // SUMMARY CARDS
            sb.AppendLine("<section class=\"summary-grid\">");
            sb.AppendLine(SummaryCard("&#128203;", "Phases", plan.Phases.Count.ToString(), "defined phases"));
            sb.AppendLine(SummaryCard("&#9989;", "Tasks", totalTasks.ToString(), doneTasks + " completed"));
            sb.AppendLine(SummaryCard("&#9888;&#65039;", "Risks", plan.Risks.Count.ToString(), "identified"));
            sb.AppendLine(SummaryCard("&#127937;", "Milestones", plan.Milestones.Count.ToString(), "key milestones"));
            sb.AppendLine("</section>");

            // PROGRESS
            sb.AppendLine("<section class=\"card\">");
            sb.AppendLine("<h2 class=\"section-title\">Overall Progress</h2>");
            sb.AppendLine("<div class=\"progress-bar-wrap\">");
            sb.AppendLine($"<div class=\"progress-bar\" style=\"width:{overallProgress}%\"></div></div>");
            sb.AppendLine($"<div class=\"progress-label\">{overallProgress}% complete &nbsp;&middot;&nbsp; {daysLeft} days remaining</div>");
            if (!string.IsNullOrWhiteSpace(plan.Objectives)) {
                sb.AppendLine("<div class=\"objectives-box\"><div class=\"objectives-label\">Objectives</div>");
                sb.AppendLine($"<p>{EscapeHtml(plan.Objectives)}</p></div>");
            }
            if (!string.IsNullOrWhiteSpace(plan.Budget))
                sb.AppendLine($"<div class=\"budget-box\">&#128176; Budget: <strong>{EscapeHtml(plan.Budget)}</strong></div>");
            sb.AppendLine("</section>");

            // MILESTONES
            if (plan.Milestones.Count > 0) {
                sb.AppendLine("<section class=\"card\"><h2 class=\"section-title\">Milestones</h2><div class=\"timeline\">");
                foreach (var m in plan.Milestones) {
                    string cls = m.Completed ? "milestone done" : (m.Date < DateTime.Today ? "milestone overdue" : "milestone");
                    string icon = m.Completed ? "&#10003;" : (m.Date < DateTime.Today ? "!" : "&#9711;");
                    sb.AppendLine($"<div class=\"{cls}\"><div class=\"milestone-dot\">{icon}</div>");
                    sb.AppendLine($"<div class=\"milestone-info\"><strong>{EscapeHtml(m.Name)}</strong><span>{m.Date:MMM d, yyyy}</span></div></div>");
                }
                sb.AppendLine("</div></section>");
            }

            // PHASES
            if (plan.Phases.Count > 0) {
                sb.AppendLine("<section class=\"phases-section\">");
                sb.AppendLine("<h2 class=\"section-title standalone\">Project Phases</h2>");
                foreach (var phase in plan.Phases) {
                    sb.AppendLine("<div class=\"phase-card\">");
                    sb.AppendLine("<div class=\"phase-header\">");
                    sb.AppendLine($"<div class=\"phase-name\">{EscapeHtml(phase.Name)}</div>");
                    sb.AppendLine($"<span class=\"phase-status status-{EscapeHtml(phase.Status.ToLower().Replace(" ", "-"))}\">{EscapeHtml(phase.Status)}</span>");
                    sb.AppendLine("</div>");
                    if (!string.IsNullOrWhiteSpace(phase.Description))
                        sb.AppendLine($"<p class=\"phase-desc\">{EscapeHtml(phase.Description)}</p>");
                    sb.AppendLine("<div class=\"phase-meta\">");
                    sb.AppendLine($"<span>&#128197; {phase.StartDate:MMM d} &rarr; {phase.EndDate:MMM d, yyyy}</span>");
                    sb.AppendLine($"<span>Progress: <strong>{phase.Progress}%</strong></span>");
                    sb.AppendLine("</div>");
                    sb.AppendLine("<div class=\"phase-progress-bar\">");
                    sb.AppendLine($"<div class=\"phase-progress-fill\" style=\"width:{phase.Progress}%\"></div></div>");

                    if (phase.Tasks.Count > 0) {
                        sb.AppendLine("<table class=\"task-table\"><thead><tr><th>Task</th><th>Assignee</th><th>Due</th><th>Priority</th><th>Status</th></tr></thead><tbody>");
                        foreach (var t in phase.Tasks) {
                            string pLabel = t.Priority == 1 ? "High" : t.Priority == 3 ? "Low" : "Medium";
                            string pCls = t.Priority == 1 ? "priority-high" : t.Priority == 3 ? "priority-low" : "priority-medium";
                            string sCls = t.Status == "Done" ? "status-done" : t.Status == "In Progress" ? "status-in-progress" : "status-todo";
                            sb.AppendLine($"<tr><td>{EscapeHtml(t.Name)}</td><td>{EscapeHtml(t.Assignee)}</td><td>{t.DueDate:MMM d}</td>");
                            sb.AppendLine($"<td><span class=\"badge {pCls}\">{pLabel}</span></td><td><span class=\"badge {sCls}\">{EscapeHtml(t.Status)}</span></td></tr>");
                        }
                        sb.AppendLine("</tbody></table>");
                    }
                    sb.AppendLine("</div>");
                }
                sb.AppendLine("</section>");
            }

            // RISKS
            if (plan.Risks.Count > 0) {
                sb.AppendLine("<section class=\"card\"><h2 class=\"section-title\">Risk Register</h2><div class=\"risk-grid\">");
                foreach (var r in plan.Risks) {
                    string rCls = r.Level == "High" ? "risk-high" : r.Level == "Low" ? "risk-low" : "risk-medium";
                    sb.AppendLine($"<div class=\"risk-item {rCls}\">");
                    sb.AppendLine($"<div class=\"risk-header\"><strong>{EscapeHtml(r.Title)}</strong><span class=\"risk-badge\">{EscapeHtml(r.Level)}</span></div>");
                    if (!string.IsNullOrWhiteSpace(r.Description)) sb.AppendLine($"<p class=\"risk-desc\">{EscapeHtml(r.Description)}</p>");
                    if (!string.IsNullOrWhiteSpace(r.Mitigation)) sb.AppendLine($"<div class=\"risk-mitigation\">&#128737; {EscapeHtml(r.Mitigation)}</div>");
                    sb.AppendLine("</div>");
                }
                sb.AppendLine("</div></section>");
            }

            sb.AppendLine($"<footer class=\"plan-footer\">Generated on {DateTime.Now:MMMM d, yyyy} at {DateTime.Now:HH:mm}</footer>");
            sb.AppendLine("</main></body></html>");
            return sb.ToString();
        }

        private static string GetStyles() { return @"<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0c0e14;--surface:#13151f;--surface2:#1a1d2e;--border:rgba(255,255,255,0.07);--accent:#6c63ff;--accent2:#00d4aa;--text:#e8eaf0;--text-muted:#7a7f99;--danger:#ff5c7c;--warn:#ffb347;--success:#00d4aa}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);line-height:1.6;min-height:100vh}
.site-header{position:relative;padding:60px 48px 48px;overflow:hidden}
.header-bg{position:absolute;inset:0;background:linear-gradient(135deg,#1a0a2e 0%,#0c0e14 50%,#001a14 100%);z-index:0}
.header-bg::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 20% 50%,rgba(108,99,255,0.25) 0%,transparent 60%),radial-gradient(ellipse 60% 80% at 80% 20%,rgba(0,212,170,0.15) 0%,transparent 60%)}
.header-content{position:relative;z-index:1;max-width:900px}
.header-eyebrow{font-family:'Syne',sans-serif;font-size:11px;font-weight:600;letter-spacing:4px;text-transform:uppercase;color:var(--accent2);margin-bottom:12px}
.project-title{font-family:'Syne',sans-serif;font-size:clamp(36px,5vw,64px);font-weight:800;line-height:1.05;background:linear-gradient(135deg,#fff 30%,var(--accent2) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:16px}
.project-desc{color:var(--text-muted);font-size:16px;max-width:600px;margin-bottom:28px}
.header-meta{display:flex;flex-wrap:wrap;gap:10px}
.meta-chip{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.06);border:1px solid var(--border);border-radius:999px;padding:6px 14px;font-size:13px;font-weight:500;backdrop-filter:blur(10px)}
.status-planning{border-color:rgba(108,99,255,0.4);color:#b8b4ff}
.status-active,.status-in-progress{border-color:rgba(0,212,170,0.4);color:var(--accent2)}
.status-completed{border-color:rgba(0,212,170,0.5);color:var(--accent2)}
.priority-high{border-color:rgba(255,92,124,0.4);color:#ff8fa3}
.priority-low{border-color:rgba(0,212,170,0.3);color:var(--accent2)}
.main-content{max-width:1000px;margin:0 auto;padding:40px 24px}
.summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:28px}
.summary-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px 20px;text-align:center}
.s-icon{font-size:28px;margin-bottom:10px}
.s-value{font-family:'Syne',sans-serif;font-size:36px;font-weight:800;color:var(--accent2)}
.s-label{font-size:13px;font-weight:600;color:var(--text);margin-top:2px}
.s-sub{font-size:11px;color:var(--text-muted);margin-top:4px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:32px;margin-bottom:24px}
.section-title{font-family:'Syne',sans-serif;font-size:20px;font-weight:700;margin-bottom:24px;color:#fff}
.section-title.standalone{margin-bottom:16px}
.progress-bar-wrap{height:12px;background:rgba(255,255,255,0.07);border-radius:999px;overflow:hidden;margin-bottom:10px}
.progress-bar{height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:999px}
.progress-label{font-size:13px;color:var(--text-muted)}
.objectives-box{margin-top:20px;background:var(--surface2);border-left:3px solid var(--accent);border-radius:0 12px 12px 0;padding:16px 20px}
.objectives-label{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:2px;color:var(--accent);margin-bottom:8px}
.budget-box{margin-top:14px;font-size:14px;color:var(--text-muted)}
.timeline{display:flex;flex-direction:column}
.milestone{display:flex;align-items:center;gap:16px;padding:14px 0;border-bottom:1px solid var(--border)}
.milestone:last-child{border-bottom:none}
.milestone-dot{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;flex-shrink:0;background:var(--surface2);border:2px solid var(--accent);color:var(--accent)}
.milestone.done .milestone-dot{background:var(--accent2);border-color:var(--accent2);color:#000}
.milestone.overdue .milestone-dot{background:rgba(255,92,124,0.2);border-color:var(--danger);color:var(--danger)}
.milestone-info{display:flex;flex-direction:column;gap:2px}
.milestone-info strong{font-size:15px}
.milestone-info span{font-size:12px;color:var(--text-muted)}
.phases-section{margin-bottom:24px}
.phase-card{background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:28px;margin-bottom:16px}
.phase-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px}
.phase-name{font-family:'Syne',sans-serif;font-size:18px;font-weight:700}
.phase-status{font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;padding:4px 12px;border-radius:999px;background:rgba(108,99,255,0.15);border:1px solid rgba(108,99,255,0.3);color:#b8b4ff}
.phase-status.status-in-progress{background:rgba(0,212,170,0.1);border-color:rgba(0,212,170,0.3);color:var(--accent2)}
.phase-status.status-completed{background:rgba(0,212,170,0.15);border-color:var(--accent2);color:var(--accent2)}
.phase-status.status-not-started{background:rgba(255,255,255,0.05);border-color:var(--border);color:var(--text-muted)}
.phase-desc{color:var(--text-muted);font-size:14px;margin-bottom:16px}
.phase-meta{display:flex;gap:20px;font-size:13px;color:var(--text-muted);margin-bottom:10px}
.phase-progress-bar{height:6px;background:rgba(255,255,255,0.07);border-radius:999px;overflow:hidden;margin-bottom:20px}
.phase-progress-fill{height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:999px}
.task-table{width:100%;border-collapse:collapse;font-size:13px}
.task-table thead tr{border-bottom:1px solid var(--border)}
.task-table th{text-align:left;padding:8px 12px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted)}
.task-table td{padding:10px 12px;border-bottom:1px solid rgba(255,255,255,0.04)}
.task-table tr:last-child td{border-bottom:none}
.badge{display:inline-block;padding:2px 10px;border-radius:999px;font-size:11px;font-weight:600}
.priority-high{background:rgba(255,92,124,0.15);color:#ff8fa3;border:1px solid rgba(255,92,124,0.3)}
.priority-medium{background:rgba(255,179,71,0.15);color:#ffc87a;border:1px solid rgba(255,179,71,0.3)}
.priority-low{background:rgba(0,212,170,0.1);color:var(--accent2);border:1px solid rgba(0,212,170,0.3)}
.status-done{background:rgba(0,212,170,0.1);color:var(--accent2);border:1px solid rgba(0,212,170,0.3)}
.status-in-progress{background:rgba(108,99,255,0.15);color:#b8b4ff;border:1px solid rgba(108,99,255,0.3)}
.status-todo{background:rgba(255,255,255,0.05);color:var(--text-muted);border:1px solid var(--border)}
.risk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.risk-item{background:var(--surface2);border-radius:14px;padding:20px;border-left:4px solid}
.risk-high{border-color:var(--danger)}
.risk-medium{border-color:var(--warn)}
.risk-low{border-color:var(--accent2)}
.risk-header{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px}
.risk-badge{font-size:11px;font-weight:700;text-transform:uppercase;padding:2px 8px;border-radius:4px;flex-shrink:0}
.risk-high .risk-badge{background:rgba(255,92,124,0.2);color:var(--danger)}
.risk-medium .risk-badge{background:rgba(255,179,71,0.2);color:var(--warn)}
.risk-low .risk-badge{background:rgba(0,212,170,0.15);color:var(--accent2)}
.risk-desc{font-size:13px;color:var(--text-muted);margin-bottom:10px}
.risk-mitigation{font-size:13px;color:var(--text-muted);font-style:italic}
.plan-footer{text-align:center;font-size:12px;color:var(--text-muted);padding:32px 0 16px;border-top:1px solid var(--border);margin-top:16px}
</style>"; }
    }
}
