using System;
using System.Collections.Generic;

namespace ProjectPlanGenerator
{
    public class ProjectPlan
    {
        public string ProjectName { get; set; } = "";
        public string Description { get; set; } = "";
        public string ProjectManager { get; set; } = "";
        public string Team { get; set; } = "";
        public DateTime StartDate { get; set; } = DateTime.Today;
        public DateTime EndDate { get; set; } = DateTime.Today.AddMonths(3);
        public string Status { get; set; } = "Planning";
        public string Priority { get; set; } = "Medium";
        public List<Phase> Phases { get; set; } = new List<Phase>();
        public List<Risk> Risks { get; set; } = new List<Risk>();
        public List<Milestone> Milestones { get; set; } = new List<Milestone>();
        public string Budget { get; set; } = "";
        public string Objectives { get; set; } = "";
    }

    public class Phase
    {
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public DateTime StartDate { get; set; } = DateTime.Today;
        public DateTime EndDate { get; set; } = DateTime.Today.AddMonths(1);
        public string Status { get; set; } = "Not Started";
        public int Progress { get; set; } = 0;
        public List<TaskItem> Tasks { get; set; } = new List<TaskItem>();
    }

    public class TaskItem
    {
        public string Name { get; set; } = "";
        public string Assignee { get; set; } = "";
        public string Status { get; set; } = "Todo";
        public int Priority { get; set; } = 2;
        public DateTime DueDate { get; set; } = DateTime.Today.AddDays(7);
    }

    public class Risk
    {
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string Level { get; set; } = "Medium";
        public string Mitigation { get; set; } = "";
    }

    public class Milestone
    {
        public string Name { get; set; } = "";
        public DateTime Date { get; set; } = DateTime.Today.AddMonths(1);
        public bool Completed { get; set; } = false;
    }
}
