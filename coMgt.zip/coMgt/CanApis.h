/* CanApis.h - header file for CanApis.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */

/* Project : Exomars Rover Vehicle */

#ifndef _CanApis_
#define _CanApis_

/***********************************************************************/
/**
 * @file
 * @brief CanApis.h - standard header file for CanApis module.
 *
 * The file provides the "standard" declaration of public services
 * and relative data definitions of CanApis module.
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

#include "util/basicTypes.h"

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------*/

/*---------- Defines & macro ------------------------------------------*/

/* All right */
#define CAN_API_STATUS_OK       (0)

/* operation aborted */
#define CAN_API_STATUS_ABORTED (-10)

/*---------- Types definitions ----------------------------------------*/
/**
 * @addtogroup canApi
 * @{
 */

/**
 * @brief CanApiRet: returned code list for CanApis services
 *
 * The CanApiRet is a enum type representing returned codes
 * provided by canAPI module
 *
 * By convention, value 0 indicates OK. The values for other codes
 * are design feature.
 */
typedef enum
{
  E_CANAPI_OK 		= 0,	/**< @brief success */
  E_CANAPI_ERROR 	= 100,/**< @brief general error */
  E_CANAPI_INTERNAL_ERROR,	/**< @brief Unexpected Internal error */
  E_CANAPI_BUS_ID_ERROR,	/**< @brief Bus Identifier error */
  E_CANAPI_NODE_ID_ERROR,	/**< @brief Node Identifier error */
  E_CANAPI_NOT_BASE_NODE,	/**< @brief Node Identifier is not a base node */
  E_CANAPI_NODE_ID_UNKNOWN,	/**< @brief Unknown Node Identifier */
  E_CANAPI_COB_ID_ERROR,	/**< @brief COB Identifier error */
  E_CANAPI_COB_ID_WRONG_TYPE,	/**< @brief COB Identifier used with wrong type */
  E_CANAPI_OD_IDX_ERROR,	/**< @brief OD index error */
  E_CANAPI_OD_SUB_IDX_ERROR,	/**< @brief OD sub index error */
  E_CANAPI_DATA_SIZE_ERROR,	/**< @brief data size error */
  
  E_CANAPI_NODE_UNREMOVABLE = 120,	/**< @brief essential loads are unremovable */
  E_CANAPI_APPLI_ALREADY_REGISTERED, /**< @brief Calling application has already been registered */
  E_CANAPI_APPLI_NOT_REGISTERED, /**< @brief Calling application has not been registered */
  E_CANAPI_DATA_BUFFER_INVALID, /**< @brief User-provided data buffer is invalid */
  E_CANAPI_TOO_MANY_PENDING_CMD,/**< @brief There are too many pending commands */
  E_CANAPI_PARAMETER_ERROR, 	/**< @brief wrong use of User-provided parameter */
  E_CANAPI_TRANSFER_ABORT,   /**< @brief Transfer aborted */
  E_CANAPI_SERVICE_TIMEOUT, /**< @brief timeout reached  */
  E_CANAPI_SERVICE_UNAVAIL	/**< @brief service unavailable */
} CanApiRet;


/**
 * @brief CanApiSdoBlkDesc: CANopen Block SDO TM descriptor 
 *
 */
typedef struct CanApiSdoBlkDesc
{
  I08 status; /**< @brief CAN_API_STATUS_OK or CAN_API_STATUS_ABORTED */
  U08 node;   /**< @brief base node ID */
  U08 blks;   /**< @brief total blocks expected for this TM */
  U08 curBlk; /**< @brief number of the current block */
} CanApiSdoBlkDesc;

/** @} */

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

/*
 * CanApis_assignBufferSupportPdoToSdos - assign the function of
 * "Buffer Support PDO" for a download and upload OD array
 */
PUBLIC U32 CanApis_assignBufferSupportPdoToSdos(U08 bus, U16 pdoCobId, U16 dwnlIdx, U16 uplIdx);

/*
 * CanApis_assignBufferSupportPdoToSdo - assign the function of
 * "Buffer Support PDO" for an OD array to a PDO Cob-ID (upload & download)
 */
PUBLIC U32 CanApis_assignBufferSupportPdoToSdo(U08 bus, U16 pdoCobId, U16 idx);

/*
* @brief CanApis_assignSubIndexSDOos - Assign a Sub-Index to use when doing a SDO 
* transfer (one upload, one download) to a particular Node
*/
PUBLIC U32 CanApis_assignSubIndexSDOs(U08 bus, U08 node, U16 dwnlSubIdx, U16 uplSubIdx);

/*
 * CanApis_distributePayloadRet - request to send RET to a node on payload bus
 */
PUBLIC U32 CanApis_distributePayloadRet(U08 node);

/*
 * CanApis_forcePayloadBusSwitch - request to toggle the Payload CAN bus
 */
PUBLIC U32 CanApis_forcePayloadBusSwitch(void);

/*
 * CanApis_getBusState - get the current health status of a master node of the bus
 */
PUBLIC U32 CanApis_getBusState(U08 bus, U08 *pState);

/*
 * CanApis_getNextBlockSdoTm - retrieve the next available block SDO TM
 * of a CAN bus
 */
PUBLIC U32 CanApis_getNextBlockSdoTm(U08 bus, CanApiSdoBlkDesc *pSdoBlkDesc, U08 *pTime, U08 *pPdoData, U08 *pSdoData, U32 *pAvail);

/*
 * CanApis_getNextExpeditedSdoMsg - retrieve the next available expedited SDO message
 * of a node on a CAN bus
 */
PUBLIC U32 CanApis_getNextExpeditedSdoMsg(U08 bus, U08 node, U08 *pTime, U08 *pData, U32 *pAvail);

/*
 * CanApis_getNextPdoTm - retrieve the next available PDO TM
 */
PUBLIC U32 CanApis_getNextPdoTm(U08 bus, U16 cobId, U08 *pTime, U08 *pData, U08 *pDataBytes, U32 *pAvail);

/*
 * CanApis_getNodeState - get the state of a device node
 */
PUBLIC U32 CanApis_getNodeState(U08 bus, U08 node, U32 *pState);

/*
 * CanApis_registerForSyncWindowEvt - request to receive RTEMS event at the end of synchronisation windows
 */
PUBLIC U32 CanApis_registerForSyncWindowEvt(U08 bus, U32 rtEvt);

/*
 * CanApis_sendNmt - send a NMT command to a device node
 */
PUBLIC U32 CanApis_sendNmt(U08 bus, U08 node, U08 cs);

/*
 * CanApis_sendPdoTc - send an asynchronous message to a slave device
 */
PUBLIC U32 CanApis_sendPdoTc(U08 bus, U16 pdoCobId, U08 dataBytes, U08 *pData);

/*
 * CanApis_setRedundancyMasterMask - notify non-essential Switched-On loads
 */
PUBLIC U32 CanApis_setRedundancyMasterMask(U08 bus, U08 toAdd, U08 toRemove);

/*
 * CanApis_startBlockDownloadSdo - request to start a Block SDO download on a node
 */
PUBLIC U32 CanApis_startBlockDownloadSdo(U08 bus, U08 node, U32 dataBytes, U08 *pData);

/*
 * CanApis_startExpeditedDownloadSdo - send an expedited SDO download message to a slave device
 */
PUBLIC U32 CanApis_startExpeditedDownloadSdo(U08 bus, U08 node, U16 idx, U08 subIdx, U08 dataBytes, U32 data32Bit);

/*
 * CanApis_startExpeditedUploadSdo - send an expedited SDO upload message to a slave device
 */
PUBLIC U32 CanApis_startExpeditedUploadSdo(U08 bus, U08 node, U16 idx, U08 subIdx);

/*
 * CanApis_waitForSyncWindowEvt - waiting for RTEMS event at the end of synchronisation windows
 */
PUBLIC U32 CanApis_waitForSyncWindowEvt(U08 bus, U32 *pElapsedCycle);
   
/*------------------ ooOoo Reserved Global  functions ooOoo ----------------------*/

#endif /* _CanApis_ */
