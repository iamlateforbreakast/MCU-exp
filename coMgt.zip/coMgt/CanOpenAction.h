/* CanOpenAction.h - header file for CanOpenAction.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenAction_
#define _CanOpenAction_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenAction.h - header file for CanOpenAction module.
 *
 * The file provides the declaration of public services of CanOpenAction
 * module used by CANopen Manager on the 2 buses
 * 
 **********************************************************************/

/*---------- Standard libraries includes ------------------------------*/
#ifdef PORT
#include <rtems.h> /* %RELAX<FIL-120-PLE> Include used */
#endif
/*---------- FSW includes ---------------------------------------------*/
#include "basicTypes.h"
#include "lock/ResourceLock.h"

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenConfig.h"
#include "coMgt/CanOpenDataPool.h"
#include "coMgt/CoMgtHk.h"

/*---------- Defines & macro ------------------------------------------*/

#define CO_SWITCH_BUS_CMD (CANOPEN_NMT_CS_RESET_COM+1) /* code for Switch Bus */
#define CO_BUS_NAME_LENGTH (8)
#define CO_NODE_NAME_LENGTH (8)

#define CO_NODE_LIST_LENGTH (CANOPEN_BASE_NODE_MAX+1)
/*---------- Types definitions ----------------------------------------*/

/**
 * @brief NodeDesc: Node descriptor
 * 
 * The descriptor is used to contain all configuration parameters
 * of a slave node
 **/
typedef struct NodeDesc
{
  Char devName[CO_NODE_NAME_LENGTH]; /**< @brief device name in text format */
  U08  baseNid;                      /**< @brief base node ID */
  U08  nodeMsk;                      /**< @brief node mask */
  U08  needDummyPdo;                 /**< @brief if need 5 dummy PDO between each PDO TC */
  U08  isUhf;                        /**< @brief if it's an UHF equipment */
  U16  cobIdRet;                     /**< @brief COB_ID for RET distribution message (index: 0x6000) */ 
} NodeDesc;



/**
 * @brief SdoExpdtReq: Expedited SDO request
 */
typedef struct SdoExpdtReq
{
  CoMsg msg;      /**< @brief content of the request */ 
  U32 reqCnt;     /**< @brief request counter */ 
} SdoExpdtReq;

/**
 * @brief SdoBlkDlReq: Block SDO download request
 */
typedef struct SdoBlkDlReq
{
  U08 node;       /**< @brief download server node ID */
  U08 status;     /**< @brief status of the current block */
  U08 blks;       /**< @brief total blocks for this TC */
  U08 curBlk;     /**< @brief number of the current block */
  U16 nBytes;     /**< @brief total data bytes of the current transfer */
  U16 objIdx;     /**< @brief index of the object */
  U16 objSubIdx;  /**< @brief SubIndex of the object */
  U32 reqCnt;     /**< @brief download request counter */ 
  U08 data[CO_SDO_BLK_DATA_LENGTH_MAX]; /**< @brief buffer containing downloaded data */
} SdoBlkDlReq;


/**
 * @brief SdoBlkUlReq: Block SDO upload request
 */
typedef struct SdoBlkUlReq
{
  U08 node;       /**< @brief upload server node ID */
  U08 status;     /**< @brief status of the current block */
  U16 pdoReq;     /**< @brief if the request is issued by a BSP message: TRUE:FALSE */
  U08 pdoData[CO_OD_BSP_DATA_LENGTH]; /**< @brief BSP message data part */
  U32 nBytes;     /**< @brief total data bytes requested */
  U16 objIdx;     /**< @brief index of the object */
  U16 objSubIdx;  /**< @brief SubIndex of the object */
  U32 reqCnt;     /**< @brief upload request counter */ 
} SdoBlkUlReq;


/**
 * @brief SdoBlkExec: Execution result for Block SDO upload/download request
 */
typedef struct SdoBlkExec
{
  U08 node;       /**< @brief upload/dwonload server node ID */
  U08 unused;
  U16 nBytes;     /**< @brief total bytes for this TC */
  U16 objIdx;     /**< @brief index of the object */
  U32 cycle;      /**< @brief execution cycle */
  U32 result;     /**< @brief execution result */
  U32 sdoUpRecNum;   /**< @brief execution result */
  U32 reqCnt;     /**< @brief upload/download request counter */ 
} SdoBlkExec;

/**
 * @brief SdoBlkTimeoutEvtData: Buffer Support Object Timeout Event Data
 */
typedef struct SdoBlkTimeoutEvtData
{
  U08 busId;      /**< @brief CAN Bus Id */
  U08 nodeId;     /**< @brief dwonload server node ID */
  U16 nodeIdx;    /**< @brief index of the object */
  U16 sdoBlkSize; /**< @brief total data bytes of the current transfer */
}SdoBlkTimeoutEvtData;

/**
 * @brief SyncWaitTask: Synchronisation Wait task Context descriptor 
 */
typedef struct SyncWaitTask
{
  rtems_id taskId;    /**< @brief task ID */
  Bool waiting;       /**< @brief is currently waiting ? */
  Uint lastWaitCycle; /**< @brief last waked up cycle */
  rtems_event_set rtEvt; /**< @brief RTEMS event to use for task notification */
} SyncWaitTask;


/**
 * @brief CoCtx: CANopen Manager Context descriptor 
 * This structure contains all data elements to work with a CAN Bus:
 * - configuration parameters,
 * - working context
 **/
typedef struct CoCtx
{
  /* this section contains identifiers of the Bus manager itself */
  Char busName[CO_BUS_NAME_LENGTH];  /**< @brief CAN Bus name */
  Uint busId;                        /**< @brief CAN Bus Id */
  U16 evtPid;                        /**< @brief Application Process ID to be used when generating events */
  rtems_id taskId;                   /**< @brief task ID of current manager */
  rtems_id cycSyncSem;               /**< @brief Manager cycle synchronization semaphore */
  ResourceLock lock;                 /**< @brief @mutex (PLAT/PAYL) Protection for the CANopen context.
                                          Protects variable @ref CoMgr_ctx */

  /* this section contains descriptions of nodes on the bus */
  Uint nodes;                                /**< @brief nodes on the bus */
  NodeDesc *pNodeList;                       /**< @brief node descriptor list */
  NodeStat *pNodeStat;                       /**< @brief node state list */
  U08 nodeToBusNodeIdx[CO_NODE_LIST_LENGTH]; /**< @brief table computing index of node in list */

  /* this section contains states/statistics of the Bus manager automaton */
  CoState curState;    /**< @brief current manager automaton state */
  CoState lastState;   /**< @brief last manager automaton state */
  Uint nTrans;         /**< @brief number of state transition occurred */
  CoEvt lastEvt;       /**< @brief last event received */
  Uint nEvt;           /**< @brief number of significant events received */

  Uint cycles;      /**< @brief current Cycle Count (10 Hz): incremented from startup */
  Uint slotInCycle; /**< @brief current Slot Count (100 Hz): between 0 and 9 if started */
  Uint slots;       /**< @brief Total Slot Count (100 Hz): incremented from startup */
  Uint itInCycle;   /**< @brief current Interrupt Count (200 Hz): between 0 and 19 if started */
  
  /* additional healthy status */
  U08 actPmHealth;      /**< @brief active PM health status */
  U08 extCanHealth;     /**< @brief external CAN Bus health status */
  U16 dummy00;          /**< @brief unused, for alignment purpose */
  
  U32 canStat;          /**< @brief CAN IF status register content */

  /* this section contains master's TX/RX context */
  Uint list;          /**< @brief list number currently used*/
  Uint txMsgLists;    /**< @brief Total number of transmit message lists */
  Uint txMsgs;        /**< @brief Total number of transmit messages */
  Uint msgsInCurList; /**< @brief Number of messages in current transmit list */
  
  Uint rxMsgs;        /**< @brief Total number of received message */
  CoMsg lastRxMsg;    /**< @brief last received message (in the last handled slot) */

  /* this section contains service 2 related context */
  Uint tcCount;       /**< @brief Total number of received TC */
  Uint tmCount;       /**< @brief Total number of generated TM */
  
  /* this section contains Master Redundancy management context */
  U32 nodeSwitchOnMsk;   /**< @brief flag indicating the switched-on's slaves' list */
  U32 nodeHbRegMsk;      /**< @brief flag indicating the slaves' HB messages reception status */
  Uint ctoggle;          /**< @brief variable describing bus switching number */
  Uint ttogglePeriodInc; /**< @brief additional delay for TtogglePeriod */
  Int ttoggleTimer;      /**< @brief variable describing the remaining cycles before timeout detection due to at least one missing hearbeat */
  Int tresetTimer;       /**< @brief variable describing the remaining cycles before timeout detection due to all hearbeats being missing */
  
  /* this section describes slave's node anomalies detection, for HK purpose */
  U08 toggleNode;	      /**< @brief latest triggered node */
  U08 uhfHailNode;      /**< @brief latest hail node */
  U08 unexpHbNode;      /**< @brief unexpected HB message source node */
  U08 dummy01;		      /**< @brief unused, for alignment purpose */
  U32 toggleCycle;      /**< @brief latest triggered cycle */
  U32 uhfHailCycle;     /**< @brief latest Hail cycle */
  U32 unexpHbCycle;	    /**< @brief unexpected HB message cycle */
  
  /* this section contains node commanding for master */
  Uint mstCmdQueue[CO_MST_CMD_QUEUE_LENGTH]; /**< @brief master NMT command requests queue */
  Uint mstCmdIn;			  /**< @brief number of master NMT command requests submitted */
  Uint mstCmdOut;       /**< @brief number of master NMT command requests handled */

  /* this section contains node commanding for slave */
  CoMsg slvCmdQueue[CO_SLV_CMD_QUEUE_LENGTH]; /**< @brief slave NMT command requests queue */
  Uint  slvCmdIn;			      /**< @brief number of slave NMT command requests submitted */
  Uint  slvCmdOut;			    /**< @brief number of slave NMT command requests handled */

  /* event waiting task list */
  Uint registeredTaskNum;		        /**< @brief number of registered tasks to wait at synchro windows */
  SyncWaitTask taskList[CO_SYNC_EVENT_APP_MAX]; /**< @brief descriptor list of registered tasks */
  
  /* this section contains the working context */
  Uint chanId;          /**< @brief channel Id */
  CoNodeHealthSts healthStatus;    /**< @brief master health status */
  Uint hbCountUp;       /**< @brief heart beat period count up*/
  Bool commSyncEna;     /**< @brief Communication SYNC is enabled */
  Uint commSyncCountUp; /**< @brief Communication SYNC period count up */
  Uint lastHbCycle;     /**< @brief cycle number at last HB generation time */
  
  U32  cucC32B;   /**< @brief CCSDS CUC coarse time part in 32 bits */
  U16  cucF16B;   /**< @brief CCSDS CUC fine time part in 16 bits */
  U16  dummy2;    /**< @brief unused, for alignment purpose */
  
  /* CCSDS CUC time for next synchronisation cycle */
  U32  cucC32BNextSyncCycle;   /**< @brief coarse time part in 32 bits */
  U16  cucF16BNextSyncCycle;   /**< @brief fine time part in 16 bits */
  U16  dummy3;                 /**< @brief unused, for alignment purpose */

  /* this section contains PDO context */
  
  Bool pdoEna;               /**< @brief PDO protocol is enabled */

  /* PDO TM storage area lists */
  PdoTmArea *pPdoTmArea;  /**< @brief PDO TM storage lists */
  
  /* PDO TC request area */
  CoMsg pdoTcQueue[CO_PDO_TC_QUEUE_LENGTH]; /**< @brief PDO TC message queue */
  Uint  pdoTcIn;			    /**< @brief number of requests submitted */
  Uint  pdoTcOut;			    /**< @brief number of requests handled */
  
  /* RET distribution request area */
  U08   retNodeIdxQueue[CO_RET_QUEUE_LENGTH]; /**< @brief requested node ID queue */
  Uint  retIn;				      /**< @brief number of requests submitted */
  Uint  retOut;				      /**< @brief number of requests handled */

  /* SDO expedited received messages queue list */
  SdoMsgArea *pSdoMsgArea; /**< @brief SDO expedited received messages queue list */
  
  /* SDO block TM queue */
  SdoBlkTmArea *pSdoBlkTmArea;  /**< @brief SDO block TM storage area */
  
  /* SDO automaton context */
  Uint sdoState;
  Uint nSdoTrans;
  
  /* this section contains SDO context */
  Bool sdoEna;          /**< @brief SDO protocol is enabled */
  U08  expdtSdoNode;    /**< @brief ongoing expedited SDO node */
  U08  expdtSdoScs;     /**< @brief expected expedited SDO SCS in response */
  U08  blkSdoUlNode;    /**< @brief ongoing Block upload SDO node */
  U08  blkSdoDlNode;    /**< @brief ongoing Block download SDO node */
  Bool blkSdoAddList;   /**< @brief status indicating the additional message in the current slot for Block SDO transfer */
  Uint blkSdoDlLastSlotsCnt;                       /**< @brief absolute slot count of last END Block SDO download confirm message*/
  U08  lastSdoMtx[CANOPEN_SDO_MULTIPLEXOR_SIZE];   /**< @brief multiplexor in last SDO exchange */
  Uint expdtSdoAbt; /**< @brief expedited SDO transfer aborted counter */
  Uint blkSdoAbt; /**< @brief block SDO transfer aborted counter */
  
  /* expedited SDO TC request management */
  SdoExpdtReq expdtSdoDlQueue[CO_EXPDT_SDO_DL_QUEUE_LENGTH];/**< @brief expedited SDO TC requests queue */
  Uint  expdtSdoDlIn;                                 /**< @brief number of requests submitted */
  Uint  expdtSdoDlOut;                                /**< @brief number of requests handled */
  Uint  expdtSdoDlReqCnt;                             /**< @brief SDO expedited request counter */
  Uint  expdtSdoDlReqLast;                            /**< @brief last SDO expedited request handled*/

  /* expedited SDO TM request management */
  SdoExpdtReq expdtSdoUlQueue[CO_EXPDT_SDO_UL_QUEUE_LENGTH];/**< @brief expedited SDO TM requests queue */
  Uint  expdtSdoUlIn;                                 /**< @brief number of requests submitted */
  Uint  expdtSdoUlOut;                                /**< @brief number of requests handled */
  Uint  expdtSdoUlReqCnt;                              /**< @brief SDO expedited request counter */
  Uint  expdtSdoUlReqLast;                             /**< @brief last SDO expedited request handled */
  
  /* SDO block download (TC) request */
  SdoBlkDlReq *pSdoBlkDlReq; /**< @brief SDO block download (TC) request queue */
  Uint sdoDlQLength;   /**< @brief length of SDO block download (TC) request queue */
  Uint sdoDlIn;        /**< @brief number of requests submitted */
  Uint sdoDlOut;       /**< @brief number of requests handled */
  Uint sdoDlReqCnt;    /**< @brief SDO block download request counter */
  Uint sdoDlReqLast;   /**< @brief last SDO block download request handled */
  Bool sdoDlBendTimeout; /**< @brief flag to timeout the SDO Downlink if no answer to the end message is received (10ms after end message) */

  /* execution result for SDO block download (TC) request */
  SdoBlkExec sdoDlExecQueue[CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH];
  Uint sdoDlExecIn;                      /**< @brief number of execution stored */
  Uint sdoDlExecOut;                     /**< @brief number of execution handled */
  SdoBlkTimeoutEvtData sdoBlkTimeoutEvt; /**< @brief Buffer Support Object Timeout Event Data */
  
  /* SDO block upload (TM) request */
  SdoBlkUlReq sdoBlkUlReq[CO_BLK_SDO_UL_QUEUE_LENGTH]; /**< @brief request queue */
  Uint sdoUlIn;        /**< @brief number of requests submitted */
  Uint sdoUlOut;       /**< @brief number of requests handled */
  Uint sdoUlReqCnt;    /**< @brief SDO block upload request counter */
  Uint sdoUlReqLast;   /**< @brief last SDO block upload request handled */
  
  /* execution result for SDO block upload (TM) request */
  SdoBlkExec sdoUlExecQueue[CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH];
  Uint sdoUlExecIn;        /**< @brief number of execution stored */
  Uint sdoUlExecOut;       /**< @brief number of execution handled */
  
  /* this section includes system configuration parameters */
  Uint syncWinLength;  /**< @brief PDO synchronisation window length in slots */
  Uint commSyncPeriod; /**< @brief Communication Cycle Period */
  Uint mstPrdHBPeriod; /**< @brief master Producer HB time (in periods of cycle) */
  Uint ttogglePeriod;  /**< @brief timeout for HB message reception before failure detection of at least one (in periods of HB producer Time) */
  Uint tresetPeriod;   /**< @brief timeout for HB message reception before failure detection all (in periods of HB producer Time) */
  Uint sdoBlks;        /**< @brief number of SDO block transfer in a cycle */
  Uint sdoBlkULStartTimerSlot[CO_SDO_BLK_MAX_IN_CYCLE]; /**< @brief starting Timer slots for the SDO Uplink block transfer */
  Uint sdoBlkDLStartTimerSlot[CO_SDO_BLK_MAX_IN_CYCLE]; /**< @brief starting Timer slots for the SDO Downlink block transfer */
  Uint sdoBlkDlPdoTimeout; /**< @brief number of cycles max for SDO Block Download PDO sending after download end  */
  
  Bool busChanIdSwitched; /**< @brief Flag that says if there has been a channel Id switch for that bus since last call to CanOpenMgt_getCurrentChannel  */
  
  /* this section includes CAN open messages exchange statistics */
  Uint hbMsgsIn;           /**< @brief Received Heart Beat messages */
  Uint hbMsgsOut;          /**< @brief Transmitted Heart Beat messages */
  Uint nmtMsgs;            /**< @brief Transmitted NMT messages */
  Uint syncMsgs;           /**< @brief Transmitted SYNC messages */
  Uint retMsgs;            /**< @brief Transmitted RET messages */
  Uint pdoMsgsIn;           /**< @brief Received PDO messages */
  Uint pdoMsgsOut;          /**< @brief Transmitted PDO messages */
  Uint sdoMsgsIn;           /**< @brief Received SDO messages */
  Uint sdoMsgsOut;          /**< @brief Transmitted SDO messages */
  
  /* FDIR */
  U32 hasOpStateExited;     /**< @brief NMT master state surveillance */
  U32 tresetTriggeredInOp;     /**< @brief treset timer has triggered, go back to OP autonoumsly */
  Boolean firstHbReceived; /**< @brief First HB is received */
  
} CoCtx;

/**
 * @brief CoAction: Pointer to an 'action' of the state machine 
 */
typedef CoState(*CoAction) (CoCtx *pCtx);

/**
 * @brief CobIdDesc: COB-ID descriptor 
 *
 */
typedef struct CobIdDesc
{
  U16 nodeIdx; /**< @brief base node Id index */
  U16 tpdoIdx; /**< @brief for TPDO, index in pdoTm buffer */
  U16 txGroup; /**< @brief reception group base (master->slave, RPDO), if not 0 */
  U16 rxGroup; /**< @brief transmission group base (slave->master, TPDO), if not 0 */
  
} CobIdDesc;

/*---------- Variables exported by the module -------------------------*/

/*
 * CANopen default channel selection for two buses 
 */
PUBLIC Uint CoMgr_defaultBus[ROV_CANBUS_NUM];

/*
 * CoMgr_cobIdList contains, for all COB_ID on the 2 buses, 
 * the corresponding nodeId, its transmit or receive group, its buffer index
 * in the PDO TM queue of the node (if in transmit group)
 */
PUBLIC CobIdDesc CoMgr_cobIdList[ROV_CANBUS_NUM][CANOPEN_NODE_MAX+1];

/*
 * CoMgr_ctx contains, on the 2 buses, all configuration
 * parameters and working context.
 */
PUBLIC CoCtx CoMgr_ctx[ROV_CANBUS_NUM];

/*---------- Functions exported by the module -------------------------*/
/*
 * CanOpenAction_setup - setup automaton start-up context
 */
PUBLIC CoStatus CanOpenAction_setup(CoCtx *pCtx, U16 evtPid);

/*
 * CanOpenAction_busMgrAutom - Engine of the CAN Bus State machine
 */
PUBLIC void CanOpenAction_busMgrAutom(CoCtx *pCtx);

/*
 * CanOpenAction_updateHkArea - update the informations in HK area according
 * to Bus manager context, dedicated to be called at the end of cycle event
 */ 

PUBLIC void CanOpenAction_updateHkArea(CoCtx *pCtx, CoState entryState);
#endif /* _CanOpenAction_ */
