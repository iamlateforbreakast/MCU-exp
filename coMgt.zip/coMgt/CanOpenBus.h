/* CanOpenBus.h - header file for CanOpenBus.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenBus_
#define _CanOpenBus_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenBus.h - header file for CanOpenBus module.
 *
 * The file provides the declaration of public services of CanOpenBus
 * module used by CANopen Manager, through its actions, on the 2 buses
 * 
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- BIOS includes ---------------------------------------------*/
#include "hdsw/HdswExtCan.h"

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenConfig.h"
#include "coMgt/CanOpenCommon.h"


/*---------- Defines & macro ------------------------------------------*/

/* CAN Bus transmission message flip/flop buffer list number */
#define CAN_IF_TX_LIST_NUM (2)

/* CAN Bus transmission buffer number */
#define CAN_IF_TX_LIST_LEGNTH CO_TX_MSG_MAX_IN_SLOT

/*
 * CAN Bus Reception buffer message number:
 * - 192: multiple of 4, as requested by HW ICD,
 * - 192 msgs * 16 bytes => 3 Kbytes 
 * - more than necessary (CO_RX_MSG_MAX_IN_SLOT: 93) => margin
 */

#define CAN_IF_RX_BUFFER_MSGS (192)

/*---------- Types definitions ----------------------------------------*/


typedef void (*CanBus_RestartIf) (
	const HdswExtCan_If_T If,
	/*@out@*/ HdswExtCan_Sts_T *const Sts);

typedef void (*CanBus_SetBusConnState) (
	const HdswExtCan_If_T                  If,
	const HdswExtCan_BusConnState_T        State,
	/*@out@*/       HdswExtCan_Sts_T          *const Sts);

typedef void (*CanBus_SetBitTiming) (
	const HdswExtCan_If_T               If,
	const HdswExtCan_BitTiming_T *const BitTiming,
	/*@out@*/       HdswExtCan_Sts_T       *const Sts);


typedef HdswExtCan_Sts_T (*CanBus_SelectBus) (
	const HdswExtCan_If_T If,
	const HdswExtCan_NomRed_T NomRed);


typedef void (*CanBus_StartTx) (
	const HdswExtCan_If_T               If,
	const HdswExtCan_MsgTx_T     *const Msgs,
	const HdswExtCan_NofTxMsgs_T        NofMsgs,
	/*@out@*/       HdswExtCan_Sts_T       *const Sts);


typedef void (*CanBus_StopTx) (
	const HdswExtCan_If_T If,
	/*@out@*/ HdswExtCan_Sts_T *const Sts);


typedef void (*CanBus_StartRx) (
	const HdswExtCan_If_T               If,
	const HdswExtCan_MsgRx_T     *const Msgs,
	const HdswExtCan_NofRxMsgs_T        NofMsgs,
	/*@out@*/       HdswExtCan_Sts_T       *const Sts);

typedef void (*CanBus_GetRxMsg) (
	const HdswExtCan_If_T           If,
	/*@out@*/       HdswExtCan_MsgRx_T *const Msg,
	/*@out@*/       HdswExtCan_Sts_T   *const Sts);

typedef void (*CanBus_StopRx) (
	const HdswExtCan_If_T If,
	/*@out@*/ HdswExtCan_Sts_T *const Sts);


typedef void (*CanBus_GetTxSts) (
	const HdswExtCan_If_T                If,
	/*@out@*/       HdswNatural32_T         *const NofMsgs,
	/*@out@*/       HdswExtCan_StsDetails_T *const Details,
	/*@out@*/       HdswExtCan_TxSts_T      *const Sts);

typedef void (*CanBus_GetRxSts) (
	const HdswExtCan_If_T                If,
	/*@out@*/       HdswNatural32_T         *const NofMsgs,
	/*@out@*/       HdswExtCan_StsDetails_T *const Details,
	/*@out@*/       HdswExtCan_RxSts_T      *const Sts);

#ifdef COMGT_UT_SUPPORT
/* SIMULATION SPECIFIC */
#include <rtems.h>
typedef struct CanSimCtx
{ 
   Bool started;
   rtems_id txQ;
   rtems_id rxQ;
} CanSimCtx;

#endif
/*---------- Variables exported by the module -------------------------*/
#ifdef COMGT_UT_SUPPORT
PUBLIC CanSimCtx SimCtx[ROV_CANBUS_NUM];
PUBLIC rtems_id CoMgt_SlotSyncSemId[ROV_CANBUS_NUM];
#endif

/*---------- Functions exported by the module -------------------------*/

/*
 * CanOpenBus_setup - Set up a CAN Bus Interface
 */
PUBLIC CoStatus CanOpenBus_setup(Uint busId);

/*
 * CanOpenBus_getCtrlStatus - Get the content of the status register
 * of the CAN Bus Interface
 */
PUBLIC U32 CanOpenBus_getCtrlStatus(Uint busId);

/*
 * CanOpenBus_restart - Initialisation/Restart a CAN Bus Interface
 */
PUBLIC CoStatus CanOpenBus_restart(Uint busId, Uint chanId);
/*
 * CanOpenBus_putMsgInList - Build a CAN message in a message list buffer
 */
PUBLIC CoStatus CanOpenBus_putMsgInList(Uint busId, Uint listId,
	    Uint msgId, Uint msgRtr, Uint dataBytes, U08 *pData);
/*
 * CanOpenBus_txMsgList - transmit messages in a message list buffer
 */
PUBLIC CoStatus CanOpenBus_txMsgList(Uint busId, Uint listId, Uint msgNb, Uint cycle, Uint slot);

/*
 * CanOpenBus_getTxSts - get the status of the last message list transmission
 */
PUBLIC CoStatus CanOpenBus_getTxSts(Uint busId, Uint *pChan, Uint *pList, Uint *pMsgs);

/*
 * CanOpenBus_stopTxMsg - stop ongoing message transmission
 */
PUBLIC CoStatus CanOpenBus_stopTxMsg(Uint busId);

/*
 * CanOpenBus_enableRxMsg - enable reception of messages
 */
PUBLIC CoStatus CanOpenBus_enableRxMsg(Uint busId);

/*
 * CanOpenBus_getTxSts - get the status of the received messages
 */
PUBLIC CoStatus CanOpenBus_getRxSts(Uint busId, Uint *pChan, Uint *pMsgs);

/*
 * CanOpenBus_getNextMsg - get the next received message
 */
PUBLIC CoStatus CanOpenBus_getNextMsg(Uint busId, Uint *pId, Uint *pRtr, Uint *pDataBytes, U08 *pData);

/*
 * CanOpenBus_storeItFromStart - store number of elapsed it Slots from beginning
 */
PUBLIC void CanOpenBus_storeItFromStart(Uint busId, Uint itSlotFromStart);

/*
 * CanOpenBus_disableRxMsg - disable reception of messages
 */
PUBLIC CoStatus CanOpenBus_disableRxMsg(Uint busId);

PUBLIC Bool CanOpenBus_getMstAloneOnBus(Uint busId);


#endif /* _CanOpenBus_ */
