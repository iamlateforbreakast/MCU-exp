/* CanOpenDevCmdTc.h - header file for CanOpenDevCmdTc.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */

/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenDevCmdTc_
#define _CanOpenDevCmdTc_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenTc.h - header file for CanOpenDevCmdTc module.
 *
 * The file provides the declaration of public services of and relative
 * data of CanOpenDevCmdTc module.
 * 
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------*/

/*---------- Defines & macro ------------------------------------------*/
/**
 * @brief CanIoError: CAN IO error list 
 * The CanIoError is a enum type representing CAN IO error list
 * The values are defined per RVSW ICD.
 */
typedef enum
{
  E_CAN_IO_TIMEOUT = 0,    /**< @brief Timeout */
  E_CAN_IO_ABORTED = 1,    /**< @brief Aborted */
  E_CAN_IO_PROT_ERROR = 2  /**< @brief protocol error */
} CanIoError;

/**
 * @brief CanSdoDir: CANopen SDO transfer direction
 * The values are defined per RVSW ICD.
 */
typedef enum
{
  E_CAN_SDO_UPLOAD = 0,     /**< @brief for SDO upload */
  E_CAN_SDO_DOWNLOAD = 1    /**< @brief for SDO download */
} CanSdoDir;

/**
 * @brief CanHbSts: CANopen SDO transfer direction
 * The values are defined per RVSW ICD.
 */
typedef enum
{
  E_CAN_HB_STS_UNEXP = 0, /**< @brief to remove node to mask */
  E_CAN_HB_STS_EXP = 1    /**< @brief to add node to mask */
} CanHbSts;

/*---------- Types definitions ----------------------------------------*/

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/
/*
 * CanOpenDevCmd_registerTCs - register all Device Commanding TC of the CanOpen manager.
 */
void CanOpenDevCmd_registerTCs(void);

/*------------------ ooOoo Reserved Global  functions ooOoo ----------------------*/


#endif /* _CanOpenDevCmdTc_ */
