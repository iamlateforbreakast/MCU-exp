/* CanOpenDataPool.h - CANopen Management Data Pool Definitions */

/* Copyright (c) 2014 - AIRBUS Defence & Space */

/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenDataPool_
#define _CanOpenDataPool_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenDataPool.h - header file CANopen Management Data Pool description.
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenConfig.h"
#include "coMgt/CanOpenObjDict.h"
#include "coMgt/CanOpenStd.h"

/*---------- Defines & macro ------------------------------------------*/


/*---------- Types definitions ----------------------------------------*/

/**
 * @brief CoPdoTmRecord: Record of PDO TM  
 */
typedef struct CoPdoTmRecord
{			     
  U08 dataSize;				     /**< @brief data size of the current TM */
  U08 unused;              /**< @brief Padding purpose */
  U08 cucCoarse[CO_CUC_COARSE_FIELD_LENGTH]; /**< @brief CUC Time coarse part */
  U08 cucFine[CO_CUC_FINE_FIELD_LENGTH];     /**< @brief CUC Time fine part */
  U08 data[CO_OD_PDO_LENGTH]; 	   	     /**< @brief data storage buffer */
} CoPdoTmRecord;

/**
 * @brief PdoTmArea: PDO TM storage area for a COB-ID 
 */
typedef struct PdoTmArea
{
  U32 written;                                /**< @brief total number of stored TM */
  U32 read;                                   /**< @brief total number of TM retrieved by API */
  CoPdoTmRecord tmQueue[CO_PDO_TM_PER_COBID]; /**< @brief TM storage buffer */
} PdoTmArea;

/**
 * @brief CoSdoMsgRecord: Record of expedited SDO Message  
 */
typedef struct CoSdoMsgRecord
{
  U32 result;                                /**< @brief result of the current record */
  U32 reqCnt;                                /**< @brief SDO expedited transfer request number */
  U08 cucCoarse[CO_CUC_COARSE_FIELD_LENGTH]; /**< @brief CUC Time coarse part */
  U08 cucFine[CO_CUC_FINE_FIELD_LENGTH];     /**< @brief CUC Time fine part */
  U16 isDownload;                            /**< @brief flag indicating Download/Upload */
  U08 data[CANOPEN_SDO_DATA_LENGTH]; 	       /**< @brief data storage buffer */
} CoSdoMsgRecord;

/**
 * @brief SdoMsgArea: SDO storage area for a node 
 **/
typedef struct SdoMsgArea
{
  U32 written; 					/**< @brief total number of stored TM */
  U32 read; 					/**< @brief total number of TM retrieved by API */
  CoSdoMsgRecord msgQueue[CO_SDO_MSG_PER_NODE]; /**< @brief message storage buffer queue */
} SdoMsgArea;

/**
 * @brief CoSdoBlkTmRecord: Record of SDO BLOCK TM Message  
 *  Note: 
 */
typedef struct CoSdoBlkTmRecord
{
  U08 status;    /**< @brief OK or CAN_STS_ABORTED */
  U08 node;      /**< @brief base node ID */
  U08 blks;      /**< @brief total blocks expected for this TM */
  U08 curBlk;    /**< @brief number of the current block */
  U16 nBytes;    /**< @brief total data bytes of the current transfer */
  U16 unused;
  CoBufSupPdo pdoData;                       /**< @brief the content of associated pdo message, filled only for the first block */
  U08 cucCoarse[CO_CUC_COARSE_FIELD_LENGTH]; /**< @brief CUC Time coarse part */
  U08 cucFine[CO_CUC_FINE_FIELD_LENGTH];     /**< @brief CUC Time fine part */
  U08 data[CANOPEN_SDO_BLK_NBYTE_PER_SEG*CANOPEN_SDO_BLK_SEGS_MAX];      /**< @brief data byte storage buffer */
} CoSdoBlkTmRecord;

/**
 * @brief SdoBlkTmArea: SDO storage area for a node 
 */
typedef struct SdoBlkTmArea
{
  U32 written; 					    /**< @brief total number of stored TM */
  U32 read; 					    /**< @brief total number of TM retrieved by API */
  U32 blks;               /**< @brief block TM number in area */
  CoSdoBlkTmRecord *pBlkQueue; /**< @brief TM byte storage queue */
} SdoBlkTmArea;

/*---------- Variables exported by the module -------------------------*/


/*---------- Functions exported by the module -------------------------*/

#endif /* _CanOpenDataPool_ */
