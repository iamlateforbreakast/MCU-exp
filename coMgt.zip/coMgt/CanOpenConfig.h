/* CanOpenConfig.h - CANopen configuration file */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenConfig_
#define _CanOpenConfig_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenConfig.h - CANopen configuration file.
 *
 * This file includes a set of ROVER-specific definitions as well as
 * configuration parameters for Platform & Payload Buses. 
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------------*/
#include "coMgt/CanOpenStd.h"
#include "NRDConfigParam.h" /* %RELAX<FIL-120-PLE> This is the Master header file used for the NRD definitions. To simplify maintenance NRD definitions is then split into multiple sub-header files, all included in the master one */

/*---------- Defines & macro ------------------------------------------*/


/*=======================================================================*/
/*===========       Protocol part, project independent       ============*/
/*=======================================================================*/

/**-----------------------------------------------------------------------*/
/** Constant definition/parameters: 
 *  - don't change them before SW design review 
 */

/*
 * CAN Bus Frame definition 
 */
#define CO_SLOTS_IN_CYCLE     (10)    /* 10 slots of 10ms in a software cycle */
#define CO_CYCLE_IN_1SEC      (10)    /* 10 cycles in 1 second */
#define CO_IT_SLOTS_IN_CYCLE  (20)    /* 20 Timer Interrupts in a software cycle */

/* maximum messages in a 10-ms time slot: ~93 CAN Messages in 10000 micro sec. at 1Mbit/s */
#define CO_RX_MSG_MAX_IN_SLOT (93)

/* maximum messages allowed to be transmitted in a 10-ms time slot:
 * - 72 CAN Messages at 1Mbit/s (design feature) 
 * */
#define CO_TX_MSG_MAX_IN_SLOT (72)

/* Node ID mask definition */
#define CO_NMSK_NID_1     (0x7F) /* node-ID count 1 */
#define CO_NMSK_NID_2     (0x7E) /* node-ID count 2 */
#define CO_NMSK_NID_4     (0x7C) /* node-ID count 4 */ 
#define CO_NMSK_NID_8     (0x78) /* node-ID count 8 */
#define CO_NMSK_NID_16    (0x70) /* node-ID count 16 */
#define CO_NMSK_NID_32    (0x60) /* node-ID count 32 */
#define CO_NMSK_NID_64    (0x40) /* node-ID count 64 */

#define CO_NMSK_NID_MAX   (0x80) /* node-ID limit */

/* maximum slaves on a bus: design feature */
#define CO_SLV_NODES_MAX (10)   

/* all slaves on platform bus has ID count 8 (cf: IRD) */
#define CO_PF_SLAVE_NMSK CO_NMSK_NID_8


/* max COB-ID count for a node */
#define CO_COBID_COUNT_MAX (32)


/** 
 * @brief CO_EXPDT_SDO_IN_CYC - maximum number of expedited SDO commands handled in a cycle
 * Note: this value is hard-coded in design (slot 2-8), don't change it before design review
 * @requirements
 * - SRS.DMS.CAN.FUNC.0940 [supported expedited SDO number definition]
 * - SRS.DMS.CAN.PERF.0120 [supported expedited SDO number definition]
 */
#define CO_EXPDT_SDO_IN_CYC (8)


/**
 * @brief SDO block transfer windows' definitions

 * Defined in accordance with CANBus framework description of SRS
 */

/* Platform: first 3 slots (30 ms in 100Hz slots) in a software cycle for PDO TM */
#define CO_PF_PDO_SLOTS (3)

/* Payload: first slot (10 ms in 100Hz slots) in a software cycle for PDO TM */
#define CO_PL_PDO_SLOTS (1)

/** 
 * Starting Slot and number of consecutive slots used for PDO TC transmission
 * - slot 7-8
 */
#define CO_PDO_TC_START_SLOT (7)
#define CO_PDO_TC_SLOTS (2)

/** Rover tailoring for CUC format: 4-byte for coarse part */
#define CO_CUC_COARSE_FIELD_LENGTH (4)

/** Rover tailoring for CUC format: 2-byte for fine part */
#define CO_CUC_FINE_FIELD_LENGTH (2)

/**
 * @brief Synchronisation PDO window duration
 * @requirements
 * - SRS.DMS.CAN.FUNC.0600 [definition of Synchronous Window]
 *
 ***********************************************************************/ 
/** Platform bus: synchronisation at the end of the PDO TM Slot */
#define CO_PF_SYNC_WIN_SLOT (CO_PF_PDO_SLOTS)

/** Payload bus: synchronisation at the end of the PDO TM Slot */
#define CO_PL_SYNC_WIN_SLOT (CO_PL_PDO_SLOTS)

/** Block SDO windows length: 8, 200hz slots */
#define CO_BLOCK_SDO_WIN_LENGTH_TIMER_STEPS (9)

/**
 * @brief CO_SDO_BLK_DATA_LENGTH_MAX - SDO Block Upload/Download Data Block Number/Size 
 * @requirements
 * - SRS.DMS.CAN.FUNC.0270 [SDO Block Data Size definition]
 * - SRS.DMS.CAN.FUNC.0280 [SDO Block Sub Index definition]
 * - SRS.DMS.CAN.FUNC.0290 [SDO Block Segment definition]
 *
 ***********************************************************************/ 
/** maximum of block SDO data length */
#define CO_SDO_BLK_DATA_LENGTH_MAX (CO_OD_SDO_BLK_SIZE_MAX)

/* subidx used for block SDO transfer */
#define CO_SDO_BLK_SUBIDX (1)

/*  maximum of block SDO download data segment in a slot */
#define CO_SDO_BLK_DL_SEGS_MAX_IN_SLOT ((CANOPEN_SDO_BLK_SEGS_MAX+1)/2)

/* RET Distribution always in slot 7: design feature, shall <= 8 */
#define CO_PDO_RET_DIST_SLOT (7)


/**
 * SDO TM/TC Period Slot Definition: design feature
 *
 ***********************************************************************/ 
/** Platform bus: first block SDO period starts at the end of PDO window 
 * Note: Using PDO 100hz counter and "*2" to convert into 200Hz Timer counter */
#define CO_PF_SDO_START_TIMER_SLOT1 (CO_PF_PDO_SLOTS*2)

/** Payload bus: first block SDO period starts at the end of PDO window 
 * Note: Using PDO 100hz counter and "*2" to convert into 200Hz Timer counter */
#define CO_PL_SDO_START_TIMER_SLOT1 (CO_PL_PDO_SLOTS*2 - 1)

/** Payload bus: second block SDO period starts at the end of the first one */
#define CO_PL_SDO_START_TIMER_SLOT2 (CO_PL_SDO_START_TIMER_SLOT1 + CO_BLOCK_SDO_WIN_LENGTH_TIMER_STEPS + 1)

/** Platform bus: 1 block SDO transfer in a cycle */
#define CO_PF_SDO_BLK_MAX_IN_CYCLE (1)

/** Payload bus: 2 block SDO transfers in a cycle */
#define CO_PL_SDO_BLK_MAX_IN_CYCLE (2)

/**
 * SDO Block Upload/Download Data Block Number/Size 
 *
 ***********************************************************************/ 
/* maximum of block SDO data length */
#define CO_SDO_BLK_DATA_LENGTH_MAX (CO_OD_SDO_BLK_SIZE_MAX)

/* subidx used for block SDO transfer */
#define CO_SDO_BLK_SUBIDX (1)

/*  maximum of block SDO download data segment in a slot */
#define CO_SDO_BLK_DL_SEGS_MAX_IN_SLOT ((CANOPEN_SDO_BLK_SEGS_MAX+1)/2)

/**-----------------------------------------------------------------------*/
/** Constant definition/parameters: 
 * - configurable parameters
 */
/*
 * maximum number of applications waiting at the
 * end of Synchronisation PDO window at a Bus 
 */
#define CO_SYNC_EVENT_APP_MAX (4)

/* number of PDO TM stored per cob_id: design feature */
#define CO_PDO_TM_PER_COBID  (20)

/*
 * Maximum number of PDO TC commands handled in a cycle
 * Two slots are used in a cycle;
 * This is SW design feature, less < (CO_TX_MSG_MAX_IN_SLOT*2)
 */
#define CO_PDO_TC_IN_CYC (128)

/* 
 * maximum number of pending RET distribution requests
 * This is SW design feature, (>= CO_SLV_NODES_MAX)
 */
#define CO_RET_QUEUE_LENGTH (10)

/*
 * maximum number of pending PDO commands
 * This is SW design feature
 */
#define CO_PDO_TC_QUEUE_LENGTH (4*CO_PDO_TC_IN_CYC)

/* maximum number of pending NMT commands for slaves (buffer length): design feature */
#define CO_SLV_CMD_QUEUE_LENGTH (16)

/*
 * Maximum number of pending expedited SDO commands
 */
#define CO_EXPDT_SDO_DL_QUEUE_LENGTH (2*CO_EXPDT_SDO_IN_CYC) 

/*
 * Maximum number of pending expedited SDO commands
 */
#define CO_EXPDT_SDO_UL_QUEUE_LENGTH (2*CO_EXPDT_SDO_IN_CYC) 

/* Block SDO download request queue length: 4 cycles */
#define CO_PF_BLK_SDO_DL_QUEUE_LENGTH (CO_PF_SDO_BLK_MAX_IN_CYCLE*4)
#define CO_PL_BLK_SDO_DL_QUEUE_LENGTH (CO_PL_SDO_BLK_MAX_IN_CYCLE*4)

/* Length of execution result queue for Block SDO download request */
#define CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH (8)


/*=======================================================================*/
/*===========     Configuration part, project dependent      ============*/
/*=======================================================================*/


#ifndef COMGT_UT_SUPPORT

/* CAN BUS Configuration parameters of flight RVSW */

#define RT_RELAX (1) /* no RT relax */

/*
 * Node ID and number on Platform Bus
 * Ref: Platform CANBus IRD 
 */
#define CO_PF_NODE_NUM (8) /* for slave */

#define CO_PF_PCDEA_NAME ("PCDE_A")
#define CO_PF_PCDEA_NID (24)
#define CO_PF_PCDEA_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_PCDEA_NID)

#define CO_PF_PCDEB_NAME ("PCDE_B")
#define CO_PF_PCDEB_NID (32)
#define CO_PF_PCDEB_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_PCDEB_NID)

#define CO_PF_UHFA_NAME ("UHFA")
#define CO_PF_UHFA_NID (48)
#define CO_PF_UHFA_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_UHFA_NID)

#define CO_PF_UHFB_NAME ("UHFB")
#define CO_PF_UHFB_NID (56)
#define CO_PF_UHFB_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_UHFB_NID)

#define CO_PF_ADE_L_NOM_NAME ("ADE_L_N")
#define CO_PF_ADE_L_NOM_NID (88)
#define CO_PF_ADE_L_NOM_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_L_NOM_NID)

#define CO_PF_ADE_R_NOM_NAME ("ADE_R_N")
#define CO_PF_ADE_R_NOM_NID (80)
#define CO_PF_ADE_R_NOM_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_R_NOM_NID)

#define CO_PF_ADE_L_RED_NAME ("ADE_L_R")
#define CO_PF_ADE_L_RED_NID (120)
#define CO_PF_ADE_L_RED_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_L_RED_NID)

#define CO_PF_ADE_R_RED_NAME ("ADE_R_R")
#define CO_PF_ADE_R_RED_NID (112)
#define CO_PF_ADE_R_RED_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_R_RED_NID)

/*
 * Node ID and number on Payload Bus
 */
#define CO_PL_NODE_NUM (6) /* for slave */  

#define CO_PL_WISDOM_NAME ("WISDOM")
#define CO_PL_WISDOM_NID (4)
#define CO_PL_WISDOM_NMSK CO_NMSK_NID_4  
#define CO_PL_WISDOM_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PL_WISDOM_NID)

#define CO_PL_RAMAN_NAME ("RAMAN")
#define CO_PL_RAMAN_NID (8)
#define CO_PL_RAMAN_NMSK CO_NMSK_NID_8 
#define CO_PL_RAMAN_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PL_RAMAN_NID)

#define CO_PL_DSEU_M_NAME ("DSEU_M")   
#define CO_PL_DSEU_M_NID (32)          
#define CO_PL_DSEU_M_NMSK CO_NMSK_NID_8   
#define CO_PL_DSEU_M_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PL_DSEU_M_NID)

#define CO_PL_DSEU_R_NAME ("DSEU_R")
#define CO_PL_DSEU_R_NID (48)
#define CO_PL_DSEU_R_NMSK CO_NMSK_NID_8
#define CO_PL_DSEU_R_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PL_DSEU_R_NID)

#define CO_PL_RTB_M_NAME ("RTB_M")       
#define CO_PL_RTB_M_NID (64)          
#define CO_PL_RTB_M_NMSK CO_NMSK_NID_16  
#define CO_PL_RTB_M_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PL_RTB_M_NID)

#define CO_PL_RTB_R_NAME ("RTB_R")
#define CO_PL_RTB_R_NID (96) 
#define CO_PL_RTB_R_NMSK CO_NMSK_NID_16
#define CO_PL_RTB_R_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PL_RTB_R_NID)


/***********************************************************/
/*
 * Node descriptor list on:
 * - Platform Bus
 * - Payload bus 
 */

#define PF_NODE01_DESC {.devName=CO_PF_PCDEA_NAME, .baseNid=CO_PF_PCDEA_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=CFG_PARAM_CAN_NB_PCDE_DUMMY_RPDO, .isUhf=0, .cobIdRet=CO_PF_PCDEA_COBID_RET},
#define PF_NODE02_DESC {.devName=CO_PF_PCDEB_NAME, .baseNid=CO_PF_PCDEB_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=CFG_PARAM_CAN_NB_PCDE_DUMMY_RPDO, .isUhf=0, .cobIdRet=CO_PF_PCDEB_COBID_RET}, 
#define PF_NODE03_DESC {.devName=CO_PF_UHFA_NAME, .baseNid=CO_PF_UHFA_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=1, .cobIdRet=CO_PF_UHFA_COBID_RET},
#define PF_NODE04_DESC {.devName=CO_PF_UHFB_NAME, .baseNid=CO_PF_UHFB_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=1, .cobIdRet=CO_PF_UHFB_COBID_RET},
#define PF_NODE05_DESC {.devName=CO_PF_ADE_L_NOM_NAME, .baseNid=CO_PF_ADE_L_NOM_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_L_NOM_COBID_RET},
#define PF_NODE06_DESC {.devName=CO_PF_ADE_R_NOM_NAME, .baseNid=CO_PF_ADE_R_NOM_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_R_NOM_COBID_RET},
#define PF_NODE07_DESC {.devName=CO_PF_ADE_L_RED_NAME, .baseNid=CO_PF_ADE_L_RED_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_L_RED_COBID_RET},
#define PF_NODE08_DESC {.devName=CO_PF_ADE_R_RED_NAME, .baseNid=CO_PF_ADE_R_RED_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_R_RED_COBID_RET} /* last one, without comma , */

/* empty "descriptor" to fill in the list */
#define PF_NODE09_DESC 
#define PF_NODE10_DESC 

#define PL_NODE01_DESC {.devName=CO_PL_WISDOM_NAME, .baseNid=CO_PL_WISDOM_NID,\
                        .nodeMsk=CO_PL_WISDOM_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_WISDOM_COBID_RET},
#define PL_NODE02_DESC {.devName=CO_PL_RAMAN_NAME, .baseNid=CO_PL_RAMAN_NID,\
                        .nodeMsk=CO_PL_RAMAN_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_RAMAN_COBID_RET},
#define PL_NODE03_DESC {.devName=CO_PL_DSEU_M_NAME, .baseNid=CO_PL_DSEU_M_NID,\
                        .nodeMsk=CO_PL_DSEU_M_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_DSEU_M_COBID_RET},
#define PL_NODE04_DESC {.devName=CO_PL_DSEU_R_NAME, .baseNid=CO_PL_DSEU_R_NID,\
                         .nodeMsk=CO_PL_DSEU_R_NMSK,\
                         .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_DSEU_R_COBID_RET},
#define PL_NODE05_DESC {.devName=CO_PL_RTB_M_NAME, .baseNid=CO_PL_RTB_M_NID,\
                         .nodeMsk=CO_PL_RTB_M_NMSK,\
                         .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_RTB_M_COBID_RET}, 
#define PL_NODE06_DESC {.devName=CO_PL_RTB_R_NAME, .baseNid=CO_PL_RTB_R_NID,\
                         .nodeMsk=CO_PL_RTB_R_NMSK,\
                         .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_RTB_R_COBID_RET} // last one, without comma ,

/* maximum number of pending NMT commands for master (buffer length): design feature */
#define CO_MST_CMD_QUEUE_LENGTH (8)

/* Block SDO Upload request queue length */
#define CO_BLK_SDO_UL_QUEUE_LENGTH (16)

/* Length of execution result queue for Block SDO upload request */
#define CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH (16)

/*
 * maximum number of expedited SDO message stored per node
 */
#define CO_SDO_MSG_PER_NODE (20)


/**
 * @brief CO_PF_BLK_SDO_DL_PDO_TIMEOUT - Timeout period to receive Buffer Support PDO message after
 * End of SDO Block Download
 * @requirements
 * - SRS.DMS.CAN.FUNC.0320 [definition of timeout period]
 *
 ***********************************************************************/ 
/** Platform bus: Timeout period in cycle to receive Buffer Support PDO */
#define CO_PF_BLK_SDO_DL_PDO_TIMEOUT (10)

/** Payload bus: Timeout period in cycle to receive Buffer Support PDO */
#define CO_PL_BLK_SDO_DL_PDO_TIMEOUT  (10)


/*
 * maximum number of block SDO TM stored on platform bus: 
 * design feature, storage capacity > 1 second
 */
#define CO_PF_SDO_BLK_TM_QUEUE_LENGTH ((CO_CYCLE_IN_1SEC+1) * CO_PF_SDO_BLK_MAX_IN_CYCLE)
#define CO_PL_SDO_BLK_TM_QUEUE_LENGTH ((CO_CYCLE_IN_1SEC+1) * CO_PL_SDO_BLK_MAX_IN_CYCLE)


/* SDO block download (TC) request */

/**
 * @brief CO_PF_COMM_CYCLE_PERIOD - Communication Cycle Period (multiple of 100 ms)
 * @requirements
 * - SRS.DMS.CAN.FUNC.0600 [definition of Communication Cycle Period]
 *
 ***********************************************************************/ 
/* platform: 1 cycle => 100 ms */
#define CO_PF_COMM_CYCLE_PERIOD (1)

/* payload: 1 cycles => 100 ms */
#define CO_PL_COMM_CYCLE_PERIOD (1)

/*
 * Platform master Producer Heart beat Time 
 * in unit of 100 ms: e.g: 5 cycles=500 ms
 */
#define CO_PF_MST_PRD_HBT (1)

/*
 * Payload master Producer Heart beat Time 
 * in unit of 100 ms:  e.g: 5 cycles=500 ms
 */
#define CO_PL_MST_PRD_HBT (1)

/** 
 * @brief CO_PF_TOGGLE_CYC - Master Toggle time
 * in multiple Heart beat producer time
 * @requirements
 * - SRS.DMS.CAN.FUNC.1010 [definition of Ttoggle time]
 */
/** Platform master: e.g: 10 timeout=10*100 ms */
#define CO_PF_TOGGLE_CYC (10) 

/** Payload master: e.g: 10 timeout=10*100 ms */
#define CO_PL_TOGGLE_CYC (10) 


#else

/* CAN BUS Configuration parameters for unit tests (covers/qualifies all cases) */

#include "CanOpenConfigTest.h"
#endif

/*---------- Types definitions ----------------------------------------*/

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

#endif /* _CanOpenConfig_ */
