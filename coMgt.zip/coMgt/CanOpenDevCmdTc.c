/* CanOpenDevCmdTc.c - CanOpenTc body */

/* Copyright (c) 2014 - AIRBUS Defence & Space */

/* Project : Exomars Rover Vehicle */

/***********************************************************************/
/**
 * @file
 * @brief CanOpenDevCmdTc - implementation of CanOpenDevCmdTc module.
 *
 * This modules implements CAN TCs of the Service 2.
 *
 * @requirements
 * - SRS.DMS.S2.FUNC.0040
 * - SRS.DMS.S2.FUNC.0050
 * - SRS.DMS.S2.CMD.0170
 ***********************************************************************/

/**
 * @addtogroup devTcMgr
 * @{
 *
 * @par CanOpenDevCmdTc module
 *
 * The CanOpenTc module in the CANopen manager is in charge of handling of
 * TC/TM related to CanOpen function as part of PUS service 2:
 * 
 * - TC (2,128): CANopen Send Expedited SDO command,
 * - TC (2,130): CANopen Block SDO Download command,
 * - TC (2,131): CANopen Block SDO Upload command,
 * - TC (2,133): CANopen Send NMT command,
 * - TC (2,134): CAN Payload Bus Switch,
 * - TC (2,150): Distribute the RET to a CAN bus node
 * - TC (2,151): Set switch mask of a CAN bus
 * 
 * - TM (2,129): CANOpen Expedited SDO Upload Report,
 * - TM (2,132): CANOpen Block SDO Upload Report,
 * 
 * @}
 */

/*---------- Standard libraries includes ------------------------------*/
#include <libc.h>

/*---------- FSW includes ---------------------------------------------*/
#include "util/basicTypes.h"
#include "errorLib.h"

#include "ackLib.h"
#include "tcBus.h"
#include "tmBus.h"
#include "tcLib.h"

#include "PusDefinitions.h"
#include "ByteStream.h"
#include "Pid.h"
#include "Fid.h"
#include "NRDConfigParam.h" /* %RELAX<FIL-120-PLE> This is the Master header file used for the NRD definitions. To simplify maintenance NRD definitions is then split into multiple sub-header files, all included in the master one */


/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenCommon.h"
#include "coMgt/CanOpenAction.h"
#include "coMgt/CanApisFull.h"
#include "coMgt/CanOpenDevCmdTc.h"
#include "coMgt/CanApis.h"

/*---------- BIOS includes ---------------------------------------------*/

/*---------- Local defines & macro ------------------------------------*/

/* Parameter size for FID LENGTH_DISCREP */
#define FID_LENGTH_DISCREP_DATA_SIZE (2)

#define FIDS_CANOPEN_DATA_SIZE_MAX FID_LENGTH_DISCREP_DATA_SIZE

/* Build the expected response for an expedited download command */
#define BUILD_SDO_EXPDT_DL_RESP_HD(idx,subIdx) \
  (((CANOPEN_SDO_SCS_EXPDT_DL&0xFF)<<24) | ((SWAP16((idx)&0xFFFF))<<8) | ((subIdx)&0xFF))

/* Build the expected response for an expedited upload command */
#define BUILD_SDO_EXPDT_UL_RESP_HD(idx,subIdx) \
  (((CANOPEN_SDO_SCS_EXPDT_UL&0xFF)<<24) | (((SWAP16(idx))&0xFFFF)<<8) | ((subIdx)&0xFF))
  
/* mask for common part of header: X, n, s fields are checked */
#define SDO_EXPDT_UL_RESP_HD_MSK ((CANOPEN_SDO_SCS_EXPDT_UL_MSK << 24) | 0xFFFFFF)

/* default wait seconds for timeout detection */
#define SDO_EXPDT_DFL_TIMEOUT_SECONDS (2)
#define SDO_BLOCK_DFL_TIMEOUT_SECONDS (5)

/* Parameter size for TM (2, 129) */
#define CAN_SDO_EXPDT_REPORT_TM_SIZE \
    (DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT_CAN_BUS_ID_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT_CAN_NODE_ID_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT_CAN_OD_IDX_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT_CAN_OD_SUB_IDX_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT_CAN_SDO_RESP_SIZE_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT_CAN_SDO_RESP_NB_ITEMS)

/* Parameter size for TM (2, 132) */
#define CAN_SDO_BLK_REPORT_TM_HEADER_SIZE \
    (DEVICE_COMMANDING_DEV_CMD_CAN_SDO_BLK_UPL_REPORT_CAN_BUS_ID_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_BLK_UPL_REPORT_CAN_NODE_ID_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_BLK_UPL_REPORT_CAN_OD_IDX_PARAM_SIZE +\
     DEVICE_COMMANDING_DEV_CMD_CAN_SDO_BLK_UPL_REPORT_CAN_SDO_BLK_SIZE_PARAM_SIZE)

/*---------- Local types definitions ----------------------------------*/

/* the structure holding all kinds of parameters for a TC execution */
typedef struct CanTcParam {
  
  U08 bus;          /* CAN Bus ID */
  U08 node;         /* Slave CAN Node ID */
  U16 objIdx;       /* CAN Object Dictionary index */
  U08 objSubIdx;    /* CAN Object Dictionary sub-index */
  U08 sdoDir;       /* CAN SDO message direction */
  U16 blkSdoSize;   /* CAN SDO Block transfer Data size */
  U08 *pBlkSdoData; /* CAN SDO Block Data buffer */
  U08 expdtSdoData[CANOPEN_SDO_EXPDT_DATA_MAX]; /* CAN SDO expedited Data */
  U08 expdtSdoSize; /* CAN SDO expedited Data Size */
  U08 cmdSpec;      /* CAN NMT Command Specifier */
  U16 timeoutCycle; /* timeout cycle */
  U32 reqNum;       /* current request number */

} CanTcParam;

/* structure for TM (2, 129): per ICD document */
typedef struct CanTmSdoExpdtUlReport
{

  U08 bus;
  U08 node;
  U16 objIdx;
  U08 objSubIdx;
  U08 dataSize;
  U08 data[CANOPEN_SDO_EXPDT_DATA_MAX];

} CanTmSdoExpdtUlReport;

/* header structure for TM (2, 132): per ICD document */
typedef struct CanTmSdoBlkUlReport
{

  U08 bus;
  U08 node;
  U16 objIdx;
  U16 dataSize;

} CanTmSdoBlkUlReport;
  
/*---------- Definition of variables exported by the module -----------*/
/**
 * @brief When handling a TC(2,130) and if 
 * the CAN_NODE_ID parameter contained in the TC is set to 0, 
 * RVSW shall use the value of the variable CoMgr_canNodeIdSdoDlOverwrite"
 * "for the SDO Download operations instead"
 */
U08 CoMgr_canNodeIdSdoDlOverwrite = CFG_PARAM_CAN_NODE_ID_SDO_DL_OVERWRITE;

/*---------- Definition of local variables and constants --------------*/
  
/* data buffer for SDO block transfer for each bus */  
PRIVATE U08 blkData[ROV_CANBUS_NUM][CO_SDO_BLK_DATA_LENGTH_MAX];
  
/*---------- Declarations of local functions --------------------------*/
/* TC execution functions */
PRIVATE void CanOpenTc_sendExpeditedSdoCmdExec(const U16 *pTc, const U32 *pData, U32 nBytes);
PRIVATE void CanOpenTc_startBlkSdoDloadExec(const U16 *pTc, const U32 *pData, U32 nBytes);
PRIVATE void CanOpenTc_startBlkSdoUloadExec(const U16 *pTc, const U32 *pData, U32 nBytes);
PRIVATE void CanOpenTc_sendNmtCmdExec(const U16 *pTcHeader, const U32 *pTcData, U32 tcDataNbBytes);
PRIVATE void CanOpenTc_switchPayloadBusExec(const U16 *pTc, const U32 *pData, U32 nBytes);
PRIVATE void CanOpenTc_distributeRetToCanBusNode(const U16 *pTc, const U32 *pData, U32 nBytes);
PRIVATE void CanOpenTc_setSwitchMaskCanBus(const U16 *pTc, const U32 *pData, U32 nBytes);

/* support functions */
PRIVATE U32 CanOpenTc_apiStsToFid (CanApiRet coApiStatus, CanTcParam *pParam, U32 *pNFailureParams, U32 *pFailureParam);
PRIVATE U32 CanOpenTc_handleExpeditedUpload (U16 *pTc, CanTcParam *pParam, U32 *pNFailureParams, U32 *pFailureParam);
PRIVATE U32 CanOpenTc_handleExpeditedDownload (CanTcParam *pParam, U32 *pNFailureParams, U32 *pFailureParam);

/*------------------ ooOoo Inline functions (if any) ooOoo ------------*/

/*------------------ ooOoo Global functions ooOoo ---------------------*/

/**
 * @addtogroup coMgr
 * @{
 */

/***********************************************************************/
/**
 * @brief CanOpenDevCmd_registerTCs - register all Device Commanding TC of
 * the CanOpen manager.
 *  
 * This function performs the registration of the TC all TC implemented in
 * CanOpenTc module as part of Service 2
 * 
 * @return N/A
 * 
 ***********************************************************************/ 
void CanOpenDevCmd_registerTCs(void)
{
  /* TC (2,128): CANopen Send Expedited SDO command */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
                 SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_EXP_SDO, CanOpenTc_sendExpeditedSdoCmdExec);
  
  /* TC (2,130): CANopen Block SDO Download command */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
    SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_BLK_SDO_DWN, CanOpenTc_startBlkSdoDloadExec);

  /* TC (2,131): CANopen Block SDO Upload command */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
    SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_BLK_SDO_UPL, CanOpenTc_startBlkSdoUloadExec);
  
  /* TC (2,133): CANopen Send NMT command */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
                 SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_NMT, CanOpenTc_sendNmtCmdExec);

  /* TC (2,134): CAN Payload Bus Switch */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
    SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_PAYLOAD_BUS_SWITCH, CanOpenTc_switchPayloadBusExec);

  /* TC (2,150): Distribute the RET to a CAN bus node */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
    SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_GEN_RET_DISTIB, CanOpenTc_distributeRetToCanBusNode);

  /* TC (2,151): Set switch mask of a CAN bus */
  cdhsTcRegister(SYSTEM_PID, SVC_TYPE_DEVICE_COMMANDING,
    SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_SET_SWITCH_MASK, CanOpenTc_setSwitchMaskCanBus);
}

/** @} */
/*------------------ ooOoo Local functions ooOoo ----------------------*/
/*****************************************************************************/
/** @brief CanOpenTc_sendExpeditedSdoCmdExec - Implements the TC(2,128) execution
 * 
 * This function requests to send a CANopen expedited SDO upload or download 
 * command to a slave node present on the CAN bus. The request is submitted to
 * CAN manager after successful checking of input parameters.
 * 
 * When the command is effectively sent, the answer to the command from the SDO
 * server is analysed to build the execution report. In addition, the expedited
 * SDO report TM(2,129) is generated when a correct response to a upload command
 * is received.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning 
 * - This TC is allowed for the slave nodes present on the Bus using their Base Node ID,
 * - SDO expedited message size and message data in the TC are required only for
 *   download command,
 * - the TM(2,129) can be only generated when a correct response to an upload
 *   command is received,
 * - Only the data part in a SDO upload 8-byte response is put in the TM (2,129),
 * - The response data size in the TM (2,129) indicates the number of the bytes of 
 *   received data, according to the other fields of the response. If this size is 0,
 *   it means that the effective size is not specified in the response, the corresponding
 *   Object Dictionary is be used to find it out.
 *   
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0120
 * - SRS.DMS.S2.CMD.0130
 * - SWICD.CSW.TC(2,128).FMT.0010
 * - SWICD.CSW.TC(2,128).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,128).CHK.0010[2] [FID_CAN_BUS_ID]
 * - SWICD.CSW.TC(2,128).CHK.0010[3] [FID_CAN_NODE]
 * - SWICD.CSW.TC(2,128).CHK.0010[4] [FID_CAN_OD_IDX]
 * - SWICD.CSW.TC(2,128).CHK.0010[5] [FID_CAN_OD_SUB]
 * - SWICD.CSW.TC(2,128).CHK.0010[6] [FID_CAN_SDO_DR]
 * - SWICD.CSW.TC(2,128).CHK.0010[7] [FID_CAN_SDO_SZ]
 * - SWICD.CSW.TC(2,128).CHK.0010[8] [FID_CAN_IO_ERR]
 * - SWICD.CSW.TM(2,129).FMT.0010
 */
PRIVATE void CanOpenTc_sendExpeditedSdoCmdExec(const U16 *pTc, const U32 *pData, U32 nBytes)
{ 
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  Uint fid = NO_FAILURE;
  ByteStream bs;
  U32 expectedParamLength;
  U32 failureParamNb;
  CanTcParam param;
  CoCtx *pCtx;

  /* check TC parameter length: Bus ID + Node ID + Direction + OD Idx  + OD SUB-IDX + nBytes + command */
  failureParamNb = 0;
  expectedParamLength = sizeof(U08) + sizeof(U08) + sizeof(U08)
                      + sizeof(U16) + sizeof(U08) + sizeof(U08)
                      + sizeof(U08) * CANOPEN_SDO_EXPDT_DATA_MAX;
  if (nBytes != expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    /* extract all TC parameters */
    ByteStream_init(&bs, (Object *) pData, nBytes);
    
    memset (&param, 0, sizeof(CanTcParam));
    param.bus       = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.node      = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.sdoDir    = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.objIdx    = (U16) ByteStream_readUnsigned(&bs, sizeof(U16));
    param.objSubIdx = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.expdtSdoSize = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    
    ByteStream_readBytes(&bs, CANOPEN_SDO_EXPDT_DATA_MAX, param.expdtSdoData);
    
    /* only one executing TC on a Bus possible by S2 */
    pCtx = &CoMgr_ctx[param.bus%ROV_CANBUS_NUM];
    pCtx->tcCount++;
    
    /* Set the default timeout 
     * Note: RT_RELAX is different from 1 only when the instrumented version 
     * is used for code coverage purpose
     */
    param.timeoutCycle = CO_CYCLE_IN_1SEC * SDO_EXPDT_DFL_TIMEOUT_SECONDS * RT_RELAX;
    
    /* for upload command */
    if (param.sdoDir == E_CAN_SDO_UPLOAD)
    {
      fid = CanOpenTc_handleExpeditedUpload ((U16 *)pTc, &param, &failureParamNb, &failureParam[0]);
      pCtx->tmCount++;
    }
    /* for download command */
    else if (param.sdoDir == E_CAN_SDO_DOWNLOAD)
    {
      fid = CanOpenTc_handleExpeditedDownload (&param, &failureParamNb, &failureParam[0]);
    }
    else
    {
      fid = FID_CAN_SDO_DR;
      failureParam[failureParamNb] = param.sdoDir; /* received transfer direction */
      failureParamNb++;
    }
  }
  
  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }
  
  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/*****************************************************************************/
/** @brief CanOpenTc_startBlkSdoDloadExec - Implements the TC(2,130) execution
 * 
 * This function requests to execute a CANopen Block SDO download transfer with a 
 * slave node present on the CAN bus. The request is submitted to CAN manager 
 * after successful checking of input parameters.
 * 
 * When the transfer is effectively performed, the exchanges with the SDO
 * server is analysed to build the execution report.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning
 * - This TC is allowed for the slave nodes present on the Bus using their Base Node ID,
 * - The Object index provided in the TC for the transfer is applied, regardless
 *   of the object index assigned to node for block transfer,
 * - This TC must be handled with care, as it allows sending patches to slave nodes
 *
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0140
 * - SRS.DMS.S2.CMD.0141
 * - SWICD.CSW.TC(2,130).FMT.0010
 * - SWICD.CSW.TC(2,130).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,130).CHK.0010[2] [FID_CAN_BUS_ID]
 * - SWICD.CSW.TC(2,130).CHK.0010[3] [FID_CAN_NODE]
 * - SWICD.CSW.TC(2,130).CHK.0010[4] [FID_CAN_OD_IDX]
 * - SWICD.CSW.TC(2,130).CHK.0010[5] [FID_CAN_SDO_SZ]
 * - SWICD.CSW.TC(2,130).CHK.0010[6] [FID_CAN_IO_ERR]
 */
PRIVATE void CanOpenTc_startBlkSdoDloadExec(const U16 *pTc, const U32 *pData, U32 nBytes)
{ 
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  CanApiRet coApiSts;
  Uint fid = NO_FAILURE;
  ByteStream bs;
  U32 expectedParamLength;
  U32 failureParamNb;
  CanTcParam param;
  CoCtx *pCtx;
  U08 nodeId;

  /* check TC parameter length: Bus ID + Node ID + OD Idx + nBytes + data */
  failureParamNb = 0;
  
  /* check size for the first part of the TC: Bus + Node + OD Idx+ BlockSize */
  expectedParamLength = sizeof(U08) + sizeof(U08) + sizeof(U16) + sizeof(U16);
  
  if (nBytes <= expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    /* extract all TC parameters */
    ByteStream_init(&bs, (Object *) pData, nBytes);
    
    memset (&param, 0, sizeof(CanTcParam));
    param.bus       = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.node      = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.objIdx    = (U16) ByteStream_readUnsigned(&bs, sizeof(U16));
    param.blkSdoSize = (U16) ByteStream_readUnsigned(&bs, sizeof(U16));

    /* When handling a TC(2,130) and if 
     * the CAN_NODE_ID parameter contained in the TC is set to 0, 
     * RVSW shall use the value of the data pool variable CoMgr_canNodeIdSdoDlOverwrite"
     * "for the SDO Download operations instead. Mainly used for ADE nodes" 
     */
    if(param.node == 0)
    {
      nodeId = CoMgr_canNodeIdSdoDlOverwrite;
    }
    else
    {
      nodeId = param.node;
    }
    
    /* only one executing TC on a Bus possible by S2 */
    pCtx = &CoMgr_ctx[param.bus%ROV_CANBUS_NUM];
    pCtx->tcCount++;
    
    expectedParamLength += param.blkSdoSize;
    
    if (IS_OUTSIDE(param.blkSdoSize,1,CO_SDO_BLK_DATA_LENGTH_MAX))
    {
      /* SDO block size error */
      fid = FID_CAN_SDO_SZ;
      failureParam[failureParamNb] = param.blkSdoSize; /* received block length */
      failureParamNb++;
    }
    else if (nBytes != expectedParamLength)
    {
      /* again: data length of TC not correct, therefore send Discrepancy failure id */
      fid = FID_LENGTH_DISCREP;
      
      failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
      failureParamNb++;
      failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
      failureParamNb++;
    }
   
    else
    {
      /* retrieve the data bytes */
      ByteStream_readBytes(&bs, param.blkSdoSize, blkData[param.bus%ROV_CANBUS_NUM]);
    
      /* Other parameters are checked inside CAN API => no need to pre-check here
       * Then 
       * - invoke CAN API services
       * - convert result to ICD FID
       */
      coApiSts = CanApis_startBlockDownloadSdoIdx(param.bus, nodeId, param.objIdx,
                                       param.blkSdoSize, blkData[param.bus%ROV_CANBUS_NUM], &param.reqNum);
      
      if (coApiSts == E_CANAPI_OK)
      {
        /* wait the end of the handling:
         * Note: RT_RELAX is different from 1 only when the instrumented version 
         * is used for code coverage purpose
         */
        param.timeoutCycle = CO_CYCLE_IN_1SEC * SDO_BLOCK_DFL_TIMEOUT_SECONDS * RT_RELAX;
        coApiSts = CanApis_getBlockDownloadSdoExec(param.bus, param.reqNum, nodeId,
                                                   param.objIdx, param.timeoutCycle);
      }
      
      fid = CanOpenTc_apiStsToFid (coApiSts, &param, &failureParamNb, &failureParam[0]);
    }
  }
  
  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }
  
  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/*****************************************************************************/
/** @brief CanOpenTc_startBlkSdoUloadExec - Implements the TC(2,131) execution
 * 
 * This function requests to execute a CANopen Block SDO upload transfer with a 
 * slave node present on the CAN bus. The request is submitted to CAN manager 
 * after successful checking of input parameters.
 * 
 * When the transfer is effectively performed, the exchanges with the SDO
 * server is analysed to build the execution report. The Block SDO Upload report
 * TM(2,132) is generated when a correct exchange for a upload command is performed.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning
 * - This TC is allowed for the slave nodes present on the Bus using their Base Node ID,
 * - The Object index provided in the TC for the transfer is applied, regardless
 *   of the object index assigned to node for block transfer,
 * - the TM (2,132) can be only generated when a correct response to a upload
 *   command is received,
 * - The Data Size specified in TC shall conform to the Definition in the relevant
 *   Object Dictionary. Otherwise, no TM(2,132) will be generated,
 * - This TC must be handled with care, as it allows performing dump on slave nodes
 *   that normally are requested by a Buffer Support PDO message.
 *
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0150
 * - SRS.DMS.S2.CMD.0160
 * - SWICD.CSW.TC(2,131).FMT.0010
 * - SWICD.CSW.TC(2,131).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,131).CHK.0010[2] [FID_CAN_BUS_ID]
 * - SWICD.CSW.TC(2,131).CHK.0010[3] [FID_CAN_NODE]
 * - SWICD.CSW.TC(2,131).CHK.0010[4] [FID_CAN_OD_IDX]
 * - SWICD.CSW.TC(2,131).CHK.0010[5] [FID_CAN_SDO_SZ]
 * - SWICD.CSW.TC(2,131).CHK.0010[6] [FID_CAN_IO_ERR]
 * - SWICD.CSW.TM(2,132).FMT.0010
 */
PRIVATE void CanOpenTc_startBlkSdoUloadExec(const U16 *pTc, const U32 *pData, U32 nBytes)
{ 
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  CanApiRet coApiSts;
  Uint fid = NO_FAILURE;
  ByteStream bs;
  U32 expectedParamLength;
  U32 failureParamNb;
  CanTcParam param;
  U32 tmSize;
  CanTmSdoBlkUlReport *pReport;
  U32 *pTmPacket;
  CoCtx *pCtx;
  
  /* check TC parameter length: Bus ID + Node ID + OD Idx + nBytes + data */
  failureParamNb = 0;
  
  /* check size for the first part of the TC: Bus + Node + OD Idx + BlockSize */
  expectedParamLength = sizeof(U08) + sizeof(U08) + sizeof(U16) + sizeof(U16);
  
  if (nBytes != expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    /* extract all TC parameters */
    ByteStream_init(&bs, (Object *) pData, nBytes);
    
    memset (&param, 0, sizeof(CanTcParam));
    param.bus       = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.node      = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.objIdx    = (U16) ByteStream_readUnsigned(&bs, sizeof(U16));
    param.blkSdoSize = (U16) ByteStream_readUnsigned(&bs, sizeof(U16));
    
    /* only one executing TC on a Bus possible by S2 */
    pCtx = &CoMgr_ctx[param.bus%ROV_CANBUS_NUM];
    pCtx->tcCount++;
    
    if (IS_OUTSIDE(param.blkSdoSize,1,CO_SDO_BLK_DATA_LENGTH_MAX))
    {
      /* SDO block size error */
      fid = FID_CAN_SDO_SZ;
      failureParam[failureParamNb] = param.blkSdoSize; /* received block length */
      failureParamNb++;
    }
   
    else
    {
      /* Other parameters are checked inside CAN API => no need to pre-check here
       * Then 
       * - invoke CAN API services
       * - convert result to ICD FID
       */
      
      /* record the request */
      coApiSts = CanApis_startBlockUploadSdoIdx(param.bus, param.node, param.objIdx,
                                                param.blkSdoSize, &param.reqNum);
      if (coApiSts == E_CANAPI_OK)
      {
        /* wait the end of the handling 
         * Note: RT_RELAX is different from 1 only when the instrumented version 
         * is used for code coverage purpose
         */
        param.timeoutCycle = CO_CYCLE_IN_1SEC * SDO_BLOCK_DFL_TIMEOUT_SECONDS * RT_RELAX;
        coApiSts = CanApis_getBlockUploadSdoExec(param.bus, param.reqNum, param.node, param.objIdx,
          blkData[param.bus%ROV_CANBUS_NUM], param.timeoutCycle);
        
        if (coApiSts == E_CANAPI_OK)
        {
          
          /* build the TM */
          /* allocate the memory block for TM packet
           * If memory can not be allocated the alloc
           * functions assume that the TM is lost
           */
          tmSize = CAN_SDO_BLK_REPORT_TM_HEADER_SIZE + param.blkSdoSize;
          pTmPacket = cdhsTmPusAlloc(SVC_TYPE_DEVICE_COMMANDING,
                                     SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_SDO_BLK_UPL_REPORT,
                                     tmSize);

          /* %COVER%FALSE% Defensive programming:
           * case when an unexpected allocation error 
           * ERROR_REPORT is invoked
           */          
          if (pTmPacket != NULL_VOID_PTR)
          {
            /* get the data pointer for the TC specific data */
            pReport = (CanTmSdoBlkUlReport *) GET_TM_PUS_DATA_PTR(pTmPacket);
          
            /* build the TM packet within allocated TM buffer */
            pReport->bus = param.bus;
            pReport->node = param.node;
            pReport->objIdx = param.objIdx;
            pReport->dataSize = param.blkSdoSize;
            memcpy (((U08 *)pReport)+CAN_SDO_BLK_REPORT_TM_HEADER_SIZE,
                     blkData[param.bus%ROV_CANBUS_NUM], param.blkSdoSize);

            /* send the TM packet */
            cdhsTmSendPusPacket(SYSTEM_PID, E_TABLE_CAT, E_STANDALONE_PKT, GET_SOURCE_ID(pTc), pTmPacket);
            pCtx->tmCount++;
          }
        } /* request execution OK */
      } /* request recortding OK */
      fid = CanOpenTc_apiStsToFid (coApiSts, &param, &failureParamNb, &failureParam[0]);
    } /* parameter extraction and checking OK */
    
  }
  
  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }
  
  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/*****************************************************************************/
/** @brief CanOpenTc_sendNmtCmdExec - Implements the TC(2,133) execution
 * 
 * This function submits a request to send a CANopen NMT command to the master
 * or a slave node on the CAN bus. After checking input parameters, the request
 * is submitted, and an execution success report is generated.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning
 * - The execution success report is generated as soon as the request to the CAN 
 *   bus Manager is recorded, i.e. without waiting for the effective command sending,
 * - Any base node ID can be used, even if the node is not present in the pre-defined
 *   node list.
 * 
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0180
 * - SRS.DMS.S2.CMD.0185 [NMT Request queued]
 * - SWICD.CSW.TC(2,133).FMT.0010
 * - SWICD.CSW.TC(2,133).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,133).CHK.0010[2] [FID_CAN_BUS_ID]
 * - SWICD.CSW.TC(2,133).CHK.0010[3] [FID_CAN_NMT_CS]
 * - SWICD.CSW.TC(2,133).CHK.0010[4] [FID_CAN_NODE]
 * - SWICD.CSW.TC(2,133).CHK.0010[5] [FID_CAN_IO_ERR]
 */
PRIVATE void CanOpenTc_sendNmtCmdExec(const U16 *pTc, const U32 *pData, U32 nBytes)
{ 
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  CanApiRet coApiSts;
  Uint fid = NO_FAILURE;
  ByteStream bs;
  U32 expectedParamLength;
  U32 failureParamNb;
  CanTcParam param;
  CoCtx *pCtx;
  
  /* check TC parameter length: Bus ID + Command + Node ID  */
  failureParamNb = 0;
  expectedParamLength = sizeof(U08) + sizeof(U08) + sizeof(U08);
  if (nBytes != expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    /* read and check TC parameters */
    ByteStream_init(&bs, (Object *) pData, nBytes);
    
    memset (&param, 0, sizeof(CanTcParam));
    param.bus     = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.cmdSpec = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    param.node    = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    
    /* only one executing TC on a Bus possible by S2 */
    pCtx = &CoMgr_ctx[param.bus%ROV_CANBUS_NUM];
    pCtx->tcCount++;
        
    /*
     * perform checking on parameters that are not checked in CAN API with the same criteria
     * - CCS code: specific FID 
     * - Node ID: master forbidden
     */
    
    if (!CO_NMT_CMD_VALID(param.cmdSpec))
    {
      /* this parameter is checked here to get specific FID */
      fid = FID_CAN_NMT_CS;
      
      failureParam[failureParamNb] = param.cmdSpec; /* received CS */
      failureParamNb++;
    }
    else if (!CO_BASE_NODE_VALID(param.node))
    {
      /* this parameter is checked here to get specific FID */
      fid = FID_CAN_NODE;
      failureParam[failureParamNb] = param.node;
      failureParamNb++;
    }
    else
    {
      /* Other parameters are checked inside CAN API => no need to pre-check here
       * Then 
       * - invoke CAN API service 
       * - convert result to ICD FID
       */
      if (param.node == CANOPEN_NODE_MASTER)
      {
        coApiSts = CanApis_sendNmt(param.bus, param.node, param.cmdSpec); 
      }
      else
      {
        coApiSts = CanApis_sendNmtSlv(param.bus, param.node, param.cmdSpec, FALSE);
      }
      
      fid = CanOpenTc_apiStsToFid (coApiSts, &param, &failureParamNb, &failureParam[0]);
    }
  }
  
  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }
  
  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/*****************************************************************************/
/** @brief CanOpenTc_switchPayloadBusExec - Implements the TC(2,134) execution
 * 
 * This telecommand requests to send a command to perform a Bus Switch on payload
 * bus. Once the request submitted, it generates an execution success report.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning
 * - The execution success report is generated as soon as the request to the CAN 
 *   bus Manager is recorded, i.e. without waiting for the effective command sending.
 *
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * @return N/A
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0190
 * - SWICD.CSW.TC(2,134).FMT.0010
 * - SWICD.CSW.TC(2,134).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,134).CHK.0010[2] [FID_CAN_IO_ERR]
 */
PRIVATE void CanOpenTc_switchPayloadBusExec(const U16 *pTc, const U32 *pData, U32 nBytes)
{ 
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  CanApiRet coApiSts;
  Uint fid = NO_FAILURE;
  U32 expectedParamLength;
  U32 failureParamNb;
  CanTcParam param;
  CoCtx *pCtx;
  
  /* only one executing TC on a Bus possible by S2 */
  pCtx = &CoMgr_ctx[CANBUS_ID_PL];
  pCtx->tcCount++;
  
  /* check TC parameter length: None parameter */
  PARAM_NOT_USED(pData);
  failureParamNb = 0;
  expectedParamLength = 0;
  
  if (nBytes != expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    coApiSts = CanApis_forcePayloadBusSwitch();
    fid = CanOpenTc_apiStsToFid (coApiSts, &param, &failureParamNb, &failureParam[0]);
  }
  
  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }
  
  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/***********************************************************************/
/**
 * @brief CanOpenTc_apiStsToFid - convert the status of CANOpen API to FID 
 *  
 * This function converts the status of CANOpen API to FID and an associated
 * parameter.
 * 
 * @param[in] coApiStatus         The status returned by CAN API
 * @param[in] pParam              The buffer contains the TC parameters
 * @param[in,out] pNFailureParams The buffer contains the current Failure Param number,
 * @param[out] pFailureParam      The buffer to contain parameter related to FID
 * @return - @link NO_FAILURE @endlink or
 *          - other FID code
 * 
 ***********************************************************************/ 
PRIVATE U32 CanOpenTc_apiStsToFid (CanApiRet coApiStatus, CanTcParam *pParam, U32 *pNFailureParams, U32 *pFailureParam)
{
  U32 fid;
  
  /* convert result to ICD FID */
  switch (coApiStatus)
  {
  /* no failure */
  case E_CANAPI_OK:
    fid = NO_FAILURE;
    break; 
    
  /* for all FIDs, set FID parameters and increment number of parameters */
    
  case E_CANAPI_BUS_ID_ERROR:
    fid = FID_CAN_BUS_ID;
    *pFailureParam = pParam->bus;
    (*pNFailureParams)++;
    break;
    
  case E_CANAPI_NODE_ID_ERROR:
  case E_CANAPI_NOT_BASE_NODE:
  case E_CANAPI_NODE_ID_UNKNOWN:
    fid = FID_CAN_NODE;
    *pFailureParam = pParam->node;
    (*pNFailureParams)++;
    break;
    
  case E_CANAPI_OD_IDX_ERROR:
    fid = FID_CAN_OD_IDX;
    *pFailureParam = pParam->objIdx;
    (*pNFailureParams)++;
    break;
    
  case E_CANAPI_OD_SUB_IDX_ERROR:
    fid = FID_CAN_OD_SUB;
    *pFailureParam = pParam->objSubIdx;
    (*pNFailureParams)++;
    break;
        
  case E_CANAPI_SERVICE_TIMEOUT:
  case E_CANAPI_TOO_MANY_PENDING_CMD:
    fid = FID_CAN_IO_ERR;
    *pFailureParam = E_CAN_IO_TIMEOUT;
    (*pNFailureParams)++;
    break;
  case E_CANAPI_TRANSFER_ABORT:
    fid = FID_CAN_IO_ERR;
    *pFailureParam = E_CAN_IO_ABORTED;
    (*pNFailureParams)++;
    break;
    
  case E_CANAPI_DATA_SIZE_ERROR: /* already checked */
    /* %COVER%STMT% Defensive programming:
     * case when an unexpected error occurred
     * ERROR_REPORT is invoked
     */
  case E_CANAPI_DATA_BUFFER_INVALID: /* already checked */
    /* %COVER%STMT% Defensive programming:
     * case when an unexpected error occurred
     * ERROR_REPORT is invoked
     */
  case  E_CANAPI_PARAMETER_ERROR: /* already checked */
    /* %COVER%STMT% Defensive programming:
     * case when an unexpected error occurred
     * ERROR_REPORT is invoked
     */
    
  default: 
    /* %COVER%STMT% Defensive programming:
     * case when an unexpected error occurred
     * ERROR_REPORT is invoked
     */
    fid = FID_CAN_IO_ERR;
    *pFailureParam = E_CAN_IO_TIMEOUT;
    (*pNFailureParams)++;
    ERROR_REPORT(SW_ERROR, pParam->bus, pParam->node, coApiStatus);
    break;
  }
  /* return converted FID to caller */
  return fid;
}

/***********************************************************************/
/**
 * @brief CanOpenTc_handleExpeditedUpload - perform SDO expedited upload
 * operation  
 *  
 * @param[in] pTc                 The Pointer to the header of the TC
 * @param[in] pParam              The The buffer contains the TC parameters
 * @param[in,out] pNFailureParams The buffer contains the current Failure Param number,
 * @param[out] pFailureParam      The buffer to contain parameter related to FID
 * @return - @link NO_FAILURE @endlink or
 *          - other FID code
 * 
 ***********************************************************************/ 
PRIVATE U32 CanOpenTc_handleExpeditedUpload (U16 *pTc, CanTcParam *pParam, U32 *pNFailureParams, U32 *pFailureParam)
{
  
  Uint fid = NO_FAILURE;
  CanApiRet coApiSts;
  U08 expdtData[CANOPEN_SDO_DATA_LENGTH];
  U32 expectedRespHd;
  U32 respHd;
  U32 *pTmPacket;
  CanTmSdoExpdtUlReport *pReport;
  
  coApiSts = CanApis_startExpeditedUploadSdoCnt(pParam->bus, pParam->node, pParam->objIdx,
                                                pParam->objSubIdx, &pParam->reqNum);
  if (coApiSts == E_CANAPI_OK)
  {
    coApiSts = CanApis_extractExpeditedSdoResp(pParam->bus, pParam->node, FALSE,
                                               pParam->timeoutCycle, pParam->reqNum, expdtData);

    if (coApiSts == E_CANAPI_OK)
    {
      /* check received message "header" */
      expectedRespHd = BUILD_SDO_EXPDT_UL_RESP_HD(pParam->objIdx, pParam->objSubIdx);
      memcpy (&respHd, expdtData, sizeof(U32));
      
      /* check received message error: expected checked by SDO Manager */
      /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
      if ((respHd&SDO_EXPDT_UL_RESP_HD_MSK) != expectedRespHd)
      {
        ERROR_REPORT(SW, pParam->bus, respHd, expectedRespHd);
        fid = FID_CAN_IO_ERR;
        pFailureParam[*pNFailureParams] = E_CAN_IO_PROT_ERROR;
        (*pNFailureParams)++;
      }
      else
      {
        /* check s field and get the data byte counter (CAN open Standard) */
        if (expdtData[0] & 1)
        {
          pParam->expdtSdoSize = CANOPEN_SDO_EXPDT_DATA_MAX -
                               ((expdtData[0] >> SHF_2BIT) & U02_MAX);
        }
        else
        {
          pParam->expdtSdoSize = 0; /* unspecified data byte counter, ref to the OD */
        }
        
        /* build the TM */
        /* allocate the memory block for TM packet
         * If memory can not be allocated the alloc
         * functions assume that the TM is lost
         */
        pTmPacket = cdhsTmPusAlloc(SVC_TYPE_DEVICE_COMMANDING,
                                   SVC_SUBTYPE_DEVICE_COMMANDING_DEV_CMD_CAN_SDO_EXP_REPORT,
                                   CAN_SDO_EXPDT_REPORT_TM_SIZE);
        
        /* %COVER%FALSE% Defensive programming:
         * case when an unexpected allocation error 
         * ERROR_REPORT is invoked
         */
        if (pTmPacket != NULL_VOID_PTR)
        {
          /* get the data pointer for the TC specific data */
          pReport = (CanTmSdoExpdtUlReport *) GET_TM_PUS_DATA_PTR(pTmPacket);
        
          /* build the TM packet within allocated TM buffer */
          pReport->bus = pParam->bus;
          pReport->node = pParam->node;
          pReport->objIdx = pParam->objIdx;
          pReport->objSubIdx = pParam->objSubIdx;
          pReport->dataSize = pParam->expdtSdoSize;
          memcpy (pReport->data, &expdtData[CANOPEN_SDO_EXPDT_DATA_OFFSET], CANOPEN_SDO_EXPDT_DATA_MAX);
          
          /* send the TM packet */
          cdhsTmSendPusPacket(SYSTEM_PID, E_TABLE_CAT, E_STANDALONE_PKT, GET_SOURCE_ID(pTc), pTmPacket);
        }
      }
    }
    else
    {
      fid = CanOpenTc_apiStsToFid (coApiSts, pParam, pNFailureParams, pFailureParam);
    }
  }
  else
  {
    fid = CanOpenTc_apiStsToFid (coApiSts, pParam, pNFailureParams, pFailureParam);
  }
  
  return fid;
}

/***********************************************************************/
/**
 * @brief CanOpenTc_handleExpeditedDownload -  perform SDO expedited upload
 * operation
 * 
 * @param[in] pParam              The buffer contains the TC parameters
 * @param[in,out] pNFailureParams The buffer contains the current Failure Param number,
 * @param[out] pFailureParam      The buffer to contain parameter related to FID
 * @return - @link NO_FAILURE @endlink or
 *          - other FID code 
 ***********************************************************************/ 
PRIVATE U32 CanOpenTc_handleExpeditedDownload (CanTcParam *pParam, U32 *pNFailureParams, U32 *pFailureParam)
{
  
  Uint fid = NO_FAILURE;
  CanApiRet coApiSts;
  
  U08 expdtData[CANOPEN_SDO_DATA_LENGTH];
  U32 expectedRespHd;
  U32 respHd;
  
  if (IS_OUTSIDE(pParam->expdtSdoSize,CANOPEN_SDO_EXPDT_DATA_MIN,CANOPEN_SDO_EXPDT_DATA_MAX))
  {
    /* this parameter is checked here to get specific FID */
    fid = FID_CAN_SDO_SZ;
    pFailureParam[*pNFailureParams] = pParam->expdtSdoSize; /* received data size */
    (*pNFailureParams)++;
  }
  else
  {
    /* Other parameters are checked inside CAN API => no need to pre-check here
     * Then 
     * - invoke CAN API services
     * - convert result to ICD FID
     */
    coApiSts = CanApis_startExpeditedDownloadSdoCnt(pParam->bus, pParam->node, pParam->objIdx,
                                                    pParam->objSubIdx, pParam->expdtSdoSize,
                                                    pParam->expdtSdoData, &pParam->reqNum);
    if (coApiSts == E_CANAPI_OK)
    {
      coApiSts = CanApis_extractExpeditedSdoResp(pParam->bus, pParam->node, TRUE,
                                                 pParam->timeoutCycle, pParam->reqNum, expdtData);
      if (coApiSts == E_CANAPI_OK)
      {
        /* check received message "header": expected checked by SDO Manager */
        expectedRespHd = BUILD_SDO_EXPDT_DL_RESP_HD(pParam->objIdx, pParam->objSubIdx);
        memcpy (&respHd, expdtData, sizeof(U32));
       
        /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
        if (respHd != expectedRespHd)
        {
          ERROR_REPORT(SW, pParam->bus, respHd, expectedRespHd);
          fid = FID_CAN_IO_ERR;
          pFailureParam[*pNFailureParams] = E_CAN_IO_PROT_ERROR;
          (*pNFailureParams)++;
        }
      }
      else
      {
        fid = CanOpenTc_apiStsToFid (coApiSts, pParam, pNFailureParams, pFailureParam);
      }
    }
    else
    {
      fid = CanOpenTc_apiStsToFid (coApiSts, pParam, pNFailureParams, pFailureParam);
    }
  }
  return fid;
}

/*****************************************************************************/
/** @brief CanOpenTc_distributeRetToCanBusNode - Implements the TC(2,150) execution
 * 
 * This function distributes the generic RET to a salbe base node id.If master node 
 * is not in Operational mode, the request is postponed until the master node reaches
 * this state.If the slave node targetted is not in the list of active node declared
 * by switch mask variable, the request is discarded.In case an error is encountered,
 * an execution failure report is generated with an appropriate FID code and relevant
 * parameters.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning
 * - The execution success report is generated as soon as the request to the CAN 
 *   bus Manager is recorded, i.e. without waiting for the effective command sending,
 * - Any base node ID can be used, even if the node is not present in the pre-defined
 *   node list.
 * 
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0192
 * - SWICD.CSW.TC(2,150).FMT.0010
 * - SWICD.CSW.TC(2,150).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,150).CHK.0010[2] [FID_CAN_BUS_ID]
 * - SWICD.CSW.TC(2,150).CHK.0010[3] [FID_CAN_NODE]
 * - SWICD.CSW.TC(2,150).CHK.0010[4] [FID_CAN_IO_ERR]
 */
PRIVATE void CanOpenTc_distributeRetToCanBusNode(const U16 *pTc, const U32 *pData, U32 nBytes)
{
  Uint fid = NO_FAILURE;
  U32 failureParamNb;
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  ByteStream bs;
  U32 expectedParamLength;
  U08 bus;
  U08 node;
  CoCtx *pCtx;
  U32 status;
  
  /* check TC parameter length: Bus ID + Node ID  */
  failureParamNb = 0;
  expectedParamLength = 
      DEVICE_COMMANDING_DEV_CMD_CAN_GEN_RET_DISTIB_CAN_BUS_ID_PARAM_SIZE +
      DEVICE_COMMANDING_DEV_CMD_CAN_GEN_RET_DISTIB_CAN_NODE_ID_PARAM_SIZE;
  
  if (nBytes != expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    /* read and check TC parameters */
    ByteStream_init(&bs, (Object *) pData, nBytes);
    
    bus     = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    node    = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    
    /* only one executing TC on a Bus possible by S2 */
    pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
    pCtx->tcCount++;
    
    status = E_CANAPI_OK;
    
    switch (bus)
    {
    /* Playload */
    case CANBUS_ID_PL:
      status = CanApis_distributePayloadRet(node);
      break;
    
    /* Platform */
    case CANBUS_ID_PF:
      status = CanApis_distributePlatformRet(node);
      break;
    
    default:
      /* Bad bus Id */
      fid = FID_CAN_BUS_ID;
      failureParam[failureParamNb] = bus; /* received data length */
      failureParamNb++;
      break;
    }

    if ( (status == E_CANAPI_NODE_ID_ERROR) || (status == E_CANAPI_NODE_ID_UNKNOWN) )
    {
      /* Bad Node Id */
      fid = FID_CAN_NODE;
      failureParam[failureParamNb] = node;
      failureParamNb++;
    }
    else if (status != E_CANAPI_OK)
    {
      /* IO Error */
      fid = FID_CAN_IO_ERR;
      failureParam[failureParamNb] = E_CAN_IO_PROT_ERROR;
      failureParamNb++;
    }
  }
  
  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }
  
  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/*****************************************************************************/
/** @brief CanOpenTc_setSwitchMaskCanBus - Implements the TC(2,151) execution
 * 
 * This function updates the current redundancy switch mask of a CAN bus by 
 * removing or adding a base node id from the list of active slave nodes 
 * powered on. Node ids tagged as essential cannot be removed.
 * 
 * In case an error is encountered, an execution failure report is generated
 * with an appropriate FID code and relevant parameters.
 * 
 * @warning
 * - The execution success report is generated as soon as the request to the CAN 
 *   bus Manager is recorded, i.e. without waiting for the effective command sending,
 * - Any base node ID can be used, even if the node is not present in the pre-defined
 *   node list.
 * 
 * @param[in] pTc     The Pointer to the header of the TC
 * @param[in] pData   The Pointer to the application data field of the TC
 * @param[in] nBytes  The Size in bytes of the application data field of the TC
 * 
 * @requirements
 * - SRS.DMS.S2.CMD.0194
 * - SWICD.CSW.TC(2,151).FMT.0010
 * - SWICD.CSW.TC(2,151).CHK.0010[1] [FID_LENGTH_DISCREP]
 * - SWICD.CSW.TC(2,151).CHK.0010[2] [FID_CAN_BUS_ID]
 * - SWICD.CSW.TC(2,151).CHK.0010[3] [FID_CAN_NODE]
 * - SWICD.CSW.TC(2,151).CHK.0010[4] [FID_CAN_HB_STS]
 */
PRIVATE void CanOpenTc_setSwitchMaskCanBus(const U16 *pTc, const U32 *pData, U32 nBytes)
{
  Uint fid;
  U32 failureParamNb;
  Uint failureParam[FIDS_CANOPEN_DATA_SIZE_MAX];
  ByteStream bs;
  U32 expectedParamLength;
  U08 bus;
  U08 node;
  U16 hbStatus;
  CoCtx *pCtx;
  U32 status;
  U08 toAdd;
  U08 toRemove;

  fid      = NO_FAILURE;
  status   = E_CANAPI_OK;
  toAdd    = 0;
  toRemove = 0;

  /* check TC parameter length: Bus ID + Node ID + HB status */
  failureParamNb = 0;
  expectedParamLength =
      DEVICE_COMMANDING_DEV_CMD_CAN_SET_SWITCH_MASK_CAN_BUS_ID_PARAM_SIZE +
      DEVICE_COMMANDING_DEV_CMD_CAN_SET_SWITCH_MASK_CAN_NODE_ID_PARAM_SIZE +
      DEVICE_COMMANDING_DEV_CMD_CAN_SET_SWITCH_MASK_CAN_HB_STS_PARAM_SIZE;

  if (nBytes != expectedParamLength)
  {
    /* data length of TC not correct, therefore send Discrepancy failure id */
    fid = FID_LENGTH_DISCREP;
    failureParam[failureParamNb] = MIN_TC_LENGTH + nBytes; /* received data length */
    failureParamNb++;
    failureParam[failureParamNb] = MIN_TC_LENGTH + expectedParamLength; /* expected data length */
    failureParamNb++;
  }
  else
  {
    /* read and check TC parameters */
    ByteStream_init(&bs, (Object *) pData, nBytes);

    bus      = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    node     = (U08) ByteStream_readUnsigned(&bs, sizeof(U08));
    hbStatus = (U16) ByteStream_readUnsigned(&bs, sizeof(U16));

    /* only one executing TC on a Bus possible by S2 */
    pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
    pCtx->tcCount++;
    
    if (node == 0)
    {
      /* Bad Node Id */
      fid = FID_CAN_NODE;
      failureParam[failureParamNb] = node;
      failureParamNb++;
    }

    /* Compute the operation */
    switch (hbStatus)
    {
    case  E_CAN_HB_STS_EXP:
      toAdd    = node;
      break;

    case E_CAN_HB_STS_UNEXP:
      toRemove = node;
      break;

    default:
      /* Bad HB status */
      fid = FID_CAN_HB_STS;
      failureParam[failureParamNb] = hbStatus;
      failureParamNb++;
      break;
    }
    
    if (fid == NO_FAILURE)
    {
      status = CanApis_setRedundancyMasterMask(bus, toAdd, toRemove);
    }
    
    if (status == E_CANAPI_BUS_ID_ERROR)
    {
      /* IO Error */
      fid = FID_CAN_BUS_ID;
      failureParam[failureParamNb] = bus;
      failureParamNb++;
    }
    else if ( (status == E_CANAPI_NODE_ID_ERROR) || (status == E_CANAPI_NODE_ID_UNKNOWN) || (status == E_CANAPI_NODE_UNREMOVABLE) )
    {
      /* Bad Node Id */
      fid = FID_CAN_NODE;
      failureParam[failureParamNb] = node;
      failureParamNb++;
    }
    else if (status != E_CANAPI_OK)
    {
      ERROR_REPORT(SW_ERROR, status, toAdd, toRemove);
    }
  }

  if (fid != NO_FAILURE)
  { 
    /* failure case: send an execution failure report */
    cdhsTcExecFailure(pTc, fid, failureParam, failureParamNb);
  }
  else
  {
    /* execution OK, send an execution success report */
    cdhsTcExecSuccess(pTc);
  }

  /* free TC buffer in any case */
  cdhsTcFree(pTc);
}

/*------------------ ooOoo End of file ooOoo --------------------------*/
