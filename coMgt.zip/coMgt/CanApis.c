/* CanApis.c - CanApis body */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

/***********************************************************************/
/** 
 * @file
 * @brief CanApis.c - implementation of external services of CAN Bus
 * Interface.
 *
 * This module implements functions supporting public services
 * provided to user's application by the CANopen Managers
 *
 ***********************************************************************/

/***********************************************************************/
/**
 * @addtogroup canApi
 * @{
 *
 *  CANopen API consists in a suite of services provided to user's
 *  application. These services allows application to perform exchanges
 *  with underlying CANopen managers on Platform & Payload buses.
 *  in particular,
 *  - manage  CANopen Master's working mode,
 *  - manage slave nodes (equipments) linked to a Master,
 *  - set up and perform data exchanges (TM, TC) with slave nodes
 *    following different CANopen protocols:
 *    - PDO
 *    - expedited SDO
 *    - block SDO
 *
 *  Most of the provided API are applicable for both buses, (they have 
 *  a bus identifier parameter as input). Otherwise, the API name directly 
 *  indicates the involved bus.
 *
 *  There is no specific tasking context with the API. All of API are
 *  executed within "caller"'s context.
 *
 * @}
 */

/*---------- Standard libraries includes ------------------------------*/
#include <libc.h>

/*---------- FSW includes ---------------------------------------------*/
#include "lock/ResourceLock.h"
#include "errorLib.h"

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanApisFull.h"
#include "coMgt/CanOpenAction.h"
#include "coMgt/CanOpenMgt.h"
#include "coMgt/CanApis.h"

/*---------- Local defines & macro ------------------------------------*/

/* All possible events received by Bus manager tasks by the CAN driver :
 * 4 waiting tasks on each bus (bit 31) : need to mask other events, like the one triggering the async task */  
#define ALL_RTEMS_EVENTS (0x8000000F)

/*---------- Local types definitions ----------------------------------*/

/*---------- Definition of variables exported by the module -----------*/

/*---------- Definition of local variables and constants --------------*/

/*---------- Declarations of local functions --------------------------*/

PRIVATE U32 CanApis_distributeRet(U08 bus, U08 node);
PRIVATE U32 CanApis_getUlReqExec(U08 bus, U32 reqNum, U32 node, U32 objIdx,  U08 *pSdoData);
PRIVATE U32 CanApis_checkDlReqExec(U08 bus, U32 reqNum, U32 node, U32 objIdx);
PRIVATE void CanApis_searchSdoMessage(U32 *result, U32 avail, SdoMsgArea *pMsgArea, Bool isDownload, U32 reqNum, U08 *pData);

/*------------------ ooOoo Inline functions (if any) ooOoo ------------*/

/*------------------ ooOoo Global functions ooOoo ---------------------*/

/**
 * @addtogroup canApi
 * @{
 */
/*********************************************************************/
/**
 * @brief CanApis_assignBufferSupportPdoToSdo - assign the function of
 * "Buffer Support PDO" for an OD array to a PDO COB-ID
 *
 * This function is dedicated to assign a PDO COB-ID as "Buffer Support PDO".
 * for a slave node. It shall be called at least once before performing
 * any Block SDO upload transfer associated to a "Buffer Support PDO"
 * message. Any previous assignment is overridden. It will also be the idx of
 * the object to download unless overwritten by a dedicated API when the download is performed.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] pdoCobId  The cobId for slave TPDO
 * @param[in] idx   The OD array entry index to upload
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_COB_ID_WRONG_TYPE @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_SERVICE_UNAVAIL @endlink
 * 
 * @requirements
 * - SRS.DMS.CAN.CMD.0160 [cobId & Index assignment]
 * 
 *********************************************************************/ 
U32 CanApis_assignBufferSupportPdoToSdo(U08 bus, U16 pdoCobId, U16 idx)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  NodeStat *pNodeStat;
  Uint nodeIdx;
  U08 node;
  CobIdDesc *pCobIdDescList;
  CobIdDesc *pCobIdDesc;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check cob ID: TPDO */
  else if (!CO_TPDO_COBID_VALID(pdoCobId))
  {
    result = E_CANAPI_COB_ID_WRONG_TYPE;
  }
  /* check idx validity */
  else if (!CO_OD_IDX_VALID(idx) )  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  else
  {
    /* initial check OK, then check nodeId */
    pCtx = &CoMgr_ctx[bus];
    node = CO_NODE_TO_BASE(pdoCobId);
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    
    pCobIdDescList = CoMgr_cobIdList[pCtx->busId];
    pCobIdDesc = &pCobIdDescList[pdoCobId];
    
    if ((nodeIdx == CO_SLV_NODES_MAX) || (pCobIdDesc->nodeIdx != nodeIdx) 
        || (pCobIdDesc->rxGroup == 0))
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* BEGIN: protect the modification of nodeStat */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      
      pNodeStat = &pCtx->pNodeStat[nodeIdx];
      
      /* assign overwriting previous definition if any */
      pNodeStat->bufSupPdoCobId = pdoCobId;
      pNodeStat->bufSupPdoIdxUpl = idx;
      pNodeStat->bufSupPdoIdxDwnl = idx;
      /* END: protect the modification nodeStat */
      ResourceLock_unlock(&pCtx->lock);
    }
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_assignBufferSupportPdoToSdos - assign the function of
 * "Buffer Support PDO" for 2 OD arrays (one upload, one download) to a PDO COB-ID
 *
 * This function is dedicated to assign a PDO COB-ID as "Buffer Support PDO".
 * for a slave node. It shall be called at least once before performing
 * any Block SDO download or upload transfer associated to a "Buffer Support PDO"
 * message. Any previous assignment is overridden.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] pdoCobId  The cobId for slave TPDO
 * @param[in] dwnlIdx   The OD array entry index to download
 * @param[in] uplIdx    The OD array entry index to upload
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_COB_ID_WRONG_TYPE @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_SERVICE_UNAVAIL @endlink
 * 
 * @requirements
 * - SRS.DMS.CAN.CMD.0160 [cobId & Index assignment]
 * 
 *********************************************************************/ 
U32 CanApis_assignBufferSupportPdoToSdos(U08 bus, U16 pdoCobId, U16 dwnlIdx, U16 uplIdx)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  NodeStat *pNodeStat;
  Uint nodeIdx;
  U08 node;
  CobIdDesc *pCobIdDescList;
  CobIdDesc *pCobIdDesc;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check cob ID: TPDO */
  else if (!CO_TPDO_COBID_VALID(pdoCobId))
  {
    result = E_CANAPI_COB_ID_WRONG_TYPE;
  }
  /* check indexes validity */
  else if ((!CO_OD_IDX_VALID(dwnlIdx)) || (!CO_OD_IDX_VALID(uplIdx)) )  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  else
  {
    /* initial check OK, then check nodeId */
    pCtx = &CoMgr_ctx[bus];
    node = CO_NODE_TO_BASE(pdoCobId);
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    
    pCobIdDescList = CoMgr_cobIdList[pCtx->busId];
    pCobIdDesc = &pCobIdDescList[pdoCobId];
    
    if ((nodeIdx == CO_SLV_NODES_MAX) || (pCobIdDesc->nodeIdx != nodeIdx) 
        || (pCobIdDesc->rxGroup == 0))
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* BEGIN: protect the modification of nodeStat */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      
      pNodeStat = &pCtx->pNodeStat[nodeIdx];
      
      /* assign overwriting previous definition if any */
      pNodeStat->bufSupPdoCobId = pdoCobId;
      pNodeStat->bufSupPdoIdxUpl = uplIdx;
      pNodeStat->bufSupPdoIdxDwnl = dwnlIdx;
      
      /* END: protect the modification nodeStat */
      ResourceLock_unlock(&pCtx->lock);
    }
  }
  return result;
}
/*********************************************************************/
/**
 * @brief CanApis_assignSubIndexSDOs - Assign a Sub-Index to use when doing a SDO 
 * transfer (one upload, one download) to a particular Node
 *
 * This function is dedicated to assign a Sub-Index used when performing an SDO
 * transfer from a slave node. It shall be called if SubIndex 1 (default value) 
 * is to be updated.
 * Any previous assignment is overridden.
 *
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus         The bus identifier
 * @param[in] node        The slave base node id on this bus
 * @param[in] dwnlSubIdx  The OD array entry Sub-index to download
 * @param[in] uplSubIdx   The OD array entry Sub-index to upload
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_OD_SUB_IDX_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * 
 * @requirements
 * 
 * 
 *********************************************************************/ 
U32 CanApis_assignSubIndexSDOs(U08 bus, U08 node, U16 dwnlSubIdx, U16 uplSubIdx)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  NodeStat *pNodeStat;
  Uint nodeIdx;  

  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
     result = E_CANAPI_NODE_ID_ERROR;
  }
  /* check indexes validity */
  else if ((!CO_OD_SUB_IDX_VALID(dwnlSubIdx)) || (!CO_OD_SUB_IDX_VALID(uplSubIdx)) )  /*%RELAX<MISRA_Rule33> The macro CO_OD_SUB_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_SUB_IDX_ERROR;
  }
  else
  {
    /* initial check OK, then check nodeId */
    pCtx = &CoMgr_ctx[bus];    
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
       
    if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* BEGIN: protect the modification of nodeStat */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      
      pNodeStat = &pCtx->pNodeStat[nodeIdx];
      
      /* assign overwriting previous definition if any */      
      pNodeStat->bufSupPdoSubIdxUpl = uplSubIdx;
      pNodeStat->bufSupPdoSubIdxDwnl = dwnlSubIdx;
      
      /* END: protect the modification nodeStat */
      ResourceLock_unlock(&pCtx->lock);
    }
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_distributePayloadRet - request to send RET to a node on
 * payload bus
 *
 * The function requests sending a RET message to a slave device at payload
 * bus. The request is registered in the RET command queue of that bus.
 * 
 * The RET commands requests are handled by the Bus manager when the bus master
 * is in OPERATIONAL mode, at the end of the cycle (slot 7) before the next
 * master's SYNC message generation. All available requests till then are handled.
 * 
 * If the Bus Master is not in OPERATIONAL, any pending RET command requests
 * are discarded.
 *
 * @param[in] node  The node ID to receive RET
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0250 [Request submit]
 *
************************************************************************/ 
U32 CanApis_distributePayloadRet(U08 node)
{
   return CanApis_distributeRet(CANBUS_ID_PL, node);
}

/*********************************************************************/
/**
 * @brief CanApis_forcePayloadBusSwitch - request to toggle the Payload CAN Bus
 *
 * The service submits the request to CANopen Manager on the Payload bus
 * to restart at opposite bus, then come back to its current state
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0240 [Request submit]
 * 
 *********************************************************************/ 
U32 CanApis_forcePayloadBusSwitch(void)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  U08 cs;
  
  /* check Payload Bus master state */
  pCtx = &CoMgr_ctx[CANBUS_ID_PL];
  
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  /* check if there is room for this command (2 nmt) in pending command queue */
  if ((pCtx->mstCmdIn+1) >= (pCtx->mstCmdOut+CO_MST_CMD_QUEUE_LENGTH))
  {
    result = E_CANAPI_TOO_MANY_PENDING_CMD;
  }
  else
  {
    /* submit the request
     * first one: Switch Bus
     * second one: go back in the current state
     */  
    idx = pCtx->mstCmdIn%CO_MST_CMD_QUEUE_LENGTH;
    pCtx->mstCmdQueue[idx] = CO_SWITCH_BUS_CMD;
    pCtx->mstCmdIn++;
    
    if (pCtx->curState == E_COSTATE_OP)
    {
      cs = CANOPEN_NMT_CS_START;
    }
    
    else if (pCtx->curState == E_COSTATE_STOP)
    {
      cs = CANOPEN_NMT_CS_STOP;
    }
    else
    {
      cs = CANOPEN_NMT_CS_ENTER_PRE_OP;
    }
    
    idx = pCtx->mstCmdIn%CO_MST_CMD_QUEUE_LENGTH;
    pCtx->mstCmdQueue[idx] = cs;
    pCtx->mstCmdIn++;
  }
  
  ResourceLock_unlock(&pCtx->lock); 
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_getBusState - get the current health status of the master
 * node of the bus
 * @param[in] bus     The bus identifier
 * @param[out] pState The buffer to contain bus (master) state per CoNodeHealthSts
 * @return
 * - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0280  [state reading]
 * 
 *********************************************************************/ 
U32 CanApis_getBusState(U08 bus, U08 *pState)
{
  U32 result = E_CANAPI_OK;
  CoBusHkArea *pHk;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (INVALID_U08_PTR (pState))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    /* OK, now retrieve the framework info */
    pHk = &CoMgr_hkArea[bus];
    *pState = pHk->healthStatus;
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_getNextBlockSdoTm - retrieve the next available block SDO TM
 * of a CAN Bus
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus: bus identifier
 * @param[out] pSdoBlkDesc  The buffer to contain descriptor of the TM
 * @param[out] pTime        The buffer to contain CUC time in 4+2 format
 * @param[out] pPdoData     The buffer to contain PDO TM data
 * @param[out] pSdoData     The buffer to contain SDO TM data
 * @param[out] pAvail       The buffer to contain available TM number, including the current one 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink

 * @requirements
 * - SRS.DMS.CAN.CMD.0100 [Message reading]
 *
 *********************************************************************/ 
U32 CanApis_getNextBlockSdoTm(U08 bus, CanApiSdoBlkDesc *pSdoBlkDesc, U08 *pTime, U08 *pPdoData, U08 *pSdoData, U32 *pAvail)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Int avail;
  Int totalBlks;
  T_BOOL pSdoBlkDescInvalid;
  T_BOOL pTimeInvalid;
  T_BOOL pSdoDataInvalid;
  T_BOOL pAvailInvalid;
  T_BOOL pPdoDataInvalid;

  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;

  pSdoBlkDescInvalid = INVALID_U08_PTR (pSdoBlkDesc);
  pTimeInvalid = INVALID_U08_PTR (pTime);
  pSdoDataInvalid = INVALID_U08_PTR (pSdoData);
  pAvailInvalid = INVALID_U08_PTR (pAvail);
  pPdoDataInvalid = INVALID_U08_PTR (pPdoData);
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check data pointers */
  else if ((pSdoBlkDescInvalid == TRUE) ||
           (pTimeInvalid == TRUE)       ||
           (pSdoDataInvalid == TRUE)    ||
           (pAvailInvalid == TRUE)      ||
           (pPdoDataInvalid == TRUE     ))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    pCtx = &CoMgr_ctx[bus];
    
    /* OK, now retrieve the next Block SDO TM of the SDO TM queue  */
    pSdoBlkBus = pCtx->pSdoBlkTmArea;
    totalBlks = pSdoBlkBus->blks;
    
    /* Beginning of protection area */
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
    
    /* check if new block has been recorded */
    avail = pSdoBlkBus->written - pSdoBlkBus->read;
    if (avail <= 0)
    {
      avail = 0;
    }
    else
    {
      /* check if there had been an over-written */
      if (avail > totalBlks)
      {
        /* discard over-written messages */
        avail = totalBlks;
        pSdoBlkBus->read = pSdoBlkBus->written - totalBlks;
      }

      pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->read%totalBlks];
      
      /* build up descriptor */
      if (pTmRecord->status == OK)
      {
        pSdoBlkDesc->status = CAN_API_STATUS_OK;
      }
      else
      {
        pSdoBlkDesc->status = CAN_API_STATUS_ABORTED;
      }
      
      pSdoBlkDesc->node = pTmRecord->node;
      pSdoBlkDesc->blks = pTmRecord->blks;
      pSdoBlkDesc->curBlk = pTmRecord->curBlk;
      
      /* retrieve CUC time */
      memcpy (pTime, pTmRecord->cucCoarse, CO_CUC_COARSE_FIELD_LENGTH);
      memcpy (pTime+CO_CUC_COARSE_FIELD_LENGTH, pTmRecord->cucFine, CO_CUC_FINE_FIELD_LENGTH);
      
      /* get the pdo data */
      memcpy (pPdoData, &pTmRecord->pdoData, sizeof(CoBufSupPdo));
      
      /* getBlock SDO TM */
      memcpy (pSdoData, pTmRecord->data, pTmRecord->nBytes);
      pSdoBlkBus->read++;
    }      
    *pAvail = avail;

    /* End of protection area */
    ResourceLock_unlock(&pCtx->lock);
  }
  return result;
}
/*********************************************************************/
/**
 * @brief CanApis_getNextExpeditedSdoMsg - retrieve the next available expedited SDO message
 * of a node on a CAN Bus
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus     The bus identifier
 * @param[in] node    The slave base node id on this bus
 * @param[out] pTime  The buffer to contain CUC time in 4+2 format
 * @param[out] pData  The buffer to contain the extracted message 
 * @param[out] pAvail The buffer to contain available TM number, including the current one 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0110 [message reading]
 *
 *********************************************************************/ 
U32 CanApis_getNextExpeditedSdoMsg(U08 bus, U08 node, U08 *pTime, U08 *pData, U32 *pAvail)
{
  U32 result = E_CANAPI_OK;

  CoCtx *pCtx;
  Uint nodeIdx;
  SdoMsgArea *pMsgArea;
  CoSdoMsgRecord *pMsgRecord;
  Int avail;
  T_BOOL pTimeInvalid;
  T_BOOL pDataInvalid;
  T_BOOL pAvailInvalid;
  
  pTimeInvalid = INVALID_U08_PTR (pTime);
  pDataInvalid = INVALID_U08_PTR (pData);
  pAvailInvalid = INVALID_U08_PTR (pAvail);

  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  /* check data pointers */
  else if ((pTimeInvalid == TRUE) || (pDataInvalid == TRUE) ||
           (pAvailInvalid == TRUE))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    *pAvail = 0;
    /* check Slave Node ID for the bus */
    pCtx = &CoMgr_ctx[bus];
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    if (nodeIdx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* OK, now retrieve the next SDO message of the SDO queue  */
      pMsgArea = &pCtx->pSdoMsgArea[nodeIdx];
      
      /* Beginning of protection area */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      
      /* check if new msg has been recorded */
      avail = pMsgArea->written - pMsgArea->read;
      if (avail <= 0)
      {
        avail = 0;
      }
      else
      {
        /* check if there had been an over-written */
        if (avail > CO_SDO_MSG_PER_NODE)
        {
          /* discard over-written messages */
          avail = CO_SDO_MSG_PER_NODE;
          pMsgArea->read = pMsgArea->written - CO_SDO_MSG_PER_NODE;
        }
        
        pMsgRecord = &pMsgArea->msgQueue[pMsgArea->read%CO_SDO_MSG_PER_NODE];
        memcpy (pData, pMsgRecord->data, CANOPEN_SDO_DATA_LENGTH);
        memcpy (pTime, pMsgRecord->cucCoarse, CO_CUC_COARSE_FIELD_LENGTH);
        memcpy (pTime+CO_CUC_COARSE_FIELD_LENGTH, pMsgRecord->cucFine, CO_CUC_FINE_FIELD_LENGTH);
        
        pMsgArea->read++;
      } 
      *pAvail = avail;
        
      /* End of protection area */
      ResourceLock_unlock(&pCtx->lock);
    }    
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_getNextPdoTm - retrieve the next available PDO acquisition
 * of a cobId on a CAN Bus
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus         The bus identifier
 * @param[in] cobId       The COB-ID of a slave TPDO to retrieve 
 * @param[out] pTime      The buffer to contain CUC time in 4+2 format
 * @param[out] pData      The buffer to contain TM data
 * @param[out] pDataBytes The buffer to contain TM data size
 * @param[out] pAvail     The buffer to contain available TM number, including the current one 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_COB_ID_WRONG_TYPE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0080 [TM reading]
 *
 *********************************************************************/ 
U32 CanApis_getNextPdoTm(U08 bus, U16 cobId, U08 *pTime, U08 *pData, U08 *pDataBytes, U32 *pAvail)
{
  U32 result = E_CANAPI_OK;

  CoCtx *pCtx;
  CobIdDesc *pCobIdDescList;
  CobIdDesc *pCobIdDesc;
  Uint nodeIdx;
  U08 node;
  Uint tmIdx;
  PdoTmArea *pTmCobId;
  CoPdoTmRecord *pTmRecord;
  Int avail;
  T_BOOL pTimeInvalid;
  T_BOOL pDataInvalid;
  T_BOOL pDataBytesInvalid;
  T_BOOL pAvailInvalid;
  
  pTimeInvalid = INVALID_U08_PTR (pTime);
  pDataInvalid = INVALID_U08_PTR (pData);
  pDataBytesInvalid = INVALID_U08_PTR (pDataBytes);
  pAvailInvalid = INVALID_U08_PTR (pAvail);

  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if ((pTimeInvalid == TRUE) || (pDataInvalid == TRUE) ||
          (pDataBytesInvalid == TRUE) || (pAvailInvalid == TRUE))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else if (!CO_TPDO_COBID_VALID(cobId))
  {
    result = E_CANAPI_COB_ID_WRONG_TYPE;
  }
  else
  {
    *pAvail = 0;
    
    /* initial check OK, then check nodeId */
    pCtx = &CoMgr_ctx[bus];
    node = CO_NODE_TO_BASE(cobId);
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    pCobIdDescList = CoMgr_cobIdList[pCtx->busId];
    pCobIdDesc = &pCobIdDescList[cobId];
    
    if ((nodeIdx == CO_SLV_NODES_MAX) || (pCobIdDesc->nodeIdx != nodeIdx) 
        || (pCobIdDesc->rxGroup == 0))
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else
    {
      /* initialise the data bytes parameter */
      *pDataBytes = 0;
    	
      /* OK, now retrieve the next TM of the requested PDO */
      /* Beginning of protection area */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
     
      /* get the TM buffer list for this cobId and locate one to store the current TM */
      tmIdx =  pCobIdDesc->tpdoIdx;
      pTmCobId = &pCtx->pPdoTmArea[tmIdx];

      /* check if new TM has been recorded */
      avail = pTmCobId->written - pTmCobId->read;
      
      if (avail <= 0)
      {
        avail = 0;
      }
      else
      {
        /* check if there had been an over-written */
        if (avail > CO_PDO_TM_PER_COBID)
        {
          /* discard over-written TM */
          avail = CO_PDO_TM_PER_COBID;
          pTmCobId->read = pTmCobId->written - CO_PDO_TM_PER_COBID;
        }
        pTmRecord = &pTmCobId->tmQueue[pTmCobId->read % CO_PDO_TM_PER_COBID];
         
        *pDataBytes = pTmRecord->dataSize;
        
        memcpy (pData, pTmRecord->data, pTmRecord->dataSize);
        memcpy (pTime, pTmRecord->cucCoarse, CO_CUC_COARSE_FIELD_LENGTH);
        memcpy (pTime+CO_CUC_COARSE_FIELD_LENGTH, pTmRecord->cucFine, CO_CUC_FINE_FIELD_LENGTH);

        pTmCobId->read++;
      }
      *pAvail = avail;
      
      /* End of protection area */
      ResourceLock_unlock(&pCtx->lock); 
    }    
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_getNodeState - get the state of a device node
 *
 * @param[in] bus     The bus identifier
 * @param[in] node    The master or slave base node id
 * @param[out] pState The buffer to contain returned state as per the structure %link CoState %endlink
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0220 [state reading]
 *
 *********************************************************************/ 
U32 CanApis_getNodeState(U08 bus, U08 node, U32 *pState)
{
  U32 result = E_CANAPI_OK;
  
  CoCtx *pCtx;
  Uint idx;
  U08 hbSts;
  U32 nodeState;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base Node ID */
  else if (!CO_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NOT_BASE_NODE;
  }
  else if (INVALID_U32_PTR (pState))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    /* OK, now retrieve the state */
    pCtx = &CoMgr_ctx[bus];
    if (node == CANOPEN_NODE_MASTER)
    {
       *pState = pCtx->curState;
    }
    else
    {
      idx = pCtx->nodeToBusNodeIdx[node];
      if (idx == CO_SLV_NODES_MAX)
      {
        result = E_CANAPI_NODE_ID_UNKNOWN;
      }
      else if (pCtx->pNodeStat[idx].hbTotal)
      {
        /* convert HB state to Node State: hbSts has been checked as valid before being recorded */
        hbSts = pCtx->pNodeStat[idx].nodeState;
        if ((hbSts == CANOPEN_HB_ST_BOOT_UP) || (hbSts == CANOPEN_HB_ST_PRE_OP))
        {
          nodeState = E_COSTATE_PRE_OP;
        }
        else if (hbSts == CANOPEN_HB_ST_STOP)
        {
          nodeState = E_COSTATE_STOP;
        }
        else  /*(hbSts == CANOPEN_HB_ST_OP) */
        {
          nodeState = E_COSTATE_OP;
        }
        
        *pState = nodeState;
      }
      else
      {
        /* no HB has been received, considered as OFF */
        *pState = E_COSTATE_OFF;
      }
    }
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_registerForSyncWindowEvt - request to receive RTEMS
 *  event at the end of synchronisation windows
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus   The bus identifier
 * @param[in] rtEvt RTEMS event to be sent to notify the task
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_SERVICE_UNAVAIL @endlink
 * - @link E_CANAPI_APPLI_ALREADY_REGISTERED @endlink
 * 
 * @requirements
 * - SRS.DMS.CAN.CMD.0260 [Request recording]
 * 
 *********************************************************************/ 
U32 CanApis_registerForSyncWindowEvt(U08 bus, U32 rtEvt)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  Bool go = TRUE;
  rtems_id taskId;
  SyncWaitTask *pTask;
   
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
    go = FALSE;
  }
  
  if (go)
  {
    pCtx = &CoMgr_ctx[bus];
    /* Beginning of protection area */
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
    /* check if the list is full */
    if (pCtx->registeredTaskNum >= CO_SYNC_EVENT_APP_MAX)
    {
      result = E_CANAPI_SERVICE_UNAVAIL;
    }
    else   /* check if the the application is already registered */
    {
    
      /* retrieves the identification of the calling task */
      (void) rtems_task_ident(RTEMS_SELF,
                            RTEMS_SEARCH_LOCAL_NODE,
                            &taskId);
      pTask = pCtx->taskList;
      for (idx = 0; ((idx < pCtx->registeredTaskNum) && (go)); idx++)
      {
        if (pTask->taskId == taskId)
        {
          result = E_CANAPI_APPLI_ALREADY_REGISTERED;
          go = FALSE;
        }
        else
        {
          pTask++;
        }
      }
      /* if the task is not registered, do it */
      if (go)
      {
        pTask->taskId = taskId;
        pTask->waiting = FALSE;
        pTask->rtEvt = (rtems_event_set) rtEvt;
         pTask->lastWaitCycle = pCtx->cycles;
        pCtx->registeredTaskNum++;
      }
    }
    /* End of protection area */
    ResourceLock_unlock(&pCtx->lock); 
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_sendNmt - send a NMT command to a device node 
 *
 * The function submits the NMT request for a node to the Bus manager.
 * The request is registered in master or slave command queues of each bus
 * according to the node ID. 
 * 
 * The master NMT commands are handled by the Bus manager, at a rate of
 * one command per cycle, at the first slot of the cycle.
 * 
 * A registered NMT command for master is never cleared before its handling.
 * 
 * The slave NMT commands are handled by the Bus manager, when the master is
 * in PRE_OP, OP, or STOP state. The handling, i.e. sending of requested command
 * to specified slave node, is performed at every slots in a cycle.
 * 
 * Any pending requests on a bus are discarded when the master node of the bus
 * is reset.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus   The bus identifier
 * @param[in] node  The master or slave base node id
 * @param[in] cs    The NMT command specifier
 * @return - @link E_CANAPI_OK @endlink or following error codes:
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_PARAMETER_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 * 
 * @requirements
 * - SRS.DMS.CAN.CMD.0195 [Request Submit for master & slave nodes]
 *
 *********************************************************************/ 
U32 CanApis_sendNmt(U08 bus, U08 node, U08 cs)
{
  U32 result = E_CANAPI_OK;
  Bool go = FALSE;
  CoCtx *pCtx;
  Uint idx;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base Node ID */  
  else if (!CO_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  /* check command */
  else if (!CO_NMT_CMD_VALID(cs))
  {
    result = E_CANAPI_PARAMETER_ERROR;
  }
  else
  {
    go = TRUE;
  }
  
  if (go)
  {
    /* OK, now retrieve the state */
    pCtx = &CoMgr_ctx[bus];
    
    /* for the master itself */
    if (node == CANOPEN_NODE_MASTER)
    {
      /* BEGIN: protect the modification of input command queues */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      if (pCtx->mstCmdIn >= (pCtx->mstCmdOut+CO_MST_CMD_QUEUE_LENGTH))
      {
        result = E_CANAPI_TOO_MANY_PENDING_CMD;
      }
      else
      {
        /* just put the cmd argument in the queue */
        idx = pCtx->mstCmdIn%CO_MST_CMD_QUEUE_LENGTH;
        pCtx->mstCmdQueue[idx] = cs;
        pCtx->mstCmdIn++;
      }
      /* END: protect the modification of input command queues */
      ResourceLock_unlock(&pCtx->lock);
    }
    /* for the slave */
    else
    {
      /* node check requested */
      result = CanApis_sendNmtSlv(bus, node, cs, TRUE);
    }
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_sendPdoTc - send an asynchronous message to a slave device
 *
 * The function requests sending an asynchronous message to a slave device.
 * The request is registered in the PDO command queues of each bus.
 * 
 * The PDO commands requests are handled by the Bus manager when the bus master
 * is in OPERATIONAL mode, at the end of the cycle (slot 7&8). The number
 * of the commands handled in a cycle are set by its configuration.
 * 
 * If the Bus Master is not in OPERATIONAL, any pending PDO TC command requests
 * are discarded.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] cobId     The COB-ID of a slave RPDO to update 
 * @param[in] dataBytes The data bytes of the TC
 * @param[in] pData     The data buffer 
 * @return - @link E_CANAPI_OK  @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_SIZE_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_COB_ID_WRONG_TYPE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0180 [Request submit]
 * - SRS.DMS.CAN.FUNC.0070 [Message with VAR (out)]
 * - SRS.DMS.CAN.FUNC.0160
 * - SRS.DMS.CAN.FUNC.0170
 * - SRS.DMS.CAN.FUNC.0180 [PDO TC no check on OD]
 * - SRS.DMS.CAN.FUNC.0190 [PDO TC Data Size]
 *
 *********************************************************************/ 
U32 CanApis_sendPdoTc(U08 bus, U16 cobId, U08 dataBytes, U08 *pData)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  CoMsg *pCoMsg;
  Uint idx;
  U08 node;
  CobIdDesc *pCobIdDescList;
  CobIdDesc *pCobIdDesc;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (dataBytes > CANOPEN_PDO_DATA_LENGTH_MAX)
  {
    result = E_CANAPI_DATA_SIZE_ERROR;
  }
  else if (INVALID_U08_PTR(pData))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else if (!CO_RPDO_COBID_VALID(cobId))
  {
    result = E_CANAPI_COB_ID_WRONG_TYPE;
  }
  else
  {  
    /* initial check OK, then check nodeId */
    pCtx = &CoMgr_ctx[bus];
    node = CO_NODE_TO_BASE(cobId);
    idx = pCtx->nodeToBusNodeIdx[node];
    
    pCobIdDescList = CoMgr_cobIdList[pCtx->busId];
    pCobIdDesc = &pCobIdDescList[cobId];
    
    if ((idx == CO_SLV_NODES_MAX) || (pCobIdDesc->nodeIdx != idx) 
        || (pCobIdDesc->txGroup == 0))
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else
    {
      /* BEGIN: protect the modification of PDO command queues */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      if (pCtx->pdoTcIn >= (pCtx->pdoTcOut+CO_PDO_TC_QUEUE_LENGTH))
      {
        result = E_CANAPI_TOO_MANY_PENDING_CMD;
      }
      else
      {
        /* put the cmd message in format into the queue */
        idx = pCtx->pdoTcIn%CO_PDO_TC_QUEUE_LENGTH;
        pCoMsg = &pCtx->pdoTcQueue[idx];
        
        pCoMsg->cobId = cobId;
        pCoMsg->rtr = CANOPEN_WPDO_RTR;
        pCoMsg->dataBytes = dataBytes;
        
        /* copy user's data  */
        memcpy (pCoMsg->data, pData, dataBytes);
        
        pCtx->pdoTcIn++;

      }
      /* END: protect the modification of PDO command queues */
      ResourceLock_unlock(&pCtx->lock);
    }
  } /* else */
  
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_setRedundancyMasterMask - notify non-essential Switched-On state of a node
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] toAdd     The node to add in switched-on load list
 * @param[in] toRemove  The node to remove from switched-on load list
 * @return - @link E_CANAPI_OK @endlink or following error codes:
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_PARAMETER_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_UNREMOVABLE @endlink
 * 
 * @requirements
 * - SRS.DMS.CAN.FUNC.0720
 * - SRS.DMS.CAN.CMD.0210
 * 
 *********************************************************************/ 
U32 CanApis_setRedundancyMasterMask(U08 bus, U08 toAdd, U08 toRemove)
{
  U32 result = E_CANAPI_OK;
  Bool go = TRUE;
  CoCtx *pCtx;
  Uint addIdx;
  Uint removeIdx;
  
  pCtx = NULL;
  
  /* Note: E_CANAPI_NODE_UNREMOVABLE is not anymore returned by this API 
   */
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
    go = FALSE;
  }
  /* nothing requested */
  if (((toAdd == 0) && (toRemove == 0)) || (go == FALSE))
  {
    /* nothing to do */
    go = FALSE;
  }
  else if (toAdd == toRemove)
  {
    /* nothing to do, just notify error in parameters */
    result = E_CANAPI_PARAMETER_ERROR;
    go = FALSE;
  }
  else
  {    
    pCtx = &CoMgr_ctx[bus];
  }

  /* clear index */
  addIdx = CO_SLV_NODES_MAX;
  removeIdx = CO_SLV_NODES_MAX;
  
  /* check node-to-add if is is significant */
  if (go && (toAdd != 0))
  {
    if (!CO_SLV_BASE_NODE_VALID(toAdd))
    {
      result = E_CANAPI_NODE_ID_ERROR;
      go = FALSE;
    }
    else
    {
      addIdx = pCtx->nodeToBusNodeIdx[toAdd];
      if (addIdx == CO_SLV_NODES_MAX)
      {
        result = E_CANAPI_NODE_ID_UNKNOWN;
        go = FALSE;
      }
      else if (pCtx->pNodeList[addIdx].baseNid != toAdd)
      {
        result = E_CANAPI_NOT_BASE_NODE;
        go = FALSE;
      }
    }
  } /* if (go && (toAdd != 0)) */
  
  if (go && (toRemove != 0))
  {
    if (!CO_SLV_BASE_NODE_VALID(toRemove))
    {
      result = E_CANAPI_NODE_ID_ERROR;
      go = FALSE;
    }
    else
    {
      removeIdx = pCtx->nodeToBusNodeIdx[toRemove];
      if (removeIdx == CO_SLV_NODES_MAX)
      {
        result = E_CANAPI_NODE_ID_UNKNOWN;
        go = FALSE;
      }
      else if (pCtx->pNodeList[removeIdx].baseNid != toRemove)
      {
        result = E_CANAPI_NOT_BASE_NODE;
        go = FALSE;
      }
    }
  } /* if (go && (toRemove != 0)) */
    
  if (go)
  {
    /* BEGIN: protect the modification of input command queues */
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);

    /* add (additional) node to the list: set the corresponding bit */
    if (addIdx != CO_SLV_NODES_MAX)
    {
      pCtx->nodeSwitchOnMsk |= 1 << addIdx;
    }
    /* remove (existing) node from the list: clear the corresponding bit */
    if (removeIdx != CO_SLV_NODES_MAX)
    {
      pCtx->nodeSwitchOnMsk &= ~(1 << removeIdx);
      pCtx->nodeHbRegMsk &= ~(1 << removeIdx);
    }
    /* END: protect the modification of input command queues */
    ResourceLock_unlock(&pCtx->lock);
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_startBlockDownloadSdo - request to start a SDO download on a node
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The slave base node id
 * @param[in] dataBytes The number of data bytes
 * @param[out] pData    The buffer containing data bytes 
 * 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_COB_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_DATA_SIZE_ERROR @endlink
 * - @link E_CANAPI_SERVICE_UNAVAIL @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 *********************************************************************/ 
U32 CanApis_startBlockDownloadSdo(U08 bus, U08 node, U32 dataBytes, U08 *pData)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  U16 objIdx;
  
  /* check only Bus ID/Node ID to be able to get assigned cobId */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else
  {
    /* check Slave Node ID for the bus */
    pCtx = &CoMgr_ctx[bus];
    idx = pCtx->nodeToBusNodeIdx[node];
    if (idx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[idx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    /* check if a pdoCobId & index has been assigned */
    else if (CO_NODE_TO_BASE(pCtx->pNodeStat[idx].bufSupPdoCobId) != node)
    {
      result = E_CANAPI_SERVICE_UNAVAIL;
    }
    else
    {
      /* use assigned object index for the request */
      objIdx = pCtx->pNodeStat[idx].bufSupPdoIdxDwnl;
      result = CanApis_startBlockDownloadSdoIdx(bus, node, objIdx, dataBytes, pData, NULL);
    }
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_startExpeditedDownloadSdo - send an expedited SDO download message to a slave device
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The base node of the slave device 
 * @param[in] idx       The OD index of the slave device
 * @param[in] subIdx    The OD sub-index of the slave device
 * @param[in] dataBytes The number of bytes to send 
 * @param[in] data32Bit The data word 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_OD_SUB_IDX_ERROR  @endlink
 * - @link E_CANAPI_DATA_SIZE_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 * 
 *********************************************************************/ 
U32 CanApis_startExpeditedDownloadSdo(U08 bus, U08 node, U16 idx, U08 subIdx, U08 dataBytes, U32 data32Bit)
{
  U32 result = E_CANAPI_OK;
  U32 data32BitBis;
  U08 *pData;
  
  /* change the bytes oeder */
  data32BitBis = SWAP32(data32Bit);
  
  pData = (U08 *) &data32BitBis;
  
  /* no need for request counter */
  result = CanApis_startExpeditedDownloadSdoCnt(bus, node, idx, subIdx, dataBytes, pData, NULL);

  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_startExpeditedUploadSdo - start an expedited SDO upload message to a slave device
 *
 * @param[in] bus     The bus identifier
 * @param[in] node    The base node of the slave device 
 * @param[in] idx     The OD index of the slave device
 * @param[in] subIdx  The OD sub-index of the slave device
 * @return  - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_OD_SUB_IDX_ERROR  @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 *********************************************************************/ 
U32 CanApis_startExpeditedUploadSdo(U08 bus, U08 node, U16 idx, U08 subIdx)
{
  U32 result;
  
  /* no need for request count */
  result = CanApis_startExpeditedUploadSdoCnt(bus, node, idx, subIdx, NULL);
  
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_waitForSyncWindowEvt - waiting for RTEMS event
 *  at the end of the next synchronisation windows
 * 
 * @param[in] bus             The bus identifier
 * @param[out] pElapsedCycle  The buffer to contain elapsed cycle
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_APPLI_NOT_REGISTERED @endlink
 * - @link E_CANAPI_SERVICE_UNAVAIL @endlink
 * - @link E_CANAPI_INTERNAL_ERROR @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0270 [waiting]
 *********************************************************************/ 
U32 CanApis_waitForSyncWindowEvt(U08 bus, U32 *pElapsedCycle)
{
  U32 result = E_CANAPI_ERROR;
  CoCtx *pCtx;
  Uint idx;
  Bool found = FALSE;
  rtems_id taskId;
  rtems_event_set rtEvtOut;
  SyncWaitTask *pTask;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (INVALID_U32_PTR (pElapsedCycle))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    pCtx = &CoMgr_ctx[bus];    
    found = FALSE;
    /* retrieves the identification of the calling task */
    (void) rtems_task_ident(RTEMS_SELF,
                            RTEMS_SEARCH_LOCAL_NODE,
                            &taskId);
    pTask = pCtx->taskList;
    for (idx = 0; ((idx < pCtx->registeredTaskNum) && (!found)); idx++)
    {
      if (pTask->taskId == taskId)
      {
        found = TRUE;
      }
      else
      {
        pTask++;
      }
    }
    /* if the task is identified, check the current state and wait for the event */
    if (found)
    {
      if (pCtx->curState != E_COSTATE_OP)
      {
        /* return elapsed cycle */
        *pElapsedCycle = pCtx->cycles - pTask->lastWaitCycle;
        result = E_CANAPI_SERVICE_UNAVAIL;
      }
      
      else
      {
        /* mark that the current task is waiting */
        pTask->waiting = TRUE;
        
        /* Wait for the slot activation */
        rtEvtOut = 0;
               
        (void) rtems_event_receive (pTask->rtEvt, RTEMS_WAIT|RTEMS_EVENT_ANY,
                                              RTEMS_NO_TIMEOUT, &rtEvtOut);

        /* mark the the task is no longer waiting */
        pTask->waiting = FALSE;
        
        /* return elapsed cycle */
        *pElapsedCycle = pCtx->cycles - pTask->lastWaitCycle;
        
        /* if a state transition occurred, we are no longer synchronised */
        if (pCtx->curState != E_COSTATE_OP)
        {
          result = E_CANAPI_SERVICE_UNAVAIL;
        }
        else
        {
          /* all right, update the current cycle */
          result = E_CANAPI_OK;
          pTask->lastWaitCycle = pCtx->cycles; 
        }
      } /* else: curState != E_COSTATE_OP*/
    } /* found */
    else /* if the task is not identified, mark the error */
    {
      result = E_CANAPI_APPLI_NOT_REGISTERED;
    }
  }
  return result;
}

/** @} */

/*------------------ ooOoo Reserved Global  functions ooOoo ----------------------*/

/*********************************************************************/
/**
 * @brief CanApis_distributePlatformRet - request to send RET to a node
 * on platform bus
 * 
 * The function requests sending a RET message to a slave device at platform
 * bus. The request is registered in the RET command queue of that bus.
 * 
 * The RET commands requests are handled by the Bus manager when the bus master
 * is in OPERATIONAL mode, at the end of the cycle (slot 7) before the next
 * master's SYNC message generation. All available requests till then are handled.
 * 
 * If the Bus Master is not in OPERATIONAL, any pending RET command requests
 * are discarded.
 * 
 * @param[in] node  The node ID to receive RET
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 *
************************************************************************/ 
U32 CanApis_distributePlatformRet(U08 node)
{
  return CanApis_distributeRet(CANBUS_ID_PF, node);
}

/*********************************************************************/
/**
 * @brief CanApis_getBusFrameWork - get the framework information of a bus
 *
 * @param[in] bus     The bus identifier
 * @param[out] pCycle The buffer to contain cycle number
 * @param[out] pSlot  The buffer to contain slot number in the cycle
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 *
 *********************************************************************/ 
U32 CanApis_getBusFrameWork(U08 bus, U32 *pCycle, U32 *pSlot)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  T_BOOL pCycleInvalid;
  T_BOOL pSlotInvalid;
  
  pCycleInvalid = INVALID_U32_PTR (pCycle);
  pSlotInvalid = INVALID_U32_PTR (pSlot);
 
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (pCycleInvalid ||
           pSlotInvalid)
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    /* OK, now retrieve the framework info */
    pCtx = &CoMgr_ctx[bus];
    
    *pCycle = pCtx->cycles;
    *pSlot = pCtx->slotInCycle;
    result = E_CANAPI_OK;   
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_getBusLastRxMsg - get the last RX CAN message of a bus
 *
 *
 * @param[in] bus       The bus identifier
 * @param[out] pRxMsgs  The buffer to contain the current message number
 * @param[out] pMsg     The buffer of @link CanApiMsg @endlink to hold the content of the message 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 *
 *********************************************************************/ 
U32 CanApis_getBusLastRxMsg(U08 bus, U32 *pRxMsgs, CanApiMsg *pMsg)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  T_BOOL pRxMsgsInvalid;
  T_BOOL pMsgInvalid;
  
  pRxMsgsInvalid = INVALID_U32_PTR (pRxMsgs);
  pMsgInvalid = INVALID_U16_PTR (pMsg);

  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check pointers validity */
  else if (pRxMsgsInvalid ||
           pMsgInvalid)
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    /* OK, now retrieve the framework info */
    pCtx = &CoMgr_ctx[bus];
    
    *pRxMsgs = pCtx->rxMsgs;
    
    pMsg->cobId = pCtx->lastRxMsg.cobId;
    pMsg->rtr = pCtx->lastRxMsg.rtr;
    pMsg->dataBytes = pCtx->lastRxMsg.dataBytes;
    memcpy (pMsg->data, pCtx->lastRxMsg.data, pCtx->lastRxMsg.dataBytes);   
  }
  return result;
}
/*********************************************************************/
/**
 * @brief CanApis_getNodeLastStateEvt - get the last state and event on a bus
 *
 * @param[in] bus     The bus identifier
 * @param[out] pState The buffer to contain the last state
 * @param[out] pEvt   The buffer to contain the last event
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 *
 *********************************************************************/ 
U32 CanApis_getNodeLastStateEvt(U08 bus, CoState *pState, CoEvt *pEvt)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  T_BOOL pStateInvalid;
  T_BOOL pEvtInvalid;
  
  pStateInvalid = INVALID_U32_PTR (pState);
  pEvtInvalid = INVALID_U32_PTR (pEvt);
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (pStateInvalid ||
           pEvtInvalid)
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    /* OK, now retrieve the framework info */
    pCtx = &CoMgr_ctx[bus];
    
    *pState = pCtx->lastState;
    *pEvt = pCtx->lastEvt;
    result = E_CANAPI_OK;
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_sendNmtSlv - send a NMT command to a slave node 
 *
 * The function submits the NMT request for a node to the Bus manager.
 * The request is registered slave command queues of each bus
 * according to the node ID. 
 * 
 * The slave NMT commands are handled by the Bus manager, when the master is
 * in PRE_OP, OP, or STOP state. The handling, i.e. sending of requested command
 * to specified slave node, is performed at every slots in a cycle.
 * 
 * Any pending requests on a bus are discarded when the master node of the bus
 * is reset.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The master or slave base node id
 * @param[in] cs        The NMT command specifier
 * @param[in] nodeCheck The request to check the node's presence in
 *                      the configuration list
 * @return - @link E_CANAPI_OK @endlink or following error codes:
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_PARAMETER_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 * 
 * @requirements
 * - SRS.DMS.CAN.CMD.0195 [Request Submit for Slave Node]
 *
 *********************************************************************/ 
U32 CanApis_sendNmtSlv(U08 bus, U08 node, U08 cs, Bool nodeCheck)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  CoMsg *pCoMsg;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base Node ID */  
  else if (!CO_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  /* check command */
  else if (!CO_NMT_CMD_VALID(cs))
  {
    result = E_CANAPI_PARAMETER_ERROR;
  }
  else
  {
    /* OK, now retrieve the state */
    pCtx = &CoMgr_ctx[bus];
   
    if (nodeCheck)
    {
      idx = pCtx->nodeToBusNodeIdx[node];
      if (idx == CO_SLV_NODES_MAX)
      {
        result = E_CANAPI_NODE_ID_UNKNOWN;
      }
    }
    if (result == E_CANAPI_OK)
    {
      if (pCtx->slvCmdIn >= (pCtx->slvCmdOut+CO_SLV_CMD_QUEUE_LENGTH))
      {
        result = E_CANAPI_TOO_MANY_PENDING_CMD;
      }
      else
      {
        /* BEGIN: protect the modification of input command queues */
         ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);

        /* build message in the queue */
        idx = pCtx->slvCmdIn%CO_SLV_CMD_QUEUE_LENGTH;
        pCoMsg = &pCtx->slvCmdQueue[idx];
                       
        pCoMsg->cobId = CANOPEN_COB_NMT;
        pCoMsg->rtr = CAN_MSG_RTR_DATA_FRAME;
        pCoMsg->dataBytes = CANOPEN_NMT_DATA_LENGTH;
        pCoMsg->data[CANOPEN_NMT_DATA_CS_IDX] = cs;
        pCoMsg->data[CANOPEN_NMT_DATA_NID_IDX] = node;
        
        pCtx->slvCmdIn++;
        
        /* END: protect the modification of input command queues */
        ResourceLock_unlock(&pCtx->lock);
      }
    }
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_startExpeditedDownloadSdoCnt - send an expedited SDO
 * download message to a slave device and get the request number
 *
 * The function requests starting a SDO expedited download transfer with 
 * a slave node. The request is registered in the SDO expedited download
 * command queue of each bus.
 * 
 * The SDO expedited download requests are handled by the Bus manager when
 * the bus master is in PRE-OPERATIONAL or OPERATIONAL mode. An SDO expedited
 * command could be handled in a every slot (except slot 0&9), if there
 * is no SDO block transfer ongoing in that slot.
 *
 * If the Bus Master is not in PRE-OPERATIONAL or OPERATIONAL mode, available
 * SDO expedited download requests are discarded.
 * 
 * For the Bus manager, a SDO expedited upload request has a lower priority
 * than a SDO expedited download request.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The base node of the slave device 
 * @param[in] idx       The OD index of the slave device
 * @param[in] subIdx    The OD sub-index of the slave device
 * @param[in] nBytes    The number of bytes to send 
 * @param[in] pData     The data bytes buffer
 * @param[out] pReqCnt  The buffer to store request number
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_OD_SUB_IDX_ERROR  @endlink
 * - @link E_CANAPI_DATA_SIZE_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0130 [Request submit]
 * - SRS.DMS.CAN.FUNC.0250 [Data size for expedited Download]
 *
 *********************************************************************/ 
U32 CanApis_startExpeditedDownloadSdoCnt(U08 bus, U08 node, U16 idx, U08 subIdx, U32 nBytes, U08 *pData, U32 *pReqCnt)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  CoMsg *pCoMsg;
  Uint nodeIdx;
  Uint msgIdx;
  
  /*%RELAX<GEN-005-P> There is no mixed code here. False positive from the tool. */
  static U08 expDlSdoCcs[CANOPEN_SDO_EXPDT_DATA_MAX] =
  {
    CANOPEN_SDO_CCS_EXPDT_DL_1BYTE,
    CANOPEN_SDO_CCS_EXPDT_DL_2BYTE,
    CANOPEN_SDO_CCS_EXPDT_DL_3BYTE,
    CANOPEN_SDO_CCS_EXPDT_DL_4BYTE
  };

  /* check Bus ID/NodeID/Idx/Subidx */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else if (!CO_OD_IDX_VALID(idx))  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  else if (!CO_SUB_IDX_VALID(subIdx)) 
  {
    result = E_CANAPI_OD_SUB_IDX_ERROR;
  }
  else if (!CO_SDO_EXPDT_DATA_SIZE_VALID(nBytes))
  {
    result = E_CANAPI_DATA_SIZE_ERROR;
  }
  else
  {
    /* check Slave Node ID for the bus */
    pCtx = &CoMgr_ctx[bus];
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    
    if (nodeIdx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* BEGIN: protect the modification of expedited-SDO command queues */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);

      if (pCtx->expdtSdoDlIn >= (pCtx->expdtSdoDlOut+CO_EXPDT_SDO_DL_QUEUE_LENGTH))
      {
        result = E_CANAPI_TOO_MANY_PENDING_CMD;
      }
      else
      {
        /* put the cmd message in format into the queue */
        msgIdx = pCtx->expdtSdoDlIn%CO_EXPDT_SDO_DL_QUEUE_LENGTH;
        pCoMsg = &pCtx->expdtSdoDlQueue[msgIdx].msg;
        
        pCoMsg->cobId = CANOPEN_COB_RSDO(node);
        pCoMsg->rtr = CANOPEN_SDO_RTR;
        pCoMsg->dataBytes = CANOPEN_SDO_DATA_LENGTH;
        
        /* fill in the following fields:
         * - ccs
         * - index
         * - sub index
         * - data 
         */
        pCoMsg->data[CANOPEN_SDO_CCS_OFFSET] = expDlSdoCcs[nBytes - 1];
        pCoMsg->data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET] = (U08) (idx & U08_MAX);
        pCoMsg->data[CANOPEN_SDO_CCS_INDEX_MSB_OFFSET] = (U08) ((idx>>SHF_8BIT) & U08_MAX);
        pCoMsg->data[CANOPEN_SDO_CCS_SUBIDX_OFFSET] = subIdx;

        /* copy user's data */
        memcpy (pCoMsg->data+CANOPEN_SDO_EXPDT_DATA_OFFSET, pData, nBytes);
        
        pCtx->expdtSdoDlIn++;
        
        /* save the request counter and update it */
        pCtx->expdtSdoDlReqCnt++;
        pCtx->expdtSdoDlQueue[msgIdx].reqCnt = pCtx->expdtSdoDlReqCnt;
        
        /* fill in the request counter if a valid buffer is provided */
        if (!INVALID_U32_PTR (pReqCnt))
        {
          *pReqCnt = pCtx->expdtSdoDlReqCnt;
        }
        result = E_CANAPI_OK;
      }
      /* END: protect the modification of expedited-SDO command queues */
      ResourceLock_unlock(&pCtx->lock);
    }
  }
  return result;  
}
/*********************************************************************/
/**
 * @brief CanApis_startExpeditedUploadSdoCnt - start an expedited SDO 
 * upload message to a slave device and get the request number
 *
 * The function requests starting a SDO expedited upload transfer with 
 * a slave node. The request is registered in the SDO expedited upload
 * command queue of each bus.
 * 
 * The SDO expedited upload requests are handled by the Bus manager when
 * the bus master is in PRE-OPERATIONAL or OPERATIONAL mode. An SDO expedited
 * command could be handled in a every slot (except slot 0&9), if there
 * is no SDO block transfer ongoing in that slot.
 *
 * If the Bus Master is not in PRE-OPERATIONAL or OPERATIONAL mode, available
 * SDO expedited upload requests are discarded.
 * 
 * For the Bus manager, a SDO expedited upload request has a lower priority
 * than a SDO expedited download request.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The base node of the slave device 
 * @param[in] idx       The OD index of the slave device
 * @param[in] subIdx    The OD sub-index of the slave device
 * @param[out] pReqCnt  The buffer to store request number
 * @return  - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_OD_SUB_IDX_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0120 [Request submit]
 * - SRS.DMS.CAN.FUNC.0250 [Data size for expedited upload]
 *
 *********************************************************************/ 
U32 CanApis_startExpeditedUploadSdoCnt(U08 bus, U08 node, U16 idx, U08 subIdx, U32 *pReqCnt)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  CoMsg *pCoMsg;
  U32 nodeIdx;
  U32 msgIdx;
  
  /* check Bus ID/NodeID/Idx/Subidx */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else if (!CO_OD_IDX_VALID(idx))  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  else if (!CO_SUB_IDX_VALID(subIdx)) 
  {
    result = E_CANAPI_OD_SUB_IDX_ERROR; 
  }
  else
  {
    /* check Slave Node ID for the bus */
    pCtx = &CoMgr_ctx[bus];
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
   
    if (nodeIdx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* BEGIN: protect the modification of expedited SDO upload queues */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
      
      if (pCtx->expdtSdoUlIn >= (pCtx->expdtSdoUlOut+CO_EXPDT_SDO_UL_QUEUE_LENGTH))
      {
        result = E_CANAPI_TOO_MANY_PENDING_CMD;
      }
      else
      {
        /* put the cmd message in format into the queue */
        msgIdx = pCtx->expdtSdoUlIn%CO_EXPDT_SDO_UL_QUEUE_LENGTH;
        pCoMsg = &pCtx->expdtSdoUlQueue[msgIdx].msg;
        
        pCoMsg->cobId = CANOPEN_COB_RSDO(node);
        pCoMsg->rtr = CANOPEN_SDO_RTR;
        pCoMsg->dataBytes = CANOPEN_SDO_DATA_LENGTH;
        
        /* fill in the following fields:
         * - ccs
         * - index
         * - sub index
         */
        pCoMsg->data[CANOPEN_SDO_CCS_OFFSET] = CANOPEN_SDO_CCS_EXPDT_UL;
        pCoMsg->data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET] = (U08) (idx & U08_MAX); 
        pCoMsg->data[CANOPEN_SDO_CCS_INDEX_MSB_OFFSET] = (U08) ((idx>>SHF_8BIT) & U08_MAX);
        pCoMsg->data[CANOPEN_SDO_CCS_SUBIDX_OFFSET] = subIdx;
        
        /* clear reserved field, not filled for TM request */
        memset (&pCoMsg->data[CANOPEN_SDO_EXPDT_DATA_OFFSET], 0, CANOPEN_SDO_EXPDT_DATA_MAX);
        pCtx->expdtSdoUlIn++;
        
        /* save the request counter and update it */
        pCtx->expdtSdoUlReqCnt++;
        pCtx->expdtSdoUlQueue[msgIdx].reqCnt = pCtx->expdtSdoUlReqCnt;
       
        /* fill in the request counter if a valid buffer is provided */
        if (!INVALID_U32_PTR (pReqCnt))
        {
          *pReqCnt = pCtx->expdtSdoUlReqCnt;
        }

        result = E_CANAPI_OK;
      }
      /* END: protect the modification of expedited-SDO command queues */
      ResourceLock_unlock(&pCtx->lock); 
    }
  }
  return result;
}

/*********************************************************************/
/**
 * @brief CanApis_extractExpeditedSdoResp - extract the response for an expedited SDO message
 * of a node on a CAN Bus
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus           The bus identifier
 * @param[in] node          The slave base node id on this bus
 * @param[in] isDownload    The request is download or upload 
 * @param[in] reqNum        The request number for the expedited SDO message
 * @param[in] timeoutCycle  The timeout cycles
 * @param[out] pData        The buffer to contain TM data
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_PARAMETER_ERROR @endlink
 * - @link E_CANAPI_SERVICE_TIMEOUT @endlink
 * - @link E_CANAPI_TRANSFER_ABORT @endlink
 *
 * @warning The extracted message remains in the queue unless 
 * if it is the first one in the queue.
 *
 *
 *********************************************************************/ 
U32 CanApis_extractExpeditedSdoResp(U08 bus, U08 node, Bool isDownload, U32 timeoutCycle, U32 reqNum, U08 *pData) /*%RELAX<GEN-010-PLE> Number of local variables and complexity are due to the complexity of the algorithm. */
{
  /* LOGISCOPE justification RVSW-DMS_INT-036-AST */
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint nodeIdx;
  SdoMsgArea *pMsgArea;
  U32 avail;
  U32 initCyc;
  rtems_status_code rtSts;
  
  /* check Bus ID */
  pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  /* check data pointers */
  else if (INVALID_U08_PTR (pData))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else if ((isDownload && (pCtx->expdtSdoDlReqCnt < reqNum)) ||
          ((!isDownload) && (pCtx->expdtSdoUlReqCnt < reqNum)))
  {
    result = E_CANAPI_PARAMETER_ERROR;
  }
  else
  {
    /* check Slave Node ID for the bus */
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    if (nodeIdx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      /* OK, now search the specified SDO message in the SDO queue */
      pMsgArea = &pCtx->pSdoMsgArea[nodeIdx];
      
      initCyc = pCtx->cycles;
      
      /* wait until the message is handled or timeout is reached */
      while ((( isDownload && (pCtx->expdtSdoDlReqLast < reqNum)) || 
             ((!isDownload) && (pCtx->expdtSdoUlReqLast < reqNum))) && 
             ((pCtx->cycles-initCyc) <= timeoutCycle))
      {
        /* RT_RELAX: used (!=1) only when the instrumented version is executed for code coverage purpose */
        rtSts = rtems_semaphore_obtain(pCtx->cycSyncSem, RTEMS_WAIT, CoMgr_ticksPerSecond*RT_RELAX);

        /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
        if (rtSts != RTEMS_UNSATISFIED)
        {
          ERROR_REPORT(SW, pCtx->busId, rtSts, pCtx->cycSyncSem);
        }
      }
      /* case of timeout */
      if ((pCtx->cycles-initCyc) > timeoutCycle)
      {
        result = E_CANAPI_SERVICE_TIMEOUT;
      }
      else
      {
        result = E_CANAPI_TRANSFER_ABORT;
        /* Beginning of protection area */
        ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
        
        /* check if new message has been recorded */
        avail = pMsgArea->written - pMsgArea->read;
        if (avail > 0)
        {          
          /* check if there had been an over-written */
          if (avail > CO_SDO_MSG_PER_NODE)
          {
            /* discard over-written messages */
            avail = CO_SDO_MSG_PER_NODE;
            pMsgArea->read = pMsgArea->written - CO_SDO_MSG_PER_NODE;
          }
          
          /* Search SDO message */
          CanApis_searchSdoMessage(&result, avail, pMsgArea, isDownload, reqNum, pData);
        }
        /* End of protection area */
        ResourceLock_unlock(&pCtx->lock);
      }
    }    
  }
  return result;
}


/*********************************************************************/
/**
 * @brief CanApis_startBlockDownloadSdoIdx - request to start a SDO download
 * on a slave node with a specific object index
 *
 * The function requests starting a SDO download on a slave node using a specific
 * object index. The request is registered in the SDO Block download command queue
 * of each bus.
 * 
 * The SDO Block download/upload commands requests are handled by the Bus manager when
 * the bus master is in OPERATIONAL mode. The number of the commands handled in a cycle
 * depends on the specific configuration of each bus (1 for platform, 2 for payload).
 * 
 * If the Bus Master is not in PRE-OPERATIONAL or OPERATIONAL mode, available
 * SDO download requests are discarded.
 * 
 * For the Bus manager, a SDO block upload request has a lower priority
 * than a SDO block download request. A SDO block (upload or download) request
 * has a higher priority than a a SDO expedited (upload/download) request. 
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The slave base node id
 * @param[in] objIdx    The object index to use for the transfer
 * @param[in] dataBytes The number of data bytes
 * @param[in] pData     The buffer containing data bytes 
 * @param[out] pReqCnt  The buffer to store the request number for download
 * 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_DATA_SIZE_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0200 [Request submit]
 * - SRS.DMS.CAN.FUNC.0270 [SDO Block Download Request submit]
 * 
 *********************************************************************/ 
U32 CanApis_startBlockDownloadSdoIdx(U08 bus, U08 node, U16 objIdx, U32 dataBytes, U08 *pData, U32 *pReqCnt)
{
  U32 result = E_CANAPI_OK;
  Uint idx;
  Uint nodeIdx;
  CoCtx *pCtx;
  NodeStat *pNodeStat;
  SdoBlkDlReq *pDlReq;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else if (!CO_OD_IDX_VALID(objIdx))  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  /* check data buffer */
  else if (INVALID_U08_PTR (pData)) 
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else if ((dataBytes > CO_SDO_BLK_DATA_LENGTH_MAX) || (dataBytes==0))
  {
    result = E_CANAPI_DATA_SIZE_ERROR; 
  }
  else
  {
    /* check Slave Node ID for the bus */
    pCtx = &CoMgr_ctx[bus];
    nodeIdx = pCtx->nodeToBusNodeIdx[node%CO_NODE_LIST_LENGTH];

    if (nodeIdx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[nodeIdx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    /* check if request is possible */
    else if ((pCtx->sdoDlIn - pCtx->sdoDlOut) >= pCtx->sdoDlQLength)
    {
      result = E_CANAPI_TOO_MANY_PENDING_CMD;
    }
    else
    {
      /* BEGIN: protect the modification of SDO DL queues */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
       
      /* locate the request buffer and build the current one inside */
      idx = pCtx->sdoDlIn % pCtx->sdoDlQLength;
      pDlReq = pCtx->pSdoBlkDlReq + idx;
       
      pDlReq->node = node;
      pDlReq->nBytes = dataBytes;
      pDlReq->blks = (dataBytes + CANOPEN_SDO_BLK_NBYTE_PER_SEG-1)/CANOPEN_SDO_BLK_NBYTE_PER_SEG;
      pDlReq->curBlk = 0;
       
      pCtx->sdoDlReqCnt++;
      pDlReq->reqCnt = pCtx->sdoDlReqCnt;
       
      /* use the assigned index */
      pDlReq->objIdx = objIdx;
      
      /* use the assigned subIndex */
      pNodeStat = &pCtx->pNodeStat[nodeIdx]; 
      pDlReq->objSubIdx = pNodeStat->bufSupPdoSubIdxDwnl;
      memcpy (pDlReq->data, pData, dataBytes);
       
      /* go to the next */
      pCtx->sdoDlIn++;

      /* fill in the request counter if a valid buffer is provided */
      if (!INVALID_U32_PTR (pReqCnt))
      {
        *pReqCnt = pDlReq->reqCnt;
      }
      /* END: protect the modification of SDO DL queues  */
      ResourceLock_unlock(&pCtx->lock);
    }
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_startBlockUploadSdoIdx - request to start a SDO upload
 * on a slave node with a specific object index
 *
 * The function requests starting a SDO upload on a slave node using a specific
 * object index. The request is registered in the SDO Block upload command queue
 * of each bus.
 * 
 * The SDO Block download/upload commands requests are handled by the Bus manager when
 * the bus master is in OPERATIONAL mode. The number of the commands handled in a cycle
 * depends on the specific configuration of each bus (1 for platform, 2 for payload).
 * 
 * If the Bus Master is not in PRE-OPERATIONAL or OPERATIONAL mode, available
 * SDO upload requests are discarded.
 * 
 * For the Bus manager, a SDO block upload request has a lower priority
 * than a SDO block download request. A SDO block (upload or download) request
 * has a higher priority than a a SDO expedited (upload/download) request. 
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus       The bus identifier
 * @param[in] node      The slave base node id
 * @param[in] objIdx    The object index to use for the transfer
 * @param[in] dataBytes The number of data bytes
 * @param[out] pReqCnt  The buffer to store the request number for upload
 * 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_DATA_SIZE_ERROR @endlink
 * - @link E_CANAPI_TOO_MANY_PENDING_CMD @endlink
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0270 [SDO Block Upload Request submit]
 * - SRS.DMS.CAN.FUNC.0281 [SDO Block Upload Request submit : set of configurable subIndex]
 * 
 *********************************************************************/ 
U32 CanApis_startBlockUploadSdoIdx(U08 bus, U08 node, U16 objIdx, U32 dataBytes, U32 *pReqCnt)
{
  U32 result = E_CANAPI_OK;
  Uint idx;
  CoCtx *pCtx;
  SdoBlkUlReq *pUlReq;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else if (!CO_OD_IDX_VALID(objIdx))  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  else if ((dataBytes > CO_SDO_BLK_DATA_LENGTH_MAX) || (dataBytes==0))
  {
    result = E_CANAPI_DATA_SIZE_ERROR; 
  }
  else
  {
    /* check Slave Node ID for the bus */
    pCtx = &CoMgr_ctx[bus];
    idx = pCtx->nodeToBusNodeIdx[node];
    if (idx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[idx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    /* check if request is possible */
    else if ((pCtx->sdoUlIn - pCtx->sdoUlOut) >= CO_BLK_SDO_UL_QUEUE_LENGTH)
    {
      result = E_CANAPI_TOO_MANY_PENDING_CMD;
    }
    else
    {
      /* BEGIN: protect the modification of SDO UL queues */
      ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);      
     
      pCtx->sdoUlReqCnt++;
      
      /* check OK, build the request in the queue */
      pUlReq = &pCtx->sdoBlkUlReq[pCtx->sdoUlIn%CO_BLK_SDO_UL_QUEUE_LENGTH];
       
      pUlReq->pdoReq = FALSE; /* request not used issued by PDO */
      pUlReq->node = node;
      pUlReq->objIdx = objIdx;
      pUlReq->objSubIdx = pCtx->pNodeStat[idx].bufSupPdoSubIdxUpl;
      pUlReq->nBytes = dataBytes;       
      pUlReq->reqCnt = pCtx->sdoUlReqCnt;
      pCtx->sdoUlIn++;  
      
      /* fill in the request counter if a valid buffer is provided */
      if (!INVALID_U32_PTR (pReqCnt))
      {
        *pReqCnt = pUlReq->reqCnt;
      }    
      /* END: protect the modification of SDO UL queues  */
      ResourceLock_unlock(&pCtx->lock);
    }
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_getBlockDownloadSdoExec - get the result of a specified 
 * Block SDO download request
 * 
 * This service is dedicated to be used after CanApis_startBlockDownloadSdoIdx
 * to support a TC handling
 *
 * @param[in] bus           The bus identifier
 * @param[in] reqNum        The request number of the download request
 * @param[in] node          The server node ID
 * @param[in] objIdx        The object index
 * @param[in] timeoutCycle  The timeout cycles
 * 
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_PARAMETER_ERROR @endlink
 * - @link E_CANAPI_SERVICE_TIMEOUT @endlink
 * - @link E_CANAPI_TRANSFER_ABORT @endlink
 * 
 * @requirements
 *
 *********************************************************************/ 
U32 CanApis_getBlockDownloadSdoExec(U08 bus, U32 reqNum, U32 node, U32 objIdx, U32 timeoutCycle)
{
  /* LOGISCOPE justification RVSW-DMS_INT-036-AST */
  U32 result = E_CANAPI_OK;
  Uint idx;
  CoCtx *pCtx;
  U32 initCyc;
  rtems_status_code rtSts;
  
  /* check Bus ID */
  pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  /* check Base slave Node ID */
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  /* check input parameter validity */
  else if (pCtx->sdoDlReqCnt < reqNum)
  {
    result = E_CANAPI_PARAMETER_ERROR;
  }
  else if (!CO_OD_IDX_VALID(objIdx))  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  else
  {
    idx = pCtx->nodeToBusNodeIdx[node];
    if (idx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[idx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {
      initCyc = pCtx->cycles;
      
      /* wait until the message is handled or timeout is reached */
      while ((pCtx->sdoDlReqLast < reqNum) && ((pCtx->cycles-initCyc) <= timeoutCycle))
      {
        /* RT_RELAX: used (!=1) only when the instrumented version is executed for code coverage purpose */
        rtSts = rtems_semaphore_obtain(pCtx->cycSyncSem, RTEMS_WAIT, CoMgr_ticksPerSecond*RT_RELAX);

        /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
        if (rtSts != RTEMS_UNSATISFIED)
        {
          ERROR_REPORT(SW, pCtx->busId, rtSts, pCtx->cycSyncSem);
        }
      }

      /* now, search in the response queue the one with the specified request number */
      result = E_CANAPI_SERVICE_TIMEOUT;
      if (pCtx->sdoDlReqLast >= reqNum)
      {
        result = CanApis_checkDlReqExec(bus, reqNum, node, objIdx);
      } /* (pCtx->sdoDlReqLast >= reqNum)*/
    } /* else */
  }
  return result;  
}

/*********************************************************************/
/**
 * @brief CanApis_getBlockUploadSdoExec - get the result of a specified 
 * Block SDO Upload request
 * 
 * This service is dedicated to be used after CanApis_startBlockUploadSdoIdx
 * to support a TC handling
 * 
 * @param[in] bus             The bus identifier
 * @param[in] reqNum          The request number of the upload request
 * @param[in] node            The server node ID
 * @param[in] objIdx          The object index
 * @param[out] pSdoData       The buffer to contain SDO TM data
 * @param[in] timeoutCycle    The timeout cycles
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * - @link E_CANAPI_OD_IDX_ERROR @endlink
 * - @link E_CANAPI_DATA_BUFFER_INVALID @endlink
 * - @link E_CANAPI_SERVICE_TIMEOUT @endlink
 * - @link E_CANAPI_TRANSFER_ABORT @endlink
 * 
 * @warning The extracted message remains in the queue unless if it is the first one in the queue.
 *
 *
 *********************************************************************/ 
U32 CanApis_getBlockUploadSdoExec(U08 bus, U32 reqNum, U32 node, U32 objIdx,  U08 *pSdoData, U32 timeoutCycle)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  U32 initCyc;
  rtems_status_code rtSts;
  
  /* check Bus ID */
  pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else if (!CO_OD_IDX_VALID(objIdx))  /*%RELAX<MISRA_Rule33> The macro CO_OD_IDX_VALID only reads variables; no writing is done, so no side effect is present and the rule is respected. */
  {
    result = E_CANAPI_OD_IDX_ERROR;
  }
  /* check input parameter validity */
  else if (pCtx->sdoUlReqCnt < reqNum)
  {
    result = E_CANAPI_PARAMETER_ERROR;
  }
  /* check data pointer */
  else if (INVALID_U08_PTR (pSdoData))
  {
    result = E_CANAPI_DATA_BUFFER_INVALID;
  }
  else
  {
    idx = pCtx->nodeToBusNodeIdx[node];
    if (idx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[idx].baseNid != node)
    {
      result = E_CANAPI_NOT_BASE_NODE;
    }
    else
    {   
      initCyc = pCtx->cycles;
      
      /* wait until the message is handled or timeout is reached */
      while ((pCtx->sdoUlReqLast < reqNum) && ((pCtx->cycles-initCyc) <= timeoutCycle))
      {
        /* RT_RELAX: used (!=1) only when the instrumented version is executed for code coverage purpose */
        rtSts = rtems_semaphore_obtain(pCtx->cycSyncSem, RTEMS_WAIT, CoMgr_ticksPerSecond*RT_RELAX);

        /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
        if (rtSts != RTEMS_UNSATISFIED)
        {
          ERROR_REPORT(SW, pCtx->busId, rtSts, pCtx->cycSyncSem);
        }
      }
     
      /* now, search in the response queue the one with the specified request number */
      result = E_CANAPI_SERVICE_TIMEOUT;
      /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro has been previously called just above. */
      if (pCtx->sdoUlReqLast >= reqNum)
      {
        result = CanApis_getUlReqExec(bus, reqNum, node, objIdx, pSdoData);
      } /* (pCtx->sdoUlReqLast >= reqNum) */

    } /* else */
  }
  return result;
}


/*********************************************************************/
/**
 * @brief CanApis_resetUnexpectedHb - allow new detection of unexpected HB 
 * 
 * This service is dedicated to reset the unexpected HB HK and allow new 
 * detection; it takes into account UHF case
 * 
 * @param[in] bus             The bus identifier
 * @param[in] node            The server node ID
 * @return - @link E_CANAPI_OK @endlink or error code
 * - @link E_CANAPI_BUS_ID_ERROR @endlink
 * - @link E_CANAPI_NOT_BASE_NODE @endlink
 * - @link E_CANAPI_NODE_ID_ERROR @endlink
 * - @link E_CANAPI_NODE_ID_UNKNOWN @endlink
 * 
 *
 *********************************************************************/ 
U32 CanApis_resetUnexpectedHb(U08 bus, U32 node)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  
  /* check Bus ID */
  pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
  if (!CO_BUS_ID_VALID(bus))
  {
    result = E_CANAPI_BUS_ID_ERROR;
  }
  else if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
  }
  else
  {
    idx = pCtx->nodeToBusNodeIdx[node];
    /* check the index is valid and corresponds to a base node id */
    if (idx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
    }
    else if (pCtx->pNodeList[idx].baseNid != node)
    {
       result = E_CANAPI_NOT_BASE_NODE;
    }  
    else
    {
      /* UHF case */
      if (pCtx->pNodeList[idx].isUhf != 0)
      {
        pCtx->uhfHailNode = 0;
        pCtx->uhfHailCycle = 0;
        pCtx->pNodeStat[idx].uhfHail = FALSE;
        pCtx->pNodeStat[idx].uhfHailCycle = 0;
      }
      else
      /* other cases */
      {
        pCtx->unexpHbNode = 0;
        pCtx->unexpHbCycle = 0;
      }
    }
  }
  return result;
}

/*------------------ ooOoo Local functions ooOoo ----------------------*/
/***********************************************************************/
/**
 * @brief CanApis_distributeRet - request to send RET to a node on a bus
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus   The bus identifier
 * @param[in] node  The node ID to receive RET
 * @return - E_CANAPI_OK or error code
 * - E_CANAPI_NODE_ID_ERROR
 * - E_CANAPI_NODE_ID_UNKNOWN
 * - E_CANAPI_TOO_MANY_PENDING_CMD
 * 
 * * @requirements
 * - SRS.DMS.CAN.FUNC.0640 [on-request RET distribution]
 ***********************************************************************/ 
PRIVATE U32 CanApis_distributeRet(U08 bus, U08 node)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx=NULL;
  Uint idx;
  Uint count;
  Uint nodeIdx = CO_SLV_NODES_MAX;
  Bool go = TRUE;

  /* check node ID: slave and defined */
  if (!CO_SLV_BASE_NODE_VALID(node))
  {
    result = E_CANAPI_NODE_ID_ERROR;
    go = FALSE;
  }
  else
  {
    /* check Payload Bus master state */
    pCtx = &CoMgr_ctx[bus];
     
    nodeIdx = pCtx->nodeToBusNodeIdx[node];
    if (nodeIdx == CO_SLV_NODES_MAX)
    {
      result = E_CANAPI_NODE_ID_UNKNOWN;
      go = FALSE;
    }
  }
  
  /* no errors detected so far */
  if (go)
  {
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
    
    if ((pCtx->retIn) >= (pCtx->retOut+CO_RET_QUEUE_LENGTH))
    {
      /* request queue full */
      result = E_CANAPI_TOO_MANY_PENDING_CMD;
    }
    else
    {
      /* if the request has been registered for the current sync period,
       * discard the current one */
      for (count = pCtx->retOut; (count < pCtx->retIn) && go; count++)
      {
        idx = count%CO_RET_QUEUE_LENGTH;
        if (pCtx->retNodeIdxQueue[idx] == nodeIdx)
        {
          go = FALSE;
        }
      }
      if (go)
      {
          /* add request to the queue */
          idx = pCtx->retIn%CO_RET_QUEUE_LENGTH;
          pCtx->retNodeIdxQueue[idx] = nodeIdx;
          pCtx->retIn++;
      }
    }
    ResourceLock_unlock(&pCtx->lock); 
  }  
  return result;
}

/***********************************************************************/
/**
 * @brief CanApis_getUlReqExec - retrieve the execution result for a Upload request
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in] bus             The bus identifier
 * @param[in] reqNum          The request number of the upload request
 * @param[in] node            The server node ID
 * @param[in] objIdx          The object index
 * @param[out] pSdoData       The buffer to contain SDO TM data
 *
 * @return - E_CANAPI_OK or error code
 * - E_CANAPI_TRANSFER_ABORT
 * - E_CANAPI_SERVICE_TIMEOUT
 * 
 ***********************************************************************/ 
PRIVATE U32 CanApis_getUlReqExec(U08 bus, U32 reqNum, U32 node, U32 objIdx,  U08 *pSdoData)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  U32 execCnt;
  U32 execIdx;
  Bool handled;
  SdoBlkExec *pExec;
  CoSdoBlkTmRecord *pTmRecord;
  SdoBlkTmArea *pSdoBlkBus;

  /* check Bus ID */
  pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];
  
  /* now, search in the response queue the one with the specified request number */
  result = E_CANAPI_SERVICE_TIMEOUT;
         
  /* get the latest upload responses */
  if ((pCtx->sdoUlExecIn - pCtx->sdoUlExecOut) > CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH)
  {
    /* if request queue overwritten */
    pCtx->sdoUlExecOut = pCtx->sdoUlExecIn - CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH;
  }
  
  execCnt = pCtx->sdoUlExecIn - pCtx->sdoUlExecOut;
  handled = FALSE;
  
  /* BEGIN: protect the modification of SDO DL EXEC queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  for (execIdx = 0; (execIdx < execCnt) && (handled == FALSE); execIdx++)
  {
    idx = pCtx->sdoUlExecOut%CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH;
    pExec = &pCtx->sdoUlExecQueue[idx];
    
    if (pExec->reqCnt == reqNum)
    {
      /* %COVER%TRUE% Defensive programming - TC service using wrong parameter ? ERROR_REPORT macro called here. */
      if ((pExec->node != node) || (pExec->objIdx != objIdx))
      {
        ERROR_REPORT(SW, pCtx->busId, reqNum, pCtx->cycSyncSem);
      }

      if (pExec->result == OK)
      {
        /* get the current TM buffer then retrieve the uploaded data and its size */
        pSdoBlkBus = pCtx->pSdoBlkTmArea;
        pTmRecord = &pSdoBlkBus->pBlkQueue[pExec->sdoUpRecNum%(pSdoBlkBus->blks)];
        memcpy (pSdoData, pTmRecord->data, pTmRecord->nBytes);
        
        /* if the current TMis the first in the Queue, remove it */
        if (pExec->sdoUpRecNum == pSdoBlkBus->read)
        {
          pSdoBlkBus->read++; 
        }
        result = E_CANAPI_OK;
      }
      else
      {
        result = E_CANAPI_TRANSFER_ABORT;
      }
      handled = TRUE;
      pCtx->sdoUlExecOut++;
    }
    else if (pExec->reqCnt > reqNum)
    {
      handled = TRUE;
    }
    else
    {
      pCtx->sdoUlExecOut++;
    }
  } /* for */
  /* END: protect the modification of SDO DL Exec queues  */
  ResourceLock_unlock(&pCtx->lock);
  
  return result;
}

/***********************************************************************/

/**
* @brief CanApis_checkDlReqExec - check the execution result for a Download request
* 
* @reentrant The variable @ref CoMgr_ctx is protected for exclusive
* read/write access by a mutex @ref CoCtx.lock.
* 
* @param[in] bus             The bus identifier
* @param[in] reqNum          The request number of the download request
* @param[in] node            The server node ID
* @param[in] objIdx          The object index
* @return - E_CANAPI_OK or error code
* - E_CANAPI_TRANSFER_ABORT
* - E_CANAPI_SERVICE_TIMEOUT
* 
 ***********************************************************************/ 
PRIVATE U32 CanApis_checkDlReqExec(U08 bus, U32 reqNum, U32 node, U32 objIdx)
{
  U32 result = E_CANAPI_OK;
  CoCtx *pCtx;
  Uint idx;
  U32 execCnt;
  U32 execIdx;
  Bool handled;
  SdoBlkExec *pExec;
  
  /* get the latest download responses */
  pCtx = &CoMgr_ctx[bus%ROV_CANBUS_NUM];

  if ((pCtx->sdoDlExecIn - pCtx->sdoDlExecOut) > CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH)
  {
    /* if request queue overwritten */
    pCtx->sdoDlExecOut = pCtx->sdoDlExecIn - CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH;
  }
  execCnt = pCtx->sdoDlExecIn - pCtx->sdoDlExecOut;
  handled = FALSE;
  result = E_CANAPI_SERVICE_TIMEOUT;
  
  /* BEGIN: protect the modification of SDO DL EXEC queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  for (execIdx = 0; (execIdx < execCnt) && (handled == FALSE); execIdx++)
  {
    idx = pCtx->sdoDlExecOut%CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH;
    pExec = &pCtx->sdoDlExecQueue[idx];
    if (pExec->reqCnt == reqNum)
    {
      /* %COVER%TRUE% Defensive programming - TC service using wrong parameter ? ERROR_REPORT macro called here. */
      if ((pExec->node != node) || (pExec->objIdx != objIdx))
      {
        ERROR_REPORT(SW, pCtx->busId, reqNum, pCtx->cycSyncSem);
      }
      
      if (pExec->result == OK)
      {
        result = E_CANAPI_OK;
      }
      else
      {
        result = E_CANAPI_TRANSFER_ABORT;
      }
      handled = TRUE;
      pCtx->sdoDlExecOut++;
    }
    else if (pExec->reqCnt > reqNum)
    {
      handled = TRUE;
    }
    else
    {
      pCtx->sdoDlExecOut++;
    }
  } /* for */
  /* END: protect the modification of SDO DL Exec queues  */
  ResourceLock_unlock(&pCtx->lock);
  return result;
}


/*********************************************************************/
/**
 * @brief CanApis_searchSdoMessage - search a specified SDO message
 *
 * @param[out] result       The result of the serach
 * @param[in] avail         Message available
 * @param[in] pMsgArea      Pointer to the message area
 * @param[in] isDownload    Is a download
 * @param[in] reqNum        request number
 * @param[in] pData         pointer to the data
 * @return - @link E_CANAPI_OK @endlink or error code
 *
 *********************************************************************/ 
PRIVATE void CanApis_searchSdoMessage(U32 *result, U32 avail, SdoMsgArea *pMsgArea, Bool isDownload, U32 reqNum, U08 *pData)
{
  U32 msgCnt;
  CoSdoMsgRecord *pMsgRecord;

  /* search in the Queue the SDO message, response to the specified request */
  for (msgCnt = 0; (msgCnt < avail) && ((*result) != E_CANAPI_OK); msgCnt++)
  {
    pMsgRecord = &pMsgArea->msgQueue[(pMsgArea->read+msgCnt)%CO_SDO_MSG_PER_NODE];
    
    if ((pMsgRecord->isDownload == isDownload) && (pMsgRecord->reqCnt == reqNum))
    {
      /* OK, retrieve it and stop the search */
      memcpy (pData, pMsgRecord->data, CANOPEN_SDO_DATA_LENGTH);
      (*result) = E_CANAPI_OK;
      
      /* discard it only if it is the head in the queue */
      if (msgCnt == 0)
      {
        pMsgArea->read++;
      }
    }
  }
}

/*------------------ ooOoo End of file ooOoo --------------------------*/
