/* CanApisFull.h - pricate header file for CanApis.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanApisFull_
#define _CanApisFull_

/***********************************************************************/
/**
 * @file
 * @brief CanApisFull.h - full header file for CanApis module.
 *
 * The file provides the "full" declaration of public services of
 * and relative data of CanApis module. It includes the declaration
 * of the "standard" services, and some "reserved" services.
 * 
 ***********************************************************************/
#include "coMgt/CanOpenStd.h"
#include "coMgt/CanOpenCommon.h"

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------*/

/*---------- Defines & macro ------------------------------------------*/

/*---------- Types definitions ----------------------------------------*/

/**
 * @addtogroup canApi
 * @{
 */

/**
 * @brief CanApiMsg: CANopen message descriptor 
 */
typedef struct CanApiMsg
{
  U16 cobId;              /**< @brief COB ID */
  U08 rtr;                /**< @brief rtr */
  U08 dataBytes;          /**< @brief data size in bytes */
  U08 data[CAN_MSG_SIZE]; /**< @brief data byte buffer */
} CanApiMsg;

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

/*
 * CanApis_distributePlatformRet - request to send RET to a node on platform bus
 */
PUBLIC U32 CanApis_distributePlatformRet(U08 node);

/*
 * CanApis_sendNmtSlv - send a NMT command to a slave node 
 */
PUBLIC U32 CanApis_sendNmtSlv(U08 bus, U08 node, U08 cs, Bool nodeCheck);

/*
 * CanApis_getBusFrameWork - get the framework information of a bus
 */
PUBLIC U32 CanApis_getBusFrameWork(U08 bus, U32 *pCycle, U32 *pSlot);

/*
 * CanApis_getBusLastRxMsg - get the last RX CAN message of a bus
 */
PUBLIC U32 CanApis_getBusLastRxMsg(U08 bus, U32 *pRxMsgs, CanApiMsg *pMsg);

/*
 * CanApis_getNodeState - get the last state and event on a bus
 */
PUBLIC U32 CanApis_getNodeLastStateEvt(U08 bus, CoState *pState, CoEvt *pEvt);

/*
 * CanApis_startExpeditedDownloadSdoCnt - send an expedited SDO
 * download message to a slave device and get the request number
 */
PUBLIC U32 CanApis_startExpeditedDownloadSdoCnt(U08 bus, U08 node, U16 idx, U08 subIdx, U32 nBytes, U08 *pData, U32 *pReqCnt);

/*
 * CanApis_startExpeditedUploadSdoCnt - start an expedited SDO 
 * upload message to a slave device and get the request number
 *
 */
PUBLIC U32 CanApis_startExpeditedUploadSdoCnt(U08 bus, U08 node, U16 idx, U08 subIdx, U32 *pReqCnt);

/*
 * CanApis_extractExpeditedSdoResp - extract the response for an expedited SDO message
 * of a node on a CAN Bus
 *
 */
PUBLIC U32 CanApis_extractExpeditedSdoResp(U08 bus, U08 node, Bool isDownload, U32 reqNum, U32 timeoutCycle, U08 *pData);

/*
 * CanApis_startBlockDownloadSdoIdx - request to start a SDO download
 * on a node with a specific index
 */
PUBLIC U32 CanApis_startBlockDownloadSdoIdx(U08 bus, U08 node, U16 objIdx, U32 dataBytes, U08 *pData, U32 *pReqCnt);

/*
 * CanApis_startBlockUploadSdoIdx - request to start a SDO upload
 * on a node with a specific index
 */
PUBLIC U32 CanApis_startBlockUploadSdoIdx(U08 bus, U08 node, U16 objIdx, U32 dataBytes, U32 *pReqCnt);

/*
 * CanApis_getBlockDownloadSdoExec - get the result of a specified 
 * Block SDO download request
 */
PUBLIC U32 CanApis_getBlockDownloadSdoExec(U08 bus, U32 reqNum, U32 node, U32 objIdx, U32 timeoutCycle);

/*
 * @brief CanApis_getBlockUploadSdoExec - get the result of a specified 
 * Block SDO Upload request
 */
PUBLIC U32 CanApis_getBlockUploadSdoExec(U08 bus, U32 reqNum, U32 node, U32 objIdx, U08 *pSdoData, U32 timeoutCycle);

/*
 * @brief CanApis_resetUnexpectedHb - allow new detection of unexpected HB 
 */
PUBLIC U32 CanApis_resetUnexpectedHb(U08 bus, U32 node);


/** @} */

#endif /* _CanApisFull_ */
