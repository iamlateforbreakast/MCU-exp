/* CanOpenSdo.h - header file for CanOpenSdo.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenSdo_
#define _CanOpenSdo_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenSdo.h - header file for CanOpenSdo module.
 *
 * The file provides the declaration of public services of CanOpenSdo
 * module used by CANopen Manager on the 2 buses
 * 
 **********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenAction.h"


/*---------- Defines & macro ------------------------------------------*/

/*---------- Types definitions ----------------------------------------*/

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

/*
 * CanOpenSdoAction_setup - setup SDO automaton start-up context
 */
PUBLIC void CanOpenSdo_setup(CoCtx *pCtx);

/*
 * CanOpenSdo_submitMsg - submit received SDO MESSAGE for SDO manager
 */
PUBLIC void CanOpenSdo_submitMsg(CoCtx *pCtx, CoMsg *pCoMsg);

/*
 * CanOpenSdo_handleReq - ask SDO manager to handle SDO request
 */
PUBLIC void CanOpenSdo_handleReq(CoCtx *pCtx);

/*
 * CanOpenSdo_updateState - update the current SDO manager state
 */
PUBLIC void CanOpenSdo_updateState(CoCtx *pCtx);


#endif /* _CanOpenSdo_ */
