/* CanOpenSdo.c - CanOpenSdo body */

/* Copyright (c) 2014 - 2018 AIRBUS Defence & Space ltd */
 
/* Project : Exomars Rover Vehicle */

/***********************************************************************/
/**
 * @file
 * @brief CanOpenSdo.c - implementation of CanOpenSdo module.
 *
 * - SRS.DMS.CAN.FUNC.0240
 * - SRS.DMS.CAN.FUNC.0260
 * - SRS.DMS.CAN.FUNC.0360
 * - SRS.DMS.CAN.PERF.0170
 ***********************************************************************/

/**
 * @addtogroup coMgr
 * @{
 * @par CanOpenSdo module
 * 
 * CanOpenSdo module implements the manager of SDO protocols for platform 
 * & payload CAN Buses. A subset of SDO protocols are implemented according
 * to Rover Project specific tailoring:
 * 
 *  - SDO Download expedited transfer;
 *  - SDO Upload expedited transfer;
 *  - SDO Download Block transfer, with block number limited to 1;
 *  - SDO Upload Block transfer,  with block number limited to 1;
 *  - ABORT SDO transfer
 *
 * A SDO protocols manager works as an automaton for the CANopen manager
 * of each bus. This automaton is part of the corresponding CANopen manager:
 *  - it is executed in same tasking context,
 *  - it accesses the same CAN Bus context.
 * 
 * The SDO protocols automaton is implemented as a state machine using a set
 * of "actions" executed according to "events" to be handled in its ongoing
 * "state", and performing the necessary "state transition":
 *
 *  - the "states" describe the on-going protocols operation,
 *  - the "events" are identified as triggers that "activate" the "state machine",
 *  - the "actions" are the operations to be performed when a given "event"
 *    is raised on a given state.
 *  - the "state transition" are provided by performed action to indicate
 *    the next state of the state machine, 
 *    
 * The "states" that the SDO protocols manager handles are identified in this
 * module as "CoSdoState". The list of the state are established according to
 * the SDO protocols as it is defined in the CANopen standard, and also
 * the CANopen Manager's internal design feature.
 * 
 * The "events" that the SDO protocols manager handles also are defined in this 
 * module as "CoSdoEvt". The list of events are based on the design feature.
 * 
 * The "actions" that performed according to events to be handled on a given state
 * and consequent "state transition" depend, not only on the SDO protocols definition,
 * but also on how the necessary operations to support the protocols are "distributed"
 * on all actions.
 *  
 * The SDO protocols manager has not its own context, it uses the global context
 * of CANopen manager on Platform & Payload. The SDO manager on the two bus
 * share the same source code, but work with different configuration parameters and
 * contexts. 
 *
 * CanOpenSdo module defines the transition table for both buses. It provides also
 * necessary services to submit "events" for the SDO protocols manager on a bus:
 * 
 *  - CanOpenSdo_MsgSubmit(): submit a received SDO CAN message for SDO manager.
 *    This service is dedicated to be invoked for each received SDO message.
 *    
 *  - CanOpenSdo_StateUpdate(): update the current SDO manager state.
 *    It is dedicated to be invoked, systematically, at each slot period after
 *    the processing of all received CAN messages of the previous slot period.
 *    
 *  - CanOpenSdo_ReqHandle(): ask SDO manager to handle SDO request
 *    It is dedicated to be invoked, systematically, at each slot period 
 *    before transmitting the CAN messages of the current slot period.
 *    
 * In addition, this module exports a clean-up function to set-up the initial 
 * working context for SDO manager (CanOpenSdoAction_Setup()) before activating SDO
 * protocols manager.
 * 
 * To support the the SDO protocols manager, this module realises the set of
 * functions corresponding to all actions defined in the transition table
 * for the SDO protocol manager.
 * 
 * @note
 * 
 * The CANopen Standard states that the SDO protocols are supported when the manager
 * is in PRE-OPERATIONAL or OPERATIONAL modes. However, so far as Rover Project
 * is concerned, the SDO Block Upload and SDO Block Download protocols may be used
 * with Buffer Support PDO message, that is only available in OPERATIONAl mode according
 * to CANopen Standard. As result, the SDO Block Upload and SDO Block Download
 * protocols are supported in PRE-OPERATIONAL mode without using Buffer Support PDO
 * message.
 * 
 * If an unexpected error is encountered during the SDO exchange handling, the SDO manager
 * may generate an Abort SDO message using the following codes according to the detected
 * error:
 *   - CANOPEN_SDO_ABORT_TIMEOUT   
 *   - CANOPEN_SDO_ABORT_CS_ERR  
 *   - CANOPEN_SDO_ABORT_BLK_SIZE_ERR
 *   - CANOPEN_SDO_ABORT_SEQ_NUM_ERR
 *   
 * The ongoing SDO transfer is then stopped.
 *  
 * In a similar manner, if a Abort SDO message, sent by SDP server, is received by
 * SDO manager and it is a valid message (node, multiplexor, abort code) for the ongoing
 * SDO transfer, the transfer is stopped also.
 * 
 * @}
 */

/*---------- Standard libraries includes ------------------------------*/

#include <libc.h>

/*---------- FSW includes ---------------------------------------------*/
#include "errorLib.h"
#include "evtLib.h"
#include "Eid.h"

/*---------- Component includes ---------------------------------------*/
#include "rtcCplr/RtcCplr.h"
#include "coMgt/CanOpenBus.h"
#include "coMgt/CanOpenSdo.h"

/*---------- Local defines & macro ------------------------------------*/
#ifdef COMGT_UT_SUPPORT
PUBLIC rtems_id CoMgt_MstWakeUpSemId[ROV_CANBUS_NUM];

/* Frequency in Hertz of the Can Open slots */
#define CO_FREQUENCY_IN_HZ (200)
#endif

 /* Number of microseconds in a millisecond */
#define NB_US_IN_MS (1000)

 /* Number of microseconds in a 1.55 ms to wait for the final SDO UL End command*/
#define SDO_UP_BUSY_WAIT (1550)

/*---------- Local types definitions ----------------------------------*/
/* 
 * SDO manager takes into account the SDO expedited command in 100Hz slots 1 to 8,
 * The response messages are so expected in 100Hz slots 2 to 9 
 * 
 */
#define COMGT_SDO_EXPDT_CMD_FIRST_SLOT (1)
#define COMGT_SDO_EXPDT_CMD_LAST_SLOT (8)

#define COMGT_SDO_EXPDT_MSG_FIRST_SLOT (COMGT_SDO_EXPDT_CMD_FIRST_SLOT)
#define COMGT_SDO_EXPDT_MSG_LAST_SLOT (COMGT_SDO_EXPDT_CMD_LAST_SLOT+1)

#define COMGT_SDO_EXPDT_MSG_FIRST_IT_SLOT (COMGT_SDO_EXPDT_CMD_FIRST_IT_SLOT+1)
#define COMGT_SDO_EXPDT_MSG_LAST_IT_SLOT (COMGT_SDO_EXPDT_CMD_LAST_IT_SLOT+1)


/** 
 * @brief CoSdoState: state list of CANopen SDO state machine 
 * 
 */
typedef enum
{
  E_SDOSTATE_READY = 0x50,  /**< @brief Ready State */
  E_SDOSTATE_EXPDT,         /**< @brief expedited transfer state */
  E_SDOSTATE_UL_INIT,       /**< @brief block upload init state */
  E_SDOSTATE_UL_DATA1,      /**< @brief block upload data transfer step 1 */
  E_SDOSTATE_UL_DATA2,      /**< @brief block upload data transfer step 2 */
  E_SDOSTATE_UL_SEGEND,     /**< @brief block upload segment end */
  E_SDOSTATE_UL_END,        /**< @brief block upload end */
  E_SDOSTATE_DL_INIT,       /**< @brief block download init state */
  E_SDOSTATE_DL_DATA1,      /**< @brief block download data transfer step 1 */
  E_SDOSTATE_DL_DATA2,      /**< @brief block download data transfer step 2 */
  E_SDOSTATE_DL_SEGEND1,     /**< @brief block download segment end phase 1 */
  E_SDOSTATE_DL_SEGEND2,     /**< @brief block download segment end Phase 2 */
  E_SDOSTATE_DL_END,        /**< @brief block download end state  */
  E_SDOSTATE_END            /**< @brief mark for the end of the list */
} CoSdoState;

/**
* @brief CoSdoEvt: event list for CANopen manager 
 *
 * The CoSdoEvt is a enum type associated at any event that 
 * the SDO manager handles. 
 */
typedef enum
{
  E_SDOEVT_REFRESH = 20, /**< @brief state refresh event */
  E_SDOEVT_COMMAND,      /**< @brief for request processing */
  E_SDOEVT_MESSAGE,      /**< @brief for input message processing */
  E_SDOEVT_END           /**< @brief marker for the end of the list */
} CoSdoEvt;


/**
 * @brief SdoScsType: type list for SDO SCS field
 *
 * The SdoScsType is a enum type associated to SCS field of a message from
 * SDO server  
 * The numerical value of each item are arbitrary
 * 
 */
typedef enum
{
  E_SDOSCS_UNKNOWN = 30,  /**< @brief Not valid SCS field */
  E_SDOSCS_EXPDT_UL,  /**< @brief confirm message for expedited upload */
  E_SDOSCS_EXPDT_DL,  /**< @brief confirm message for expedited download */
  E_SDOSCS_BLK_UL_INIT,  /**< @brief confirm message for block upload "init" */
  E_SDOSCS_BLK_UL_END,  /**< @brief indication message for block upload "end" */
  E_SDOSCS_BLK_DL_INIT,  /**< @brief confirm message for block download "init" */
  E_SDOSCS_BLK_DL_SEG,  /**< @brief confirm message for block download "segment" end */
  E_SDOSCS_BLK_DL_END,  /**< @brief confirm message for block download "end" */
  E_SDOSCS_END, /**< @brief end of the list */
} SdoScsType;


/**
 * @brief SdoBlkStp: step list for SDO block Transfer 
 *
 * The SdoBlkStep is a enum type associated at any slots w.r.t 
 * their usage during the transfer.
 * The numerical value of each item are arbitrary
 * 
 */
typedef enum
{
  E_SDOBLKSTP_NONE = 10,  /**< @brief N/A for SDO block */
  E_SDOBLKSTP_INIT1,      /**< @brief Init phase 1 */
  E_SDOBLKSTP_INIT2,      /**< @brief Init phase 2 */
  E_SDOBLKSTP_DATA1,      /**< @brief Data transfer phase 1*/
  E_SDOBLKSTP_DATA2,      /**< @brief Data transfer phase 2*/
  E_SDOBLKSTP_END,        /**< @brief End phase */
} SdoBlkStp;

/**
 * @brief SdoScsTypeDesc: CANopen message descriptor 
 *
 * This structure defines a CANopen message:
 * - extraction mask
 * - expected extracted value
 * - corresponding type
 **/
typedef struct SdoScsTypeDesc
{
  U08 msk;             /**< @<brief mask to retrieve scs  */
  U08 scs;             /**< @<brief expected masked scs value */
  SdoScsType type;     /**< @brief type identifier */
} SdoScsTypeDesc;


/**
 * @brief CoSdoAction: Pointer to an 'action' of the state machine 
 */
typedef CoSdoState(*CoSdoAction) (CoCtx *pCtx, CoMsg *);


/**
 * @brief CoTrans: state machine transition descriptor
 **/
 typedef struct CoSdoTrans
{
  CoSdoState  state; /**< @brief current automaton state */
  CoSdoEvt    evt;    /**< @brief input event */
  CoSdoAction act;   /**< @brief corresponding 'action' to be performed */
} CoSdoTrans;

/*---------- Definition of variables exported by the module -----------*/

/*---------- Definition of local variables and constants --------------*/

/*---------- Declarations of local functions --------------------------*/

/* actions used in automatons */

PRIVATE CoSdoState coSdoActReadyCmd(CoCtx *pCtx, CoMsg *pMsg);

/* For Expedited transfer */
PRIVATE CoSdoState coSdoActExpdtMsg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActExpdtUdt(CoCtx *pCtx, CoMsg *pMsg);

/* For Upload transfer */
PRIVATE CoSdoState coSdoActUInitMsg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActUInitUdt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActUDat1Msg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActUDat1Udt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActUDat2Msg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActUDat2Udt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActUSgmtMsg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActUSgmtUdt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActUBendCmd(CoCtx *pCtx, CoMsg *pMsg);

/* For Download transfer */
PRIVATE CoSdoState coSdoActDInitMsg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActDInitUdt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActDDat1Udt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActDDat2Udt(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActDDat2Msg(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActDSgt1Msg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActDSgt1Udt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActDSgt2Udt(CoCtx *pCtx, CoMsg *pMsg);

PRIVATE CoSdoState coSdoActDBendMsg(CoCtx *pCtx, CoMsg *pMsg);
PRIVATE CoSdoState coSdoActDBendUdt(CoCtx *pCtx, CoMsg *pMsg);

/* other services */
PRIVATE CoSdoTrans const *coSdoTransGet(CoSdoEvt event, CoSdoState state);
PRIVATE void coSdoAutom(CoCtx *pCtx, CoSdoEvt evt, CoMsg *pMsg);

PRIVATE SdoScsType coSdoScsToType(U08 scs);
PRIVATE SdoBlkStp coULSlotToSdoBlkStep(CoCtx *pCtx);
PRIVATE SdoBlkStp coDLSlotToSdoBlkStep(CoCtx *pCtx);

PRIVATE Bool coExpeditedSdoMsgBuild(CoCtx *pCtx);
PRIVATE void coAbortSdoMsgBuild(CoCtx *pCtx, U08 node, U08 *pMtx, U32 code);
PRIVATE Bool coAbortSdoMsgCheck(CoMsg *pMsg, U08 *pMtx, U32 *pAbortCode);

PRIVATE Bool coBlkSdoUlInitMsgBuild(CoCtx *pCtx);
PRIVATE void coBlkSdoUlStartBuild(CoCtx *pCtx);
PRIVATE void coBlkSdoUlCfmBuild(CoCtx *pCtx, CoSdoBlkTmRecord *pTmRecord);
PRIVATE void coBlkSdoUlEndBuild(CoCtx *pCtx);
PRIVATE void coBlkSdoUlSegCfmSend(CoCtx *pCtx, CoSdoBlkTmRecord *pTmRecord);

PRIVATE Bool coBlkSdoDlInitMsgBuild(CoCtx *pCtx);
PRIVATE void coBlkSdoDlEndMsgBuild(CoCtx *pCtx);

PRIVATE U32 coBlkUlDataMsgRecord(CoCtx *pCtx, CoMsg *pMsg, CoSdoBlkTmRecord *pTmRecord);

PRIVATE void coBlkUlReqQueueNodeRemove(CoCtx *pCtx, U08 node);
PRIVATE void coBlkSdoDlDataMsgSend(CoCtx *pCtx, Uint nBlk, SdoBlkDlReq *pDlReq);
PRIVATE void coBlkSdoDlEnd(CoCtx *pCtx, U32 cliAbortCode, U32 serAbortCode);
PRIVATE void coBlkSdoUlEnd(CoCtx *pCtx, U32 cliAbortCode, U32 srvAbortCode);

/**
 * @brief CoSdoTrans - CANopen SDO State machine transition definition
 *
 * This table defines the CANopen Manager's state machine:
 * - the possible states,
 * - the possible and significant events for each state,
 * - the action for all events on all states
 * 
 * The next state of the machine at the end of a given action is provided by the action.
 *
 * This table is applicable for the 2 buses.
 *
 ***********************************************************************/
PRIVATE CoSdoTrans const canOpenSdoTrans[] = {
    
  /* from READY state */
  {E_SDOSTATE_READY, E_SDOEVT_COMMAND, coSdoActReadyCmd},

  /* from EXPDT state */
  {E_SDOSTATE_EXPDT, E_SDOEVT_REFRESH, coSdoActExpdtUdt},
  {E_SDOSTATE_EXPDT, E_SDOEVT_MESSAGE, coSdoActExpdtMsg},
  
  /* from UL_INIT state */
  {E_SDOSTATE_UL_INIT, E_SDOEVT_REFRESH, coSdoActUInitUdt},
  {E_SDOSTATE_UL_INIT, E_SDOEVT_MESSAGE, coSdoActUInitMsg},
     
  /* from UL_DATA1 state */
  {E_SDOSTATE_UL_DATA1, E_SDOEVT_REFRESH, coSdoActUDat1Udt},
  {E_SDOSTATE_UL_DATA1, E_SDOEVT_MESSAGE, coSdoActUDat1Msg},
  
  /* from UL_DATA2 state */
  {E_SDOSTATE_UL_DATA2, E_SDOEVT_REFRESH, coSdoActUDat2Udt},
  {E_SDOSTATE_UL_DATA2, E_SDOEVT_MESSAGE, coSdoActUDat2Msg},
  
  /* from UL_SEGEND state */
  {E_SDOSTATE_UL_SEGEND, E_SDOEVT_REFRESH, coSdoActUSgmtUdt},
  {E_SDOSTATE_UL_SEGEND, E_SDOEVT_MESSAGE, coSdoActUSgmtMsg},
  
  /* from UL_END state */
  {E_SDOSTATE_UL_END, E_SDOEVT_COMMAND, coSdoActUBendCmd},
  
  /* from DL_INIT state */
  {E_SDOSTATE_DL_INIT, E_SDOEVT_REFRESH, coSdoActDInitUdt},
  {E_SDOSTATE_DL_INIT, E_SDOEVT_MESSAGE, coSdoActDInitMsg},

  /* from DL_DATA1 state */
  {E_SDOSTATE_DL_DATA1, E_SDOEVT_REFRESH, coSdoActDDat1Udt},

  /* from DL_DATA2 state */
  {E_SDOSTATE_DL_DATA2, E_SDOEVT_REFRESH, coSdoActDDat2Udt},
  {E_SDOSTATE_DL_DATA2, E_SDOEVT_MESSAGE, coSdoActDDat2Msg},
  
  /* from DL_SEGEND1 state */
  {E_SDOSTATE_DL_SEGEND1, E_SDOEVT_REFRESH, coSdoActDSgt1Udt},
  {E_SDOSTATE_DL_SEGEND1, E_SDOEVT_MESSAGE, coSdoActDSgt1Msg},
  
  /* from DL_SEGEND2 state */
  {E_SDOSTATE_DL_SEGEND2, E_SDOEVT_REFRESH, coSdoActDSgt2Udt},  
  
  /* from DL_END state */
  {E_SDOSTATE_DL_END, E_SDOEVT_REFRESH, coSdoActDBendUdt},
  {E_SDOSTATE_DL_END, E_SDOEVT_MESSAGE, coSdoActDBendMsg},
  
  /* mark it as the end of transition table */
  {E_SDOSTATE_END, E_SDOEVT_END, NULL}
};

/*------------------ ooOoo Inline functions (if any) ooOoo ------------*/

/*------------------ ooOoo Global functions ooOoo ---------------------*/

/***********************************************************************/
/**
 * @brief CanOpenSdo_setup - setup SDO automaton start-up context
 *
 * This function sets up the initial context for a SDO manager of a Bus.
 * It is to be called once and only once before activating SDO function.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return    N/A
 * 
 ***********************************************************************/ 
void CanOpenSdo_setup(CoCtx *pCtx) 
{
  T_UINT32 idx = 0;
  T_UINT32 sizeOfArray = 0;

  /* set init state for SDO related context */
  
  pCtx->sdoEna = FALSE;
  pCtx->expdtSdoNode = 0;
  pCtx->expdtSdoScs = 0;
  pCtx->blkSdoUlNode = 0;
  pCtx->blkSdoDlNode = 0;
  pCtx->blkSdoAddList = FALSE;
  memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);
  
  /* Expdt SDO Downlink */
  pCtx->expdtSdoDlIn = 0;
  pCtx->expdtSdoDlOut = 0;
  pCtx->expdtSdoDlReqCnt = 0;
  pCtx->expdtSdoDlReqLast = 0;

  /* Expdt SDO Uplink */
  pCtx->expdtSdoUlIn = 0;
  pCtx->expdtSdoUlOut = 0;
  pCtx->expdtSdoUlReqCnt = 0;
  pCtx->expdtSdoUlReqLast = 0;
  
  /* SDO Downlink */
  pCtx->sdoDlIn = 0;
  pCtx->sdoDlOut = 0;
  pCtx->sdoDlReqCnt = 0;
  pCtx->sdoDlReqLast = 0;
  
  pCtx->sdoDlExecIn = 0;
  pCtx->sdoDlExecOut = 0;
    
  /* SDO Uplink */
  pCtx->sdoUlIn = 0;
  pCtx->sdoUlOut = 0;
  
  pCtx->sdoUlReqCnt = 0;
  pCtx->sdoUlReqLast = 0;
  
  pCtx->sdoUlExecIn = 0;
  pCtx->sdoUlExecOut = 0;
  
  /* SDO state */
  pCtx->sdoState = E_SDOSTATE_READY;

  /* setup the subIndex for Upload and Download */
  if(pCtx->busId == CANBUS_ID_PF)
  {
    sizeOfArray = CO_PF_NODE_NUM;
  }
  else
  {
    sizeOfArray = CO_PL_NODE_NUM;
  }
  
  for (idx = 0 ; idx < sizeOfArray; idx++)
  {

    pCtx->pNodeStat[idx].bufSupPdoSubIdxUpl = CO_OD_SDO_BLK_SUBIDX;
    pCtx->pNodeStat[idx].bufSupPdoSubIdxDwnl = CO_OD_SDO_BLK_SUBIDX;
  } 
}

/***********************************************************************/
/**
 * @brief CanOpenSdo_submitMsg - submit received SDO MESSAGE for SDO manager
 *
 * This function provides a received SDO message from a SDO server
 * for SDO manager for its processing after a minimum check. 
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pCoMsg    The pointer to the received SDO message
 * @return    N/A
 * 
 ***********************************************************************/ 
void CanOpenSdo_submitMsg(CoCtx *pCtx, CoMsg *pCoMsg)
{
  /* check if it is really a valid SDO message */
  if ((pCoMsg->rtr == CANOPEN_SDO_RTR) && 
      (pCoMsg->dataBytes == CANOPEN_SDO_DATA_LENGTH))
  {
    /* run automaton with E_SDOEVT_MESSAGE and incoming message */
    coSdoAutom(pCtx, E_SDOEVT_MESSAGE, pCoMsg);
  }
}

/***********************************************************************/
/**
 * @brief CanOpenSdo_handleReq - ask SDO manager to handle SDO request
 *
 * This function asks SDO manager to handle SDO request in the request queue
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return    N/A
 * 
 ***********************************************************************/ 
void CanOpenSdo_handleReq(CoCtx *pCtx)
{
  /* run automaton with E_SDOEVT_COMMAND and no message */
  coSdoAutom(pCtx, E_SDOEVT_COMMAND, NULL);
}

/***********************************************************************/
/**
 * @brief CanOpenSdo_updateState - update the current SDO manager state
 *
 * This function updates the current SDO manager state
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return    N/A
 * 
 ***********************************************************************/ 
void CanOpenSdo_updateState(CoCtx *pCtx)
{
  /* run automaton with E_SDOEVT_REFRESH and no message */
  coSdoAutom(pCtx,  E_SDOEVT_REFRESH, NULL);
}

/*------------------ ooOoo Local functions ooOoo ----------------------*/

/***********************************************************************/
/**
 * @brief coSdoActReadyCmd - action to perform upon a command event
 * reception when SDO manager is in READY state.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 * 
 * @requirements
 * - SRS.DMS.CAN.FUNC.0940 [SDO TC have priority over SDO TM]
 * - SRS.DMS.CAN.FUNC.0960 [TC (Block Download) request handled before TM (Block Upload)]
 * - SRS.DMS.CAN.PERF.0120 [invoked up to 8 times per cycle]
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActReadyCmd(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_READY;
  PARAM_NOT_USED(pMsg);
  
  /* if SDO is not supported, do not process the SDO transfer request */
  /* %COVER%TRUE% Defensive programming - check done already done outside automaton (in CanOpenAction:slotProcess) */   
  if (pCtx->sdoEna != TRUE)
  {
    nextState = E_SDOSTATE_READY;
  }
  /* process Block SDO firstly: TC then TM */  
  else if (coBlkSdoDlInitMsgBuild(pCtx))
  {
    nextState = E_SDOSTATE_DL_INIT;
  }
  /* if there is no Block SDO download (TM) request, then check Block upload @ 200 Hz*/
  else if (coBlkSdoUlInitMsgBuild(pCtx))
  {
    nextState = E_SDOSTATE_UL_INIT;
  }
  
  /* if SDO is neither enabled nor we are not in 100Hz slots (1-8), no expedited command to take */
  else if ((!IS_OUTSIDE(pCtx->slotInCycle,COMGT_SDO_EXPDT_CMD_FIRST_SLOT,
                        COMGT_SDO_EXPDT_CMD_LAST_SLOT)) && 
           (pCtx->itInCycle%2 == 0))
  {
    if (coExpeditedSdoMsgBuild(pCtx))
    {
      nextState = E_SDOSTATE_EXPDT;
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActExpdtMsg -  action to perform upon a message event
 * reception when SDO manager is in EXPDT state.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0110 [message recording]
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActExpdtMsg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_EXPDT;

  Uint nodeIdx;
  U08  baseNodeId;
  U08  scsRaw;
  U32 abortCode;
  NodeStat *pNode;
  SdoMsgArea *pArea;
  CoSdoMsgRecord *pRecord;
  CobIdDesc *pCobIdDescList;
  CobIdDesc *pCobIdDesc;
  
  scsRaw = pMsg->data[CANOPEN_SDO_SCS_OFFSET];
  baseNodeId = CO_NODE_TO_BASE(pMsg->cobId);
  nodeIdx = pCtx->nodeToBusNodeIdx[pCtx->expdtSdoNode];
  pNode = &pCtx->pNodeStat[nodeIdx];
  
  pNode->sdoExpdtAbtSerCode = OK;
  pNode->sdoExpdtAbtCliCode = OK;
  
  /* if we are not in 100Hz slot (1-9), ignore the message */ 
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */  
  if (IS_OUTSIDE(pCtx->slotInCycle, COMGT_SDO_EXPDT_MSG_FIRST_SLOT, COMGT_SDO_EXPDT_MSG_LAST_SLOT))
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->cycles, pCtx->slotInCycle);
    nextState = E_SDOSTATE_EXPDT;
  }
  /* if it is not for the ongoing node, ignore it */
  else if (baseNodeId != pCtx->expdtSdoNode)
  {
    nextState = E_SDOSTATE_EXPDT;
  }
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  else if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* update server abort context */
    pCtx->expdtSdoAbt++;

    pNode->sdoExpdtAbtSerCnt++;
    pNode->sdoExpdtAbtSerCode = abortCode;

    memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);
    pCtx->expdtSdoNode = 0;
    nextState = E_SDOSTATE_READY;
  }
  
  /* if it is not a confirm message for SDO expedited Download/Upload Init request, send abort */
  else if (
      ((pCtx->expdtSdoScs != CANOPEN_SDO_SCS_EXPDT_UL) &&
       (pCtx->expdtSdoScs != CANOPEN_SDO_SCS_EXPDT_DL))
       ||
      ((pCtx->expdtSdoScs == CANOPEN_SDO_SCS_EXPDT_UL) &&
      ((scsRaw & CANOPEN_SDO_SCS_EXPDT_UL_MSK) != CANOPEN_SDO_SCS_EXPDT_UL))
        ||
      ((pCtx->expdtSdoScs == CANOPEN_SDO_SCS_EXPDT_DL) &&
      ((scsRaw & CANOPEN_SDO_SCS_EXPDT_DL_MSK) != CANOPEN_SDO_SCS_EXPDT_DL))
          )
  {
    /* update client abort context */

    coAbortSdoMsgBuild(pCtx, pCtx->expdtSdoNode, pCtx->lastSdoMtx, CANOPEN_SDO_ABORT_CS_ERR);
    pCtx->expdtSdoAbt++;

    pNode->sdoExpdtAbtCliCnt++;
    pNode->sdoExpdtAbtCliCode = CANOPEN_SDO_ABORT_CS_ERR;
   
    memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);
    pCtx->expdtSdoNode = 0;
    nextState = E_SDOSTATE_READY;
  }
  else
  {
    /* identify the nodeID check if it's validated one */
    pCobIdDescList = CoMgr_cobIdList[pCtx->busId];
    pCobIdDesc = &pCobIdDescList[pMsg->cobId];

    nodeIdx = pCobIdDesc->nodeIdx;

    /* get the expedited message buffer list for this node 
     * and locate one to store the current message
     */
    pArea = &pCtx->pSdoMsgArea[nodeIdx];
    pRecord = &pArea->msgQueue[pArea->written % CO_SDO_MSG_PER_NODE];

    /* Beginning of protection area */
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);

    memset (pRecord, 0, sizeof(CoSdoMsgRecord));

    /* fill the data field and create the CUC time */
    memcpy (pRecord->data, pMsg->data, CANOPEN_SDO_DATA_LENGTH);

    /* Note: SPARC Big-endian data organisation matches RET package format */
    memcpy (pRecord->cucCoarse, &pCtx->cucC32B, CO_CUC_COARSE_FIELD_LENGTH);
    memcpy (pRecord->cucFine, &pCtx->cucF16B, CO_CUC_FINE_FIELD_LENGTH);
    
    if (pCtx->expdtSdoScs == CANOPEN_SDO_SCS_EXPDT_DL)
    {
      pRecord->reqCnt = pCtx->expdtSdoDlReqLast;
      pRecord->isDownload = TRUE;
    }
    else
    {
      pRecord->reqCnt = pCtx->expdtSdoUlReqLast;
      pRecord->isDownload = FALSE;
    }

    /* mark the end of ongoing expedited SDO handling for expected base Node Id and multiplexor */
    if ((memcmp (pMsg->data+CANOPEN_SDO_SCS_INDEX_LSB_OFFSET, pCtx->lastSdoMtx, CANOPEN_SDO_MULTIPLEXOR_SIZE) == 0) &&
        (baseNodeId == pCtx->expdtSdoNode))
    {
      pCtx->expdtSdoNode = 0;
      nextState = E_SDOSTATE_READY;
      memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);
    }
    else
    {
      /* this is an unexpected SDO message */
      pRecord->reqCnt = 0;
      nextState = E_SDOSTATE_EXPDT;
    }

    /* consider it's finished and go to the next one */
    pArea->written++;

    /* End of protection area */
    ResourceLock_unlock(&pCtx->lock);
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActExpdtUdt - action to perform upon a REFRESH event
 * reception when SDO manager is in EXPDT state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActExpdtUdt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_READY;
  Uint nodeIdx;
  NodeStat *pNode;
  PARAM_NOT_USED(pMsg);
  
  /* if we are not in 100Hz slot (1-9), unexpected invocation (internal error or overrun): raise error */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */  
  if ((IS_OUTSIDE(pCtx->slotInCycle, COMGT_SDO_EXPDT_MSG_FIRST_SLOT, COMGT_SDO_EXPDT_MSG_LAST_SLOT)) && 
      (pCtx->itInCycle%2 == 0) )
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->cycles, pCtx->slotInCycle);
  }
  
  /* if there is an ongoing transfer, but no response is received, abort it */
  else
  {
    /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
    if (pCtx->expdtSdoNode != 0)
    {
      /* Build up abort SDO message */
      coAbortSdoMsgBuild(pCtx, pCtx->expdtSdoNode, pCtx->lastSdoMtx, CANOPEN_SDO_ABORT_TIMEOUT);
      nodeIdx = pCtx->nodeToBusNodeIdx[pCtx->expdtSdoNode];
      pNode = &pCtx->pNodeStat[nodeIdx];
      
      /* increment number of abort SDO messages */
      pCtx->expdtSdoAbt++;
      
      /* set abort SDO message context parameters */
      pNode->sdoExpdtAbtCliCnt++;
      pNode->sdoExpdtAbtCliCode = CANOPEN_SDO_ABORT_TIMEOUT;
      pNode->sdoExpdtAbtSerCode = OK;
      
      memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);
      pCtx->expdtSdoNode = 0;
    }
    else
    {
      ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->cycles, pCtx->slotInCycle);
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUInitMsg - action to perform upon a message event
 * reception when SDO manager is in UL_INIT state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 * 
 * @requirements
 * - SRS.DMS.CAN.FUNC.0060 [input: unsigned 8, 16]
 * - SRS.DMS.CAN.FUNC.0350
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUInitMsg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_INIT;
  SdoScsType scsType;
  SdoBlkStp  step;
  U32 abortCode;

  /* get the current step and SCS code for check: Init Block Upload Confirm expected */
  step = coULSlotToSdoBlkStep(pCtx);
  scsType = coSdoScsToType(pMsg->data[CANOPEN_SDO_SCS_OFFSET]);
  
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoUlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_DATA1) && (step != E_SDOBLKSTP_INIT1) && (step != E_SDOBLKSTP_INIT2))
  {
    /* unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_UL_INIT;
  }
  /* if it is not for the ongoing node, ignore it */
  else if (CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoUlNode)
  {
    nextState = E_SDOSTATE_UL_INIT;
  }
  /* if it is not a confirm message for SDO Upload Init request, send ABORT */
  else if (scsType != E_SDOSCS_BLK_UL_INIT)
  {
    coBlkSdoUlEnd(pCtx, CANOPEN_SDO_ABORT_CS_ERR, OK);
    nextState = E_SDOSTATE_READY;
  }
  /* check the message size and multiplexor field */
  else 
  {
    /* %COVER%TRUE% Defensive programming - wrong answer from slave equipment. */      
    if ((memcmp (pMsg->data+CANOPEN_SDO_SCS_INDEX_LSB_OFFSET,
                 pCtx->lastSdoMtx, CANOPEN_SDO_MULTIPLEXOR_SIZE) != 0) ||
        (pMsg->dataBytes != CANOPEN_SDO_DATA_LENGTH))
    {
      /* ignored, remain in the same state, so this TM will be considered as Timeout */
      ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
      nextState = E_SDOSTATE_UL_INIT;
    }
    else
    {
      /* all checks passed, send START command and go to Data1 state */
      coBlkSdoUlStartBuild(pCtx);
      nextState = E_SDOSTATE_UL_DATA1;
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUInitUdt - action to perform upon a REFRESH event
 * reception when SDO manager is in UL_INIT state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUInitUdt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_READY;
  SdoBlkStp step;
  
  PARAM_NOT_USED(pMsg);

  /* get the current step and check the expected state */
  step = coULSlotToSdoBlkStep(pCtx);
  /* If ack message has not arrived in INIT1 or INIT2 steps, it could arrive in DATA1: remain in the same state */
  if ((step == E_SDOBLKSTP_INIT1) || (step == E_SDOBLKSTP_INIT2))
  {
    nextState = E_SDOSTATE_UL_INIT;
  }
  /* %COVER%TRUE% Defensive programming - sanity check. */    
  else if (step != E_SDOBLKSTP_DATA1)
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
  }
  else
  {
    coBlkSdoUlEnd(pCtx, CANOPEN_SDO_ABORT_TIMEOUT, OK);
    nextState = E_SDOSTATE_READY;
  }

  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUDat1Msg - action to perform upon a message event
 * reception when SDO manager is in UL_DATA1 state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUDat1Msg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_DATA1;
  SdoBlkStp  step;
  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;
  U32 abortCode;

  /* get the current step for check */
  step = coULSlotToSdoBlkStep(pCtx);
  
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoUlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_DATA1) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_INIT2))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->itInCycle, step);
    nextState = E_SDOSTATE_UL_DATA1;
  }
  else 
  {
    /* if it is not for the ongoing node, ignore it */
    /* %COVER%TRUE% Defensive programming - wrong answer from slave equipment. */        
    if (CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoUlNode)
    {
      nextState = E_SDOSTATE_UL_DATA1;
    }
    else
    {
      /* now, try to use it as a data message */

      /* get the current TM buffer */
      pSdoBlkBus = pCtx->pSdoBlkTmArea;
      pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->written%(pSdoBlkBus->blks)];
     
      abortCode = coBlkUlDataMsgRecord(pCtx, pMsg, pTmRecord);
      
      if (abortCode != OK)
      {
        /* end the current transfer */
        coBlkSdoUlEnd(pCtx, abortCode, OK);
        nextState = E_SDOSTATE_READY;
      }
      else
      {
        /* message recorded, OK */
        nextState = E_SDOSTATE_UL_DATA1;
      }
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUDat1Udt - action to perform upon a REFRESH event
 * reception when SDO manager is in UL_DATA1 state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUDat1Udt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_DATA1;
  SdoBlkStp step;
  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;
  
  PARAM_NOT_USED(pMsg);

  /* get the current TM buffer */
  pSdoBlkBus = pCtx->pSdoBlkTmArea;
  pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->written%(pSdoBlkBus->blks)];

  /* get the current step and check the expected state */
  step = coULSlotToSdoBlkStep(pCtx);
  if ((step == E_SDOBLKSTP_DATA1) || (step == E_SDOBLKSTP_INIT2))
  {
    if (pTmRecord->curBlk == pTmRecord->blks)
    {
      /* if the end of block is reached,  */
      coBlkSdoUlSegCfmSend(pCtx, pTmRecord);

      pCtx->blkSdoAddList = TRUE;
      nextState = E_SDOSTATE_UL_SEGEND;
    }
    else
    {
      /* normal case, nothing to do */
      nextState = E_SDOSTATE_UL_DATA1;
    }
  }
  else
  {  
    /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */   
    if (step == E_SDOBLKSTP_DATA2)
    {
      /* go to DATA2 state */
      /* NOTE: in case no block is received during the DATA1 slots, let's try to 
       * receive the blocks in the DATA2 slots. This is a change introduced with the implementation 
       * of CR-0800. Before, a timeout was raised if no block was received in the first 10 ms. */
      nextState = E_SDOSTATE_UL_DATA2;
    }
    else
    {
      /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
      ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
      nextState = E_SDOSTATE_UL_DATA1;
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUDat2Msg - action to perform upon a message event
 * reception when SDO manager is in UL_DATA2 state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUDat2Msg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_DATA2;
  SdoBlkStp  step;
  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;
  U32 abortCode;

  /* get the current step for check */
  step = coULSlotToSdoBlkStep(pCtx);
  
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoUlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_UL_DATA2;
  }
  else 
  {
    /* if it is not for the ongoing node, ignore it */
    /* %COVER%TRUE% Defensive programming - wrong answer from slave equipment. */     
    if (CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoUlNode)
    {
      nextState = E_SDOSTATE_UL_DATA2;
    }
    else 
    {
      /* now, try to use it as a data message */

      /* get the current TM buffer */
      pSdoBlkBus = pCtx->pSdoBlkTmArea;
      pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->written%(pSdoBlkBus->blks)];
  
      abortCode = coBlkUlDataMsgRecord(pCtx, pMsg, pTmRecord);
      
      if (abortCode != OK)
      {
        /* end the current transfer */
        coBlkSdoUlEnd(pCtx, abortCode, OK);
        nextState = E_SDOSTATE_READY;
      }
      else
      {
        if (pTmRecord->curBlk == pTmRecord->blks)
        {
          /* if the end of block is reached, send segment confirm message */
          coBlkSdoUlSegCfmSend(pCtx, pTmRecord);

          pCtx->blkSdoAddList = TRUE;
          nextState = E_SDOSTATE_UL_SEGEND;
        }
        else
        {
          nextState = E_SDOSTATE_UL_DATA2;
        }
      }
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUDat2Udt - action to perform upon a REFRESH event
 * reception when SDO manager is in UL_DATA2 state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUDat2Udt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_DATA2;
  SdoBlkStp step;
  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;
  
  PARAM_NOT_USED(pMsg);

  /* get the current step and check the expected state */
  step = coULSlotToSdoBlkStep(pCtx);
  
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */       
  if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_UL_DATA2;
  }
  else
  {
    /* get the current TM buffer */
    pSdoBlkBus = pCtx->pSdoBlkTmArea;
    pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->written%(pSdoBlkBus->blks)];
    
    /* if all messages have been received, send segment confirm message */
    if (pTmRecord->curBlk == pTmRecord->blks)
    {
      /* if the end of block is reached,  */
      coBlkSdoUlSegCfmSend(pCtx, pTmRecord);

      pCtx->blkSdoAddList = TRUE;
      nextState = E_SDOSTATE_UL_SEGEND;
    }
    else
    {
      /* if all messages are not received and this is the Last slot, send ABORT message */
      if(step == E_SDOBLKSTP_END)
      {
        coBlkSdoUlEnd(pCtx, CANOPEN_SDO_ABORT_TIMEOUT, OK);
        nextState = E_SDOSTATE_READY;
      }  
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUSgmtMsg - action to perform upon a message event
 * reception when SDO manager is in UL_SEGEND state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 *
 * @requirements
 * - SRS.DMS.CAN.CMD.0100 [end of message recording]
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUSgmtMsg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_SEGEND;
  SdoBlkStp  step;
  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;
  Int segSize, expSegSize;
  SdoScsType scsType;
  U32 abortCode;

  /* get the current step for check */
  step = coULSlotToSdoBlkStep(pCtx);
  
  /* get SDO SCS code */
  scsType = coSdoScsToType(pMsg->data[0]);
  
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoUlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_UL_SEGEND;
  }
  else
  {
    /* if it is not for the ongoing node, ignore it */
    /* %COVER%TRUE% Defensive programming - wrong answer from slave equipment. */ 
    if (CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoUlNode)
    {
      nextState = E_SDOSTATE_UL_SEGEND;
    }
    else 
    {

      /* now, try to use it as an End Of Block Upload */
      /* Defensive programming - wrong answer from slave equipment. */ 
      if (scsType != E_SDOSCS_BLK_UL_END)
      {
        nextState = E_SDOSTATE_UL_SEGEND;
      }
      else
      {
        /* get the current TM buffer */
        pSdoBlkBus = pCtx->pSdoBlkTmArea;
        pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->written%(pSdoBlkBus->blks)];
  
        /* check if the last segment size is correct: n field;
         * bit 2-4 (ref to CANopen protocol definition)
         */
        segSize = CANOPEN_SDO_BLK_NBYTE_PER_SEG - 
            ((pMsg->data[0] >> CANOPEN_SDO_BLK_UL_IND_NBYTES_IN_LAST_SEG_SHIFT) &
              CANOPEN_SDO_BLK_UL_IND_NBYTES_IN_LAST_SEG_MSK);
        expSegSize = pTmRecord->nBytes - (pTmRecord->blks-1) * CANOPEN_SDO_BLK_NBYTE_PER_SEG;
  
        if (segSize != expSegSize)
        {
          abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
          nextState = E_SDOSTATE_READY;
        }
        else
        {
          /* End of Block Upload indication message checked, send back the response */
          coBlkSdoUlEndBuild (pCtx);
    
          pTmRecord->status = OK;
  
          abortCode = OK;
          nextState = E_SDOSTATE_UL_END;
        }
        coBlkSdoUlEnd(pCtx, abortCode, OK);
      }
    }
  }

  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUSgmtUdt - action to perform upon a REFRESH event
 * reception when SDO manager is in UL_SEGEND state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUSgmtUdt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_UL_SEGEND;
  SdoBlkTmArea *pSdoBlkBus;
  
  PARAM_NOT_USED(pMsg);

  /* get the current TM buffer */
  pSdoBlkBus = pCtx->pSdoBlkTmArea;
   
  /* send ABORT message */
  coBlkSdoUlEnd(pCtx, CANOPEN_SDO_ABORT_TIMEOUT, OK);
   
  nextState = E_SDOSTATE_READY;

  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActUBendCmd - action to perform upon a command event
 * reception when SDO manager is in UL_END state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActUBendCmd(CoCtx *pCtx, CoMsg *pMsg)
{
  /* the transition is performed at the current slot, 
   * so that the next SDO transfer, if requested, will be started in the next slot
   */
  CoSdoState nextState = E_SDOSTATE_READY;
  SdoBlkStp step;
  
  /* in UL END state, no command supported */
  PARAM_NOT_USED(pCtx);
  PARAM_NOT_USED(pMsg);

  /* get the current step and check the expected state */
  step = coULSlotToSdoBlkStep(pCtx);
  
  /* if we are not in the right slots, raise error */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
  if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_UL_END;
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDInitMsg - action to perform upon a message event
 * reception when SDO manager is in DL_INIT state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0380
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDInitMsg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_INIT;
  SdoScsType scsType;
  SdoBlkStp  step;
  SdoBlkDlReq *pDlReq;
  Uint idx;
  U32 abortCode;
   
  /* get the current step and SCS code for check: Init Block Download Confirm expected */
  step = coDLSlotToSdoBlkStep(pCtx);
  scsType = coSdoScsToType(pMsg->data[CANOPEN_SDO_SCS_OFFSET]);
  
  /* locate and get the ongoing download request */
  idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
  pDlReq = pCtx->pSdoBlkDlReq + idx;
  
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoDlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_INIT1) && (step != E_SDOBLKSTP_INIT2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_DL_INIT;
  }
  /* if it is not for the ongoing node, ignore it */
  else if (CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoDlNode)
  {
    nextState = E_SDOSTATE_DL_INIT;
  }
  /* if it is not a confirm message for SDO Download Init request, send ABORT */
  else if (scsType != E_SDOSCS_BLK_DL_INIT)
  {
    coBlkSdoDlEnd(pCtx, CANOPEN_SDO_ABORT_CS_ERR, OK); 
    nextState = E_SDOSTATE_READY;
  }
  /* check the message size and multiplexor field */
  else if ((memcmp (pMsg->data+CANOPEN_SDO_SCS_INDEX_LSB_OFFSET,
                    pCtx->lastSdoMtx, CANOPEN_SDO_MULTIPLEXOR_SIZE) != 0) ||
           (pMsg->dataBytes != CANOPEN_SDO_DATA_LENGTH))
  {
    /* ignored, remain in the same state, so this request will be considered as Timeout */
    nextState = E_SDOSTATE_DL_INIT;
  }
  /* check the blocksize in the message */
  else if (pMsg->data[CANOPEN_SDO_BLK_DL_CFM_BLKSZ_OFFSET] != pDlReq->blks)
  {
    abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
    coBlkSdoDlEnd(pCtx, abortCode, OK); 
    nextState = E_SDOSTATE_READY;
  }
  else
  {
    nextState = E_SDOSTATE_DL_DATA1;
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDInitUdt - action to perform upon a REFRESH event
 * reception when SDO manager is in DL_INIT state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDInitUdt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_READY;
  SdoBlkStp step;
  
  PARAM_NOT_USED(pMsg);
  
  /* get the current step and check the expected state */
  step = coDLSlotToSdoBlkStep(pCtx);
  if ((step == E_SDOBLKSTP_INIT1) || (step == E_SDOBLKSTP_INIT2))
  {
    /* Still waiting for an answer from the equipment. Keep the same SDO State */
    nextState = pCtx->sdoState;
  }
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
  else if (step != E_SDOBLKSTP_DATA1)
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
  }
  else
  {
    /* answer from the equipment not received within 10ms: timeout */
    coBlkSdoDlEnd(pCtx, CANOPEN_SDO_ABORT_TIMEOUT, OK); 
    nextState = E_SDOSTATE_READY;
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDDat1Udt - action to perform upon a REFRESH event
 * reception when SDO manager is in DL_DATA1 state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function  
 * @return next state of the CAN Bus Manager
 * 
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDDat1Udt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_DATA1;
  SdoBlkStp  step;
  SdoBlkDlReq *pDlReq;
  U16 blks;
  Uint idx;

  PARAM_NOT_USED(pMsg);

  /* get the current step for check */
  step = coDLSlotToSdoBlkStep(pCtx);

  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
  if ((step != E_SDOBLKSTP_DATA1) && (step != E_SDOBLKSTP_INIT2))
  {
    /* unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_DL_DATA1;
  }
  else
  {
    /* locate and get the ongoing download request */
    idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
    pDlReq = pCtx->pSdoBlkDlReq + idx;

    /* Send the data blocks.
     * Note: blocks sent in a slot: limited to the half of max SDO block
     */
    blks = MIN(pDlReq->blks, CO_SDO_BLK_DL_SEGS_MAX_IN_SLOT);
    coBlkSdoDlDataMsgSend(pCtx, blks, pDlReq);

    nextState = E_SDOSTATE_DL_DATA2;
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDDat2Udt - action to perform upon a REFRESH event
 * reception when SDO manager is in DL_DATA2 state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function  
 * @return next state of the CAN Bus Manager
 * 
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDDat2Udt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_DATA2;
  SdoBlkStp  step;
  SdoBlkDlReq *pDlReq;
  U16 blks;
  Uint idx;

  PARAM_NOT_USED(pMsg);
  
  /* get the current step for check */
  step = coDLSlotToSdoBlkStep(pCtx);

  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
  if ((step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_DL_DATA2;
  }
  else
  {
    /* locate and get the current download request and get data size */
    idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
    pDlReq = pCtx->pSdoBlkDlReq + idx;
    
    /* the blocks sent in a slot: remaining blocks */
    blks = pDlReq->blks - pDlReq->curBlk;
    
    /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
    if (blks > CO_SDO_BLK_DL_SEGS_MAX_IN_SLOT)
    {
      ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, blks);
      nextState = E_SDOSTATE_DL_DATA2;
    }
    else
    {
      /* send the remaining part */
      if (blks > 0)
      {
        coBlkSdoDlDataMsgSend(pCtx, blks, pDlReq);
      }
      nextState = E_SDOSTATE_DL_SEGEND1;
    }
  }
  
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDDat2Msg - action to perform upon a message event
 * reception when SDO manager is in DL_DATA2 state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, 
 * @return next state of the CAN Bus Manager
 * 
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDDat2Msg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_SEGEND1;
  SdoScsType scsType;
  SdoBlkStp  step;
  SdoBlkDlReq *pDlReq;
  U32 abortCode = 0;
  Uint idx;

  /* locate and get the current download request */
  idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
  pDlReq = pCtx->pSdoBlkDlReq + idx;
    
  /* get the current step and SCS code for check: Last Block Download reception Confirm expected */
  step = coDLSlotToSdoBlkStep(pCtx);
  scsType = coSdoScsToType(pMsg->data[CANOPEN_SDO_SCS_OFFSET]);
    
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoDlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_DL_SEGEND1;
  }
  else 
  {
    /* if it is not for the ongoing node, ignore it */
    /* %COVER%TRUE% Defensive programming - wrong answer from slave equipment. */     
    if ((CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoDlNode) 
        || (pMsg->dataBytes != CANOPEN_SDO_DATA_LENGTH))
    {
      nextState = E_SDOSTATE_DL_SEGEND1;
    }
    /* if it is not SDO Download segment end confirm message, send ABORT */
    else if (scsType != E_SDOSCS_BLK_DL_SEG)
    {
      abortCode = CANOPEN_SDO_ABORT_CS_ERR;
      coBlkSdoDlEnd(pCtx, abortCode, OK);
      nextState = E_SDOSTATE_READY;
    }
    /* if the ackseq field is not correct, send ABORT */
    else if (pMsg->data[CANOPEN_SDO_BLK_DL_SEG_CFM_ACKSEQ_OFFSET] != pDlReq->blks)
    {
      /* ignored, remain in the same state, so this request will be considered as Timeout */
      abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
      coBlkSdoDlEnd(pCtx, abortCode, OK);
      nextState = E_SDOSTATE_READY;
    }
    /* now, all checks OK */
    else
    {
      /* build End SDO Block Download message */
      coBlkSdoDlEndMsgBuild(pCtx);
      nextState = E_SDOSTATE_DL_SEGEND2;
    }
  }  
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDSgt1Udt - action to perform upon a REFRESH event
 * reception when SDO manager is in DL_SEGEND1 state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDSgt1Udt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_READY;
  SdoBlkStp step;
  SdoBlkDlReq *pDlReq;
  U16 blks;
  Uint idx;
  
  PARAM_NOT_USED(pMsg);

  /* get the current step and check the expected state */
  step = coDLSlotToSdoBlkStep(pCtx);

  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
  if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA1) && (step != E_SDOBLKSTP_DATA2))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
  }
  else
  {
    if (step == E_SDOBLKSTP_END)
    {
      /* locate and get the current download request and get data size */
      idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
      pDlReq = pCtx->pSdoBlkDlReq + idx;
      
      /* check remaining blocks */
      blks = pDlReq->blks - pDlReq->curBlk;
      
      /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */     
      if (blks != 0)
      {
        /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
        ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, blks);
      }
      else
      {
        coBlkSdoDlEnd(pCtx, CANOPEN_SDO_ABORT_TIMEOUT, OK);
        nextState = E_SDOSTATE_READY;
      }
    }
    else
    {
      /* Still not reached last Step */
      nextState = pCtx->sdoState;
    }
  }
  
  return nextState;
}


/***********************************************************************/
/**
 * @brief coSdoActDSgt1Msg - action to perform upon a message event
 * reception when SDO manager is in DL_SEGEND1 state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 *  
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDSgt1Msg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_SEGEND1;
  SdoScsType scsType;
  SdoBlkStp  step;
  SdoBlkDlReq *pDlReq;
  Uint idx;
  U32 abortCode = 0;

  /* locate and get the current download request */
  idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
  pDlReq = pCtx->pSdoBlkDlReq + idx;
  
  /* get the current step and SCS code for check: End Block Download message expected */
  step = coDLSlotToSdoBlkStep(pCtx);
  scsType = coSdoScsToType(pMsg->data[CANOPEN_SDO_SCS_OFFSET]);

  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoDlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if we are not in the right slots, ignore the message */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
  else if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
    nextState = E_SDOSTATE_DL_SEGEND1;
  }
  else 
  {
    /* if it is not for the ongoing node, ignore it */
    /* %COVER%TRUE% Defensive programming - wrong answer from slave equipment. */     
    if ((CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoDlNode) 
        || (pMsg->dataBytes != CANOPEN_SDO_DATA_LENGTH))
    {
      nextState = E_SDOSTATE_DL_SEGEND1;
    }
    /* if it is not SDO Download segment end confirm message, send ABORT */
    else if (scsType != E_SDOSCS_BLK_DL_SEG)
    {
      abortCode = CANOPEN_SDO_ABORT_CS_ERR;
      coBlkSdoDlEnd(pCtx, abortCode, OK);
      nextState = E_SDOSTATE_READY;
    }
    /* if the ackseq field is not correct, send ABORT */
    else if (pMsg->data[CANOPEN_SDO_BLK_DL_SEG_CFM_ACKSEQ_OFFSET] != pDlReq->blks)
    {
      /* ignored, remain in the same state, so this request will be considered as Timeout */
      abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
      coBlkSdoDlEnd(pCtx, abortCode, OK);
      nextState = E_SDOSTATE_READY;
    }
    /* now, all checks OK */
    else
    {
      /* build End SDO Block Download message */
      coBlkSdoDlEndMsgBuild(pCtx);
      nextState = E_SDOSTATE_DL_SEGEND2;
    }
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDSgt2Udt - action to perform upon a REFRESH event
 * reception when SDO manager is in DL_SEGEND2 state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDSgt2Udt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_END;
  SdoBlkStp step;
  
  PARAM_NOT_USED(pMsg);

  /* get the current step and check the expected state */
  step = coDLSlotToSdoBlkStep(pCtx);
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */    
  if ((step != E_SDOBLKSTP_END) && (step != E_SDOBLKSTP_DATA2) && (step != E_SDOBLKSTP_DATA1))
  {
    /* Unexpected situation: unexpected invocation (internal error or overrun): raise error */
    ERROR_REPORT(SW_ERROR, pCtx->busId, pCtx->slotInCycle, step);
  }
  else
  { 
    /* initialise the timeout flag */
    pCtx->sdoDlBendTimeout = FALSE;
    
    nextState = E_SDOSTATE_DL_END;
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDBendUdt - action to perform upon a REFRESH event
 * reception when SDO manager is in DL_END state
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message, N/A for this function 
 * @return next state of the CAN Bus Manager
 *
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDBendUdt(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_READY;

  PARAM_NOT_USED(pMsg);

  /* Check if timeout is authorised */
  if(pCtx->sdoDlBendTimeout == TRUE)
  {
    coBlkSdoDlEnd(pCtx, CANOPEN_SDO_ABORT_TIMEOUT, OK);

    /* reset the timeout flag */
    pCtx->sdoDlBendTimeout = FALSE;
    
    nextState = E_SDOSTATE_READY;
  }
  else
  {
    /* This is the 200Hz slot after sending the end message. Keep the same SDO State */
    nextState = pCtx->sdoState;
    
    /* next 200Hz slot there will be a timeout if response is not received */
    pCtx->sdoDlBendTimeout = TRUE;
  }
  
  return nextState;
}

/***********************************************************************/
/**
 * @brief coSdoActDBendMsg - action to perform upon a message event
 * reception when SDO manager is in DL_END state.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg      The pointer to the received SDO message 
 * @return next state of the CAN Bus Manager
 * 
 ***********************************************************************/ 
PRIVATE CoSdoState coSdoActDBendMsg(CoCtx *pCtx, CoMsg *pMsg)
{
  CoSdoState nextState = E_SDOSTATE_DL_END;
  SdoScsType scsType;
  U32 abortCode;
  
  /* get the current SCS code for check: SDO Download segment end confirm message expected */
  scsType = coSdoScsToType(pMsg->data[CANOPEN_SDO_SCS_OFFSET]);
  
  /* if it is a abort SDO transfer request from the server, stop the transfer */
  if (coAbortSdoMsgCheck(pMsg, pCtx->lastSdoMtx, &abortCode) == TRUE)
  {
    /* end the transfer with the server's abort code */
    coBlkSdoDlEnd(pCtx, OK, abortCode);
    nextState = E_SDOSTATE_READY;
  }
  /* if it is not for the ongoing node, ignore it */
  else if ((CO_NODE_TO_BASE(pMsg->cobId) != pCtx->blkSdoDlNode) 
        || (pMsg->dataBytes != CANOPEN_SDO_DATA_LENGTH))
  {
    nextState = E_SDOSTATE_DL_END;
  }
  /* if it is not SDO Download segment end confirm message, send ABORT */
  else if (scsType != E_SDOSCS_BLK_DL_END)
  {
    abortCode = CANOPEN_SDO_ABORT_CS_ERR;
    coBlkSdoDlEnd(pCtx, abortCode, OK);
    nextState = E_SDOSTATE_READY;
  }
  /* now, all checks OK */
  else
  {
    /* consider it is finished, then go to the next TC request */
    coBlkSdoDlEnd(pCtx, OK, OK);
    
    /* As the PDO is expected in nominal case, the current absolute slot count
     * is stored for Buffer Support PDO reception timeout (hold-on period) detection purpose.
     * If the timeout is reached without expected PDo message, other SDO transfers are enabled
     * anyway.
     */
    pCtx->blkSdoDlLastSlotsCnt = pCtx->cycles * CO_SLOTS_IN_CYCLE + pCtx->slotInCycle;

     /* go back to READY state */
    nextState = E_SDOSTATE_READY;
  }
  return nextState;
}

/***********************************************************************/
/**
 * @brief  coSdoTransGet - get the transition corresponding to current event 
 * 
 * @param[in] event The incoming event to be handled
 * @param[in] state The current automaton's state
 * @return   pointer to the matched transition from
 *  the transition table, or Null if there is no transition associated to
 *  the couple (state, event). In such a case, no action to be taken
 *  for this event in the current state.
 *
 ***********************************************************************/ 
PRIVATE CoSdoTrans const *coSdoTransGet(CoSdoEvt event, CoSdoState state)
{
  CoSdoTrans const *pTrans;
  Boolean found;

  /* Search what transition applies (for current event in current state) */
  pTrans = &canOpenSdoTrans[0];
  found =  FALSE;
  
  while ((pTrans->state != E_SDOSTATE_END) && (found == FALSE))
  {
    /* check both event and state */
    if ((pTrans->state == state) && (pTrans->evt == event))
    {
      /* Transition found */
      found = TRUE;
    }
    else
    {
      pTrans++;
    } 
  }
  
  if (found == FALSE)
  {
    /* No action found */
    pTrans =  NULL;
  }
  return pTrans;
}

/***********************************************************************/
/**
 * @brief  coSdoAutom - engine of the CAN Bus SDO state machine 
 * 
 * This function, from input event, searches for the transition descriptor
 * corresponding to the event in the current state if any, and performs
 * the 'action' associated to the transition. Finally, it updates
 * the state of the current state machine.
 *
 * This function is used to manager both platform and payload CAN Bus.
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] evt       The incoming event to be handled
 * @param[in] pMsg      The incoming sdo message to be handled
 * @return    N/A
 * 
 ***********************************************************************/ 
PRIVATE void coSdoAutom(CoCtx *pCtx, CoSdoEvt evt, CoMsg *pMsg)
{
  CoSdoState state;
  CoSdoTrans const *pTrans = NULL;

  /* identify the action */
  pTrans = coSdoTransGet(evt, pCtx->sdoState);

  /* Perform the action associated to the transition.
   * When the action has been performed, the "new" state is returned
   * by the action.
   */
  /* Defensive programming - ERROR_REPORT macro called here. */
  if (pTrans != NULL)
  {
    state = pTrans->act(pCtx, pMsg);
    /* state transition occurred: update context */
    if (state != pCtx->sdoState)
    {   
      pCtx->sdoState = state;
      pCtx->nSdoTrans++;
    }
  }
}
/***********************************************************************/
/**
 * @brief  coSdoScsToType - translate SDO SCS field to message type
 * 
 * @param[in] scs: SDO SCS field
 * @return corresponding message type
 *
 ***********************************************************************/ 
PRIVATE SdoScsType coSdoScsToType(U08 scs)
{
  Uint i;
  Bool found = FALSE;
  SdoScsType type = E_SDOSCS_UNKNOWN;
  static SdoScsTypeDesc scsTypeList [] = 
  {
    {CANOPEN_SDO_SCS_EXPDT_UL_MSK, CANOPEN_SDO_SCS_EXPDT_UL, E_SDOSCS_EXPDT_UL},
    {CANOPEN_SDO_SCS_EXPDT_DL_MSK, CANOPEN_SDO_SCS_EXPDT_DL, E_SDOSCS_EXPDT_DL},
    {CANOPEN_SDO_BLK_UL_INIT_CFM_MSK, CANOPEN_SDO_BLK_UL_INIT_CFM, E_SDOSCS_BLK_UL_INIT},
    {CANOPEN_SDO_BLK_UL_END_IND_MSK, CANOPEN_SDO_BLK_UL_END_IND, E_SDOSCS_BLK_UL_END},
    {CANOPEN_SDO_BLK_DL_INIT_CFM_MSK, CANOPEN_SDO_BLK_DL_INIT_CFM, E_SDOSCS_BLK_DL_INIT},
    {CANOPEN_SDO_BLK_DL_SEG_CFM_MSK, CANOPEN_SDO_BLK_DL_SEG_CFM, E_SDOSCS_BLK_DL_SEG},
    {CANOPEN_SDO_BLK_DL_END_CFM_MSK, CANOPEN_SDO_BLK_DL_END_CFM, E_SDOSCS_BLK_DL_END},
    {0, CANOPEN_SDO_BLK_NONE_MSG, E_SDOSCS_END} 
  };
  
  /* simple search in the list with break when found */
  for (i = 0; (i < NELEMENTS(scsTypeList))&&(!found); i++)
  {
    /* stop condition evaluation */
    if ((scsTypeList[i].msk & scs) == scsTypeList[i].scs)
    {
      type = scsTypeList[i].type;
      found = TRUE;
    }
  }
  return type;
}

/***********************************************************************/
/**
 * @brief  coULSlotToSdoBlkStep - get pre-defined slot usage for SDO Block 
 * Uplink transfer 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return N/A
 * 
 * @requirements
 * - SRS.DMS.CAN.PERF.0110 [SDO] 
 * 
 ***********************************************************************/ 
PRIVATE SdoBlkStp coULSlotToSdoBlkStep(CoCtx *pCtx)
{
  U32 i;
  SdoBlkStp step;
  Int curBlk = -1; /* not valid */
  
  static SdoBlkStp stepList[CO_BLOCK_SDO_WIN_LENGTH_TIMER_STEPS] =
  {
    E_SDOBLKSTP_INIT1,
    E_SDOBLKSTP_INIT2,
    E_SDOBLKSTP_DATA1,
    E_SDOBLKSTP_DATA1,
    E_SDOBLKSTP_DATA2,
    E_SDOBLKSTP_DATA2,
    E_SDOBLKSTP_DATA2,    
    E_SDOBLKSTP_DATA2,
    E_SDOBLKSTP_END
  };
  
  /* identify the block */
  for (i = 0; i < pCtx->sdoBlks; i++)
  {
    if ((pCtx->itInCycle >= pCtx->sdoBlkULStartTimerSlot[i]) &&
        (pCtx->itInCycle < (pCtx->sdoBlkULStartTimerSlot[i] + CO_BLOCK_SDO_WIN_LENGTH_TIMER_STEPS)))
    {
      curBlk = i;
    }
  }
  
  /* for N/A */
  if (curBlk < 0)
  {
    step = E_SDOBLKSTP_NONE;
  }
  else
  {
    /* get the offset */
    step = stepList[(pCtx->itInCycle - pCtx->sdoBlkULStartTimerSlot[curBlk])];
  }  
  return step;
}

/***********************************************************************/
/**
 * @brief  coDLSlotToSdoBlkStep - get pre-defined slot usage for SDO Block Downlink transfer 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return N/A
 * 
 * @requirements
 * - SRS.DMS.CAN.PERF.0110 [SDO] 
 * 
 ***********************************************************************/ 
PRIVATE SdoBlkStp coDLSlotToSdoBlkStep(CoCtx *pCtx)
{
  U32 i;
  SdoBlkStp step;
  Int curBlk = -1; /* not valid */
  
  static SdoBlkStp stepList[CO_BLOCK_SDO_WIN_LENGTH_TIMER_STEPS-1] =
  {
    E_SDOBLKSTP_INIT1,
    E_SDOBLKSTP_INIT2,
    E_SDOBLKSTP_DATA1,
    E_SDOBLKSTP_DATA1,
    E_SDOBLKSTP_DATA2,
    E_SDOBLKSTP_DATA2,    
    E_SDOBLKSTP_END,
    E_SDOBLKSTP_END
  };
  
  /* identify the block */
  for (i = 0; i < pCtx->sdoBlks; i++)
  {
    if ((pCtx->itInCycle >= (pCtx->sdoBlkDLStartTimerSlot[i])) &&
        (pCtx->itInCycle < (pCtx->sdoBlkDLStartTimerSlot[i] + CO_BLOCK_SDO_WIN_LENGTH_TIMER_STEPS - 1)))
    {
      curBlk = i;
    }
  }
  
  /* for N/A */
  if (curBlk < 0)
  {
    step = E_SDOBLKSTP_NONE;
  }
  else
  {
    /* get the offset */
    step = stepList[(pCtx->itInCycle - pCtx->sdoBlkDLStartTimerSlot[curBlk])];
  }  
  return step;
}

/***********************************************************************/
/**
 * @brief  coExpeditedSdoMsgBuild - Build up expedited SDO message
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return Flag indicating if a message has been built
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0250 [SDO TC Sending/SDO TM request]
 * - SRS.DMS.CAN.CMD.0120 [request handling]
 * - SRS.DMS.CAN.CMD.0130 [request handling]
 ***********************************************************************/ 
PRIVATE Bool coExpeditedSdoMsgBuild(CoCtx *pCtx)
{
  CoStatus coSts;
  CoMsg *pCoMsg;
  NodeStat *pNode;
  Uint nodeIdx;
  Uint idx; 
  Bool msg = FALSE;
  
  /* BEGIN: protect the modification of expedited SDO TC/TM request queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  /* expedited SDO TC has a high priority than TM */
  if (pCtx->expdtSdoDlIn > pCtx->expdtSdoDlOut)
  {
    /* get the next command from request queue */
    idx = pCtx->expdtSdoDlOut%CO_EXPDT_SDO_DL_QUEUE_LENGTH;
    pCoMsg = &pCtx->expdtSdoDlQueue[idx].msg;
    
    /* save the last handled request number */
    pCtx->expdtSdoDlReqLast = pCtx->expdtSdoDlQueue[idx].reqCnt;
    
    /* prepare expected SCS for check purpose */
    pCtx->expdtSdoScs = CANOPEN_SDO_SCS_EXPDT_DL;
        
    /* get its index in the node list and update its state */
    nodeIdx = pCtx->nodeToBusNodeIdx[CO_NODE_TO_BASE(pCoMsg->cobId)];
    pNode = &pCtx->pNodeStat[nodeIdx];
    pNode->sdoExpdtDlTotal++;
    
    /* go to the next one */
    pCtx->expdtSdoDlOut++;

    msg = TRUE;
  }
  else if (pCtx->expdtSdoUlIn > pCtx->expdtSdoUlOut)
  {
    /* get the next command from request Queue */
    idx = pCtx->expdtSdoUlOut%CO_EXPDT_SDO_UL_QUEUE_LENGTH;
    pCoMsg = &pCtx->expdtSdoUlQueue[idx].msg;
    
    /* save the last handled request number */
    pCtx->expdtSdoUlReqLast = pCtx->expdtSdoUlQueue[idx].reqCnt;
    
    /* prepare the expected SCS for check purpose */
    pCtx->expdtSdoScs = CANOPEN_SDO_SCS_EXPDT_UL;
    
    /* get its index in the node list and update its state */
    nodeIdx = pCtx->nodeToBusNodeIdx[CO_NODE_TO_BASE(pCoMsg->cobId)];
    pNode = &pCtx->pNodeStat[nodeIdx];
    pNode->sdoExpdtUlTotal++;
    
    /* go to the next one */
    pCtx->expdtSdoUlOut++;
    msg = TRUE;
  }
  else
  {
    msg = FALSE;
    pCoMsg = NULL; /* to avoid warning message */
  }
  
  if (msg)
  {
    /* store the description of the current SDO message */
    pCtx->expdtSdoNode = CO_NODE_TO_BASE(pCoMsg->cobId);
    memcpy (pCtx->lastSdoMtx, &pCoMsg->data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET],
      CANOPEN_SDO_MULTIPLEXOR_SIZE);
    
    /* build the message in the list */
    coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                    pCoMsg->cobId, pCoMsg->rtr, pCoMsg->dataBytes, pCoMsg->data);

    /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */    
    if (coSts == E_COSTATUS_OK)
    {
      /* one message added in the list */
      pCtx->msgsInCurList++;
      pCtx->sdoMsgsOut++;
    }
    else
    {
      ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
    }
  } /* if */

  /* END: protect the modification of expedited SDO TC/TM request queues * */
  ResourceLock_unlock(&pCtx->lock);
  
  return msg;
}

/***********************************************************************/
/**
 * @brief  coAbortSdoMsgBuild - Build up abort SDO message
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] node      The SDO server Node ID
 * @param[in] pMtx      The current multiplexor
 * @param[in] code      The reason for the abort
 * 
 * @return N/A
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0060 [output: unsigned 8, 16, 32]
 * 
 ***********************************************************************/ 
PRIVATE void coAbortSdoMsgBuild(CoCtx *pCtx, U08 node, U08 *pMtx, U32 code)
{
  CoStatus coSts;
  CoMsg coMsg;
  CoMsg *pCoMsg;
  U32 abortCode;
    
  coMsg.cobId = CANOPEN_COB_RSDO(node);
  coMsg.rtr = CANOPEN_SDO_RTR;
  coMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
  coMsg.data[CANOPEN_SDO_CCS_OFFSET] = CANOPEN_SDO_CS_ABORT;

  memcpy (&coMsg.data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET], pMtx,
    CANOPEN_SDO_MULTIPLEXOR_SIZE);
  abortCode = code;
  
  memcpy (&coMsg.data[CANOPEN_SDO_ABORT_DATA_OFFSET], &abortCode,
    CANOPEN_SDO_ABORT_DATA_LENGTH);
   
  /* build the message in the list */
  pCoMsg = &coMsg;
  coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                  pCoMsg->cobId, pCoMsg->rtr, pCoMsg->dataBytes, pCoMsg->data);

  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */    
  if (coSts == E_COSTATUS_OK)
  {
    /* one message added in the list */
    pCtx->msgsInCurList++;
    pCtx->sdoMsgsOut++;
  }
  else
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
  }
  return;
}

/***********************************************************************/
/**
 * @brief  coAbortSdoMsgCheck - Check the abort SDO message
 * 
 * @param[in] pMsg        The pointer to the SDO Abort message for check.
 * @param[in] pMtx        The pointer to the multiplexor of the ongoing SDO transfer
 * @param[out] pAbortCode The buffer to store the received abort code if the message
 *                   is a valid 
 * @return - @link TRUE @endlink if the message is valid  SDO abort message
 *         - @link FALSE @endlink otherwise
 *
 * 
 ***********************************************************************/ 
PRIVATE Bool coAbortSdoMsgCheck(CoMsg *pMsg, U08 *pMtx, U32 *pAbortCode)
{
  U32 abortCode;
  Bool result = FALSE;
  U32 idx;
  U32 listLength;
  
  /* list of the SDO abort code defined by CANOpen standard */
  static U32 allowedRcvdAbortCode [] =
  {
    CANOPEN_SDO_ABORT_TGL_BIT_ERR,
    CANOPEN_SDO_ABORT_TIMEOUT,
    CANOPEN_SDO_ABORT_CS_ERR,
    CANOPEN_SDO_ABORT_BLK_SIZE_ERR,
    CANOPEN_SDO_ABORT_SEQ_NUM_ERR,
    CANOPEN_SDO_ABORT_CRC_ERR,
    CANOPEN_SDO_ABORT_OUT_OF_MEM,
    CANOPEN_SDO_ABORT_UNSUP_ACCESS,
    CANOPEN_SDO_ABORT_WRONLY_OBJ,
    CANOPEN_SDO_ABORT_RDONLY_OBJ,
    
    CANOPEN_SDO_ABORT_NO_OBJ,
    CANOPEN_SDO_ABORT_OBJ_NO_PDO,
    CANOPEN_SDO_ABORT_OBJ_EXCEED_PDO,
    CANOPEN_SDO_ABORT_PARAM_ERR,
    CANOPEN_SDO_ABORT_DEVICE_ERR,
    CANOPEN_SDO_ABORT_ACCESS_HW_ERR,
    CANOPEN_SDO_ABORT_DTYPE_NO_MATCH,
    CANOPEN_SDO_ABORT_DTYPE_TOO_HIGH,
    CANOPEN_SDO_ABORT_NO_SUBIDX,
    
    CANOPEN_SDO_ABORT_VAL_EXCEED,
    CANOPEN_SDO_ABORT_VAL_TOO_HIGH, 
    CANOPEN_SDO_ABORT_TOO_LOW,
    CANOPEN_SDO_ABORT_VAL_MAX_ERR,
    CANOPEN_SDO_ABORT_GENERAL_ERR,
    CANOPEN_SDO_ABORT_DATA_STORE_ERR,
    CANOPEN_SDO_ABORT_DATA_STORE_DENY,
    CANOPEN_SDO_ABORT_DEV_STATE_ERR,
    CANOPEN_SDO_ABORT_DYN_OBJ_FAIL
  };

  /* check the message content: SCS code + multiplexor */
  if ((memcmp (&pMsg->data[CANOPEN_SDO_SCS_INDEX_LSB_OFFSET], pMtx,
               CANOPEN_SDO_MULTIPLEXOR_SIZE) == 0) &&
      (pMsg->data[CANOPEN_SDO_SCS_OFFSET] == CANOPEN_SDO_CS_ABORT))
  {
    /* check the aborted code: defined by CANOpen standard */
    listLength = NELEMENTS(allowedRcvdAbortCode);
    memcpy (&abortCode, &pMsg->data[CANOPEN_SDO_ABORT_DATA_OFFSET],
      CANOPEN_SDO_ABORT_DATA_LENGTH); 
        
    for (idx = 0; ((idx < listLength) & (!result)); idx++)
    {
      if (abortCode == allowedRcvdAbortCode[idx])
      {
        *pAbortCode = abortCode;
        result = TRUE;
      }
    }
  }
  
  return result;
}

/***********************************************************************/
/**
 * @brief  coBlkSdoUlInitMsgBuild - Build up Block SDO Initiate message
 * according to Buffer Support PDO message
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return Flag indicating if a message has been built
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0200 [Buffer Support PDO message handling for upload]
 * - SRS.DMS.CAN.FUNC.0210 [Buffer Support PDO message decoding]
 * - SRS.DMS.CAN.FUNC.0220
 * - SRS.DMS.CAN.FUNC.0270 [SDO Block Upload size]
 * - SRS.DMS.CAN.FUNC.0281 [SDO Block Upload Sub-index]
 * - SRS.DMS.CAN.FUNC.0390
 * - SRS.DMS.CAN.FUNC.0950 [Start Upload request in right slot]
 * 
 ***********************************************************************/ 
PRIVATE Bool coBlkSdoUlInitMsgBuild(CoCtx *pCtx)
{
  CoStatus coSts;
  SdoBlkUlReq *pReq;
  CoMsg initMsg;
  Uint idx;
  U32 nBlks;
  SdoBlkTmArea *pSdoBlkBus;
  CoSdoBlkTmRecord *pTmRecord;
  Bool msg = FALSE;
  SdoBlkStp step;
  SdoBlkExec *pExec;
  
  /* check if we are in the right slots to start a Block SDO transfer */
  step = coULSlotToSdoBlkStep(pCtx);
  if (step != E_SDOBLKSTP_INIT1)  /* Func.950 */
  {
    msg = FALSE;
  }
  else if (pCtx->sdoUlIn > pCtx->sdoUlOut)
  {
    /* BEGIN: protect the modification of Block SDO TC/TM request queues */
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
    
    /* get the Upload request queue (issued by Buffer Support PDO message or TC(2,131) */
    if ((pCtx->sdoUlIn - pCtx->sdoUlOut) > CO_BLK_SDO_UL_QUEUE_LENGTH)
    {
      /* if request queue overwritten */
      pCtx->sdoUlOut = pCtx->sdoUlIn - CO_BLK_SDO_UL_QUEUE_LENGTH;
    }
    
    idx = pCtx->sdoUlOut%CO_EXPDT_SDO_UL_QUEUE_LENGTH;
    pReq = &pCtx->sdoBlkUlReq[idx];
    
    /* number of segments: up-rounding the data size for segment and less than the limit */ 
    nBlks = (pReq->nBytes + CANOPEN_SDO_BLK_NBYTE_PER_SEG - 1)/CANOPEN_SDO_BLK_NBYTE_PER_SEG;
    nBlks = MIN(nBlks, CANOPEN_SDO_BLK_SEGS_MAX);

    /* build the message for Initiate SDO Block Upload */
    initMsg.cobId     = CANOPEN_COB_RSDO(pReq->node);
    initMsg.rtr       = CANOPEN_SDO_RTR;
    initMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
    
    /* fill in the following fields:
      * - ccs/cs/cs
      * - index
      * - sub index
      * - blksize
      * - pst 
      */
    memset (initMsg.data, 0, CANOPEN_SDO_DATA_LENGTH);
    initMsg.data[CANOPEN_SDO_CCS_OFFSET]   = CANOPEN_SDO_CCS_BLK_UL_INIT;
    initMsg.data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET] = (U08) (pReq->objIdx & U08_MAX); 
    initMsg.data[CANOPEN_SDO_CCS_INDEX_MSB_OFFSET] = (U08) ((pReq->objIdx>>SHF_8BIT) & U08_MAX);
    initMsg.data[CANOPEN_SDO_CCS_SUBIDX_OFFSET]= (U08) (pReq->objSubIdx & U08_MAX);
    initMsg.data[CANOPEN_SDO_BLK_UL_REQ_BLKSZ_OFFSET] = nBlks;
    initMsg.data[CANOPEN_SDO_BLK_UL_REQ_PST_OFFSET]   = CANOPEN_SDO_BLK_PST_NOT_ALLOWED;
    /* store the ongoing SDO exchange context */
    pCtx->blkSdoUlNode = pReq->node;
    
    memcpy (pCtx->lastSdoMtx, &initMsg.data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET],
      CANOPEN_SDO_MULTIPLEXOR_SIZE);
  
    /* store the current BSP and description of the transfer with reserved TM buffer */
    pSdoBlkBus = pCtx->pSdoBlkTmArea;

    pTmRecord = &pSdoBlkBus->pBlkQueue[pSdoBlkBus->written%(pSdoBlkBus->blks)];
    
    /* build up descriptor */
    pTmRecord->status = CAN_STS_ABORTED;
    pTmRecord->node = pReq->node;
    pTmRecord->blks = nBlks;
    pTmRecord->curBlk = 0;
    pTmRecord->nBytes = MIN(pReq->nBytes, CO_SDO_BLK_DATA_LENGTH_MAX);
    
    /* store associated Buffer Support PDO message data bytes if the request is issued by BSP */
    if (pReq->pdoReq)
    {
      memcpy (&pTmRecord->pdoData, pReq->pdoData, CO_OD_BSP_DATA_LENGTH);
    }
    
    /* time-stamp with the current CUC time */
    memcpy (pTmRecord->cucCoarse, &pCtx->cucC32B, CO_CUC_COARSE_FIELD_LENGTH);
    memcpy (pTmRecord->cucFine, &pCtx->cucF16B, CO_CUC_FINE_FIELD_LENGTH);
    
    /* Store the request part in the execution result */
    pExec = &pCtx->sdoUlExecQueue[pCtx->sdoUlExecIn%CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH];
    
    memset (pExec, 0, sizeof(SdoBlkExec));
    pExec->node   = pReq->node;
    pExec->nBytes = pTmRecord->nBytes;
    pExec->objIdx = pReq->objIdx;
    pExec->reqCnt = pReq->reqCnt;

    /* move to the next request */
    pCtx->sdoUlOut++;
    
    /* build the message in the list */
    coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                    initMsg.cobId, initMsg.rtr, initMsg.dataBytes, initMsg.data);
    /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
    if (coSts == E_COSTATUS_OK)
    {
      /* one message added in the list */
      pCtx->msgsInCurList++;
      pCtx->sdoMsgsOut++;
      msg = TRUE;
    }
    else
    {
      ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
      msg = FALSE;
    }
    /* END: protect the modification of expedited SDO TC/TM request queues * */
    ResourceLock_unlock(&pCtx->lock);
  }
  
  return msg;
}
/***********************************************************************/
/**
 * @brief  coBlkSdoUlStartBuild - Build up Block SDO Start message
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return N/A
 *
 ***********************************************************************/ 
PRIVATE void coBlkSdoUlStartBuild(CoCtx *pCtx)
{
  CoStatus coSts;
  CoMsg coMsg;
  
  /* BEGIN: protect the modification of Block SDO TC/TM request queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  /* build the message for Start SDO Block Upload */
  coMsg.cobId     = CANOPEN_COB_RSDO(pCtx->blkSdoUlNode);
  coMsg.rtr       = CANOPEN_SDO_RTR;
  coMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
  
  /* fill in the following fields:
    * - ccs = 5
    * - X = 0
    * - cs = 3
    * - reserved = 0
    */
  memset (coMsg.data, 0, CANOPEN_SDO_DATA_LENGTH);
  coMsg.data[CANOPEN_SDO_CCS_OFFSET]   = CANOPEN_SDO_CCS_BLK_UL_START;

  /* build the message in the list */
  coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                  coMsg.cobId, coMsg.rtr, coMsg.dataBytes, coMsg.data);
  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
  if (coSts == E_COSTATUS_OK)
  {
    /* one message added in the list */
    pCtx->msgsInCurList++;
    pCtx->sdoMsgsOut++;
  }
  else
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
  }
  /* END: protect the modification of expedited SDO TC/TM request queues * */
  ResourceLock_unlock(&pCtx->lock);
  
  return;
}

/***********************************************************************/
/**
 * @brief  coBlkSdoUlCfmBuild - Build up Block SDO Confirm message
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx        The pointer to the context of a CAN Bus Manager.
 * @param[in,out] pTmRecord   The pointer to the SDO block TM Buffer.
 * @return N/A
 *
 ***********************************************************************/ 
PRIVATE void coBlkSdoUlCfmBuild(CoCtx *pCtx, CoSdoBlkTmRecord *pTmRecord)
{
  CoStatus coSts;
  CoMsg coMsg;
  
  /* BEGIN: protect the modification of Block SDO TC/TM request queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  /* build the message for Start SDO Block Upload */
  coMsg.cobId     = CANOPEN_COB_RSDO(pCtx->blkSdoUlNode);
  coMsg.rtr       = CANOPEN_SDO_RTR;
  coMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
  
  /* fill in the following fields:
    * - ccs = 5
    * - X = 0
    * - cs = 2
    * - reserved = 0
    */
  memset (coMsg.data, 0, CANOPEN_SDO_DATA_LENGTH);
  coMsg.data[CANOPEN_SDO_CCS_OFFSET] = CANOPEN_SDO_CCS_BLK_UL_SEG_END;
  
  /* send back the last block sequence number */
  coMsg.data[CANOPEN_SDO_BLK_UL_RESP_ACKSEQ_OFFSET] = pTmRecord->curBlk;
  
  /* there is no "next" block for the transfer, so not significant */
  coMsg.data[CANOPEN_SDO_BLK_UL_RESP_BLKSZ_OFFSET] = 1;

  /* build the message in the list */
  coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                  coMsg.cobId, coMsg.rtr, coMsg.dataBytes, coMsg.data);
  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
  if (coSts == E_COSTATUS_OK)
  {
    /* one message added in the list */
    pCtx->msgsInCurList++;
    pCtx->sdoMsgsOut++;
  }
  else
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
  }
  /* END: protect the modification of expedited SDO TC/TM request queues * */
  ResourceLock_unlock(&pCtx->lock);
  
  return;
}

/***********************************************************************/
/**
 * @brief  coBlkSdoUlEndBuild - Build up Block SDO End message
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx      The pointer to the context of a CAN Bus Manager.
 * @return N/A
 *
 ***********************************************************************/ 
PRIVATE void coBlkSdoUlEndBuild(CoCtx *pCtx)
{
  CoStatus coSts;
  CoMsg coMsg;
  
  /* BEGIN: protect the modification of Block SDO TC/TM request queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);
  
  /* build the message for Start SDO Block Upload */
  coMsg.cobId     = CANOPEN_COB_RSDO(pCtx->blkSdoUlNode);
  coMsg.rtr       = CANOPEN_SDO_RTR;
  coMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
  
  /* fill in the following fields:
    * - ccs = 5
    * - X = 0
    * - cs = 1
    * - reserved = 0
    */
  memset (coMsg.data, 0, CANOPEN_SDO_DATA_LENGTH);
  coMsg.data[CANOPEN_SDO_CCS_OFFSET] = CANOPEN_SDO_CCS_BLK_UL_END;

  /* build the message in the list */
  coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                  coMsg.cobId, coMsg.rtr, coMsg.dataBytes, coMsg.data);
  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
  if (coSts == E_COSTATUS_OK)
  {
    /* one message added in the list */
    pCtx->msgsInCurList++;
    pCtx->sdoMsgsOut++;
  }
  else
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
  }
  /* END: protect the modification of expedited SDO TC/TM request queues * */
  ResourceLock_unlock(&pCtx->lock);
  
  return;
}


/***********************************************************************/
/**
 * @brief  coBlkSdoUlSegCfmSend - Send SDO Block SegmentConfirm message
 * 
 * @param[in,out] pCtx      The pointer to the context of a CAN Bus Manager.
 * @param[in,out] pTmRecord The pointer to the SDO block TM Buffer.
 * @return N/A
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0370
 * 
 ***********************************************************************/ 
PRIVATE void coBlkSdoUlSegCfmSend(CoCtx *pCtx, CoSdoBlkTmRecord *pTmRecord)
{
  CoStatus coSts;
  Uint timeStart;
  Uint timeEnd;
  Uint accTime;

  /* The End of block is reached, send confirm message */
  coBlkSdoUlCfmBuild(pCtx, pTmRecord);
  
  /* start the sending of the current list */
  /* transmit all messages in the list if not empty */
  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro already called in previous function. */
  
  if (pCtx->msgsInCurList > 0)
  {
    coSts = CanOpenBus_txMsgList(pCtx->busId, pCtx->list, pCtx->msgsInCurList,
                                 pCtx->cycles, pCtx->slotInCycle);
    /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
    if (coSts != E_COSTATUS_OK)
    {
      ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->msgsInCurList);
    }
    pCtx->txMsgs += pCtx->msgsInCurList;

    /* wait until 1.5 ms */
    timeStart = RtcCplr_getCurUs();
    accTime = 0;
  
#ifdef COMGT_UT_SUPPORT
   
  /* in simulation, release CPU so that the simulators could be activated */
    {
      static int ticksPerSecond = 0;
      rtems_status_code rtSts;
      if (ticksPerSecond == 0)
      {
        rtems_clock_get(RTEMS_CLOCK_GET_TICKS_PER_SECOND, (void*)&ticksPerSecond);
      }
      
      /* wait 2 slot duration */
      rtSts = rtems_semaphore_obtain(CoMgt_MstWakeUpSemId[pCtx->busId], RTEMS_WAIT, (2*ticksPerSecond)/CO_FREQUENCY_IN_HZ);
      /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */
      if (rtSts != RTEMS_UNSATISFIED)
      {
        ERROR_REPORT(SW, pCtx->busId, rtSts, CoMgt_MstWakeUpSemId[pCtx->busId]);
      }
    }
#endif  
  
    /* Do a busy wait for the reception of the End Message */
    while (accTime < SDO_UP_BUSY_WAIT) 
    {
      timeEnd = RtcCplr_getCurUs();
      accTime += RtcCplr_deltaUs(timeStart, timeEnd);
      
      timeStart = timeEnd;
    }
  }  
  return;
}

/***********************************************************************/
/**
 * @brief  coBlkSdoDlInitMsgBuild - Build up Block SDO Download Initiate message
 * 
 * Normal progress event EID_BUF_SUP_PDO_TIMEOUT is generated if a Buffer Support
 * Object Timeout is detected.
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return Flag indicating if a message has been built
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0280 [SDO Block Download Sub-index]
 * - SRS.DMS.CAN.FUNC.0340
 * - SRS.DMS.CAN.FUNC.0310 [SDO Block Download notification wait]
 * - SRS.DMS.CAN.FUNC.0320 [SDO Block Download Timeout detection and notification]
 * - SRS.DMS.CAN.FUNC.0950 [Start Download request in right slot]
 * - SRS.DMS.CAN.FUNC.0960 [Discard SDO Block Upload after Download on the same node]
 * - SRS.DMS.CAN.CMD.0200 [Request handling]
 ***********************************************************************/ 
PRIVATE Bool coBlkSdoDlInitMsgBuild(CoCtx *pCtx)
{
  CoStatus coSts;
  CoMsg initMsg;
  Bool msg = FALSE;
  SdoBlkStp step;
  SdoBlkDlReq *pReq;
  U08  nodeId;
  Uint idx;
  U32 nBytes;
  Int remainSlots;
  SdoBlkExec *pExec;

  /* Check if the previous Block Download Buffer support PDO has been received
   * or its timeout detection (hold-on) delay is reached 
   */
  if (pCtx->blkSdoDlLastSlotsCnt != 0)
  {
    remainSlots = (pCtx->blkSdoDlLastSlotsCnt + pCtx->sdoBlkDlPdoTimeout*CO_SLOTS_IN_CYCLE) -
                  (pCtx->cycles*CO_SLOTS_IN_CYCLE + pCtx->slotInCycle);
        
    if (remainSlots < 0 )
    {
      /* Block Download Buffer support PDO timeout detected.
       * Generate event to notify the Timeout
       */
      cdhsEvtReportAutoSev(pCtx->evtPid, EID_BUF_SUP_PDO_TIMEOUT, &pCtx->sdoBlkTimeoutEvt, sizeof(pCtx->sdoBlkTimeoutEvt));
      
      /* Enable the next download transfer */
      pCtx->blkSdoDlLastSlotsCnt = 0;
    }
  }
  /* check if we are in the right slots to start a Block SDO transfer */
  step = coDLSlotToSdoBlkStep(pCtx);
  if (step != E_SDOBLKSTP_INIT1)
  {
    msg = FALSE;
  }
  /* if there is any request in the queue and the last download has been fully ended */
  else if ((pCtx->sdoDlIn > pCtx->sdoDlOut) && 
           (pCtx->blkSdoDlNode == 0) && 
           (pCtx->blkSdoDlLastSlotsCnt == 0))
  {
    /* BEGIN: protect the modification of Block SDO TC/TM request queues */
    ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);

    /* locate and get the current download request: overwritten is not possible */
    idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
    pReq = pCtx->pSdoBlkDlReq + idx;

    /* from the nodeId, and index for Block transfer */
    nodeId = pReq->node;      
    
    /* build the message for Initiate SDO Block download */
    initMsg.cobId     = CANOPEN_COB_RSDO(nodeId);
    initMsg.rtr       = CANOPEN_SDO_RTR;
    initMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
    
    /* fill in the following fields:
      * - ccs/cs/s/cs
      * - index
      * - sub index
      * - size
      */
    memset (initMsg.data, 0, CANOPEN_SDO_DATA_LENGTH);
    initMsg.data[CANOPEN_SDO_CCS_OFFSET] = CANOPEN_SDO_CCS_BLK_DL_SIZE_INIT;
    initMsg.data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET] = (U08) (pReq->objIdx & U08_MAX); 
    initMsg.data[CANOPEN_SDO_CCS_INDEX_MSB_OFFSET] = (U08) ((pReq->objIdx>>SHF_8BIT) & U08_MAX);
    initMsg.data[CANOPEN_SDO_CCS_SUBIDX_OFFSET]    = (U08) (pReq->objSubIdx & U08_MAX);
    
    nBytes = SWAP32(pReq->nBytes);
    memcpy (initMsg.data+CANOPEN_SDO_BLK_DL_REQ_SIZE_OFFSET, &nBytes, sizeof(U32));

    /* store the ongoing SDO exchange context */
    pCtx->blkSdoUlNode = 0;
    pCtx->blkSdoDlNode = nodeId;
    
    /* save the MTX of the SDO transfer */
    memcpy (pCtx->lastSdoMtx, &initMsg.data[CANOPEN_SDO_CCS_INDEX_LSB_OFFSET],
      CANOPEN_SDO_MULTIPLEXOR_SIZE);
     
    /* Store the request part in the execution result */
    pExec = &pCtx->sdoDlExecQueue[pCtx->sdoDlExecIn%CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH];
    
    memset (pExec, 0, sizeof(SdoBlkExec));
    pExec->node   = pReq->node;
    pExec->nBytes = pReq->nBytes;
    pExec->objIdx = pReq->objIdx;
    pExec->reqCnt = pReq->reqCnt;
    
    /* remove any request for SDO Block Upload on the same node */
    coBlkUlReqQueueNodeRemove(pCtx, nodeId) ;
    
    /* build the message in the list */
    coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                    initMsg.cobId, initMsg.rtr, initMsg.dataBytes, initMsg.data);
    /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
    if (coSts == E_COSTATUS_OK)
    {
      /* one message added in the list */
      pCtx->msgsInCurList++;
      pCtx->sdoMsgsOut++;
      msg = TRUE;
    }
    else
    {
      ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
      msg = FALSE;
    }

    /* initialise flag */
    pCtx->sdoDlBendTimeout = FALSE;

    /* END: protect the modification of expedited SDO TC/TM request queues * */
    ResourceLock_unlock(&pCtx->lock);
  }
  return msg;
}

/***********************************************************************/
/**
 * @brief  coBlkSdoDlEndMsgBuild - Build up End SDO Block Download message
 * 
 * @reentrant The variable @ref CoMgr_ctx is protected for exclusive
 * read/write access by a mutex @ref CoCtx.lock.
 *
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @return Flag indicating if a message has been built
 *
 ***********************************************************************/ 
PRIVATE void coBlkSdoDlEndMsgBuild(CoCtx *pCtx)
{
  CoStatus coSts;
  CoMsg coMsg;
  SdoBlkDlReq *pDlReq;
  U08  unUsedBytes;
  Uint idx;

  /* BEGIN: protect the modification of Block SDO TC/TM request queues */
  ResourceLock_lock(&pCtx->lock, RESOURCELOCK_NO_TIMEOUT);

  /* locate and get the current download request */
  idx = pCtx->sdoDlOut%pCtx->sdoDlQLength;
  pDlReq = pCtx->pSdoBlkDlReq + idx;
  
  /* build the message for Initiate SDO Block download */
  coMsg.cobId     = CANOPEN_COB_RSDO(pCtx->blkSdoDlNode);
  coMsg.rtr       = CANOPEN_SDO_RTR;
  coMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
  
  /* fill in the following fields:
   * - ccs/n/cs
   * - crc=0
   * ref to CANopen protocol definition for detail
   */
  unUsedBytes = pDlReq->blks * CANOPEN_SDO_BLK_NBYTE_PER_SEG - pDlReq->nBytes;
  
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */  
  if (unUsedBytes >= CANOPEN_SDO_BLK_NBYTE_PER_SEG)
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, pDlReq->blks, pDlReq->nBytes);
  }
 
  memset (coMsg.data, 0, CANOPEN_SDO_DATA_LENGTH);
  coMsg.data[CANOPEN_SDO_CCS_OFFSET] = CANOPEN_SDO_CCS_BLK_DL_END |
      ((unUsedBytes << CANOPEN_SDO_CCS_BLK_DL_END_NBYTE_LSB) & CANOPEN_SDO_CCS_BLK_DL_END_NBYTE_MSK);

  /* build the message in the list */
  coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                  coMsg.cobId, coMsg.rtr, coMsg.dataBytes, coMsg.data);
  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */  
  if (coSts == E_COSTATUS_OK)
  {
    /* one message added in the list */
    pCtx->msgsInCurList++;
    pCtx->sdoMsgsOut++;
  }
  else
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
  }
  /* END: protect the modification of expedited SDO TC/TM request queues * */
  ResourceLock_unlock(&pCtx->lock);
}

/***********************************************************************/
/**
 * @brief  coBlkUlDataMsgRecord - Check and record SDO data message
 * 
 * @param[in,out] pCtx      The pointer to the context of a CAN Bus Manager.
 * @param[in] pMsg          The pointer to the incoming SDO data message.
 * @param[in,out] pTmRecord The pointer to the SDO block TM Buffer.
 * @return Code indicating if a message has been built
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0070 [Message with ARRAY (in)]
 * - SRS.DMS.CAN.FUNC.0330
 * 
 ***********************************************************************/ 
PRIVATE U32 coBlkUlDataMsgRecord(CoCtx *pCtx, CoMsg *pMsg, CoSdoBlkTmRecord *pTmRecord) 
{
  U08 cFlag;
  U08 seqNo;
  U32 abortCode;
  
  PARAM_NOT_USED(pCtx);
  /* retrieve header info */
  cFlag = pMsg->data[CANOPEN_SDO_BLK_DATA_HEAD_OFFSET] & CANOPEN_SDO_BLK_DATA_HEAD_SEQ_END; 
  seqNo = pMsg->data[CANOPEN_SDO_BLK_DATA_HEAD_OFFSET] & CANOPEN_SDO_BLK_DATA_HEAD_SEQNO_MSK;
  
  /* check C flag and seqNo, if error, send ABORT message */
  /* sequence number not consecutive */
  if (pTmRecord->curBlk != (seqNo-1))
  {
    abortCode = CANOPEN_SDO_ABORT_SEQ_NUM_ERR;
  }
  /* at the expected end, there is still messages */
  else if ((seqNo == pTmRecord->blks) && (cFlag == 0))
  {
    abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
  }
  else if (((seqNo < pTmRecord->blks) && (cFlag != 0)))
  {
    abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
  }
  else if (seqNo > pTmRecord->blks)
  {
    abortCode = CANOPEN_SDO_ABORT_BLK_SIZE_ERR;
  }
  /* if all right, extract the data byte and store it in reserved TM buffer: FUNC.330 */ 
  else
  {    
    memcpy (&pTmRecord->data[pTmRecord->curBlk*CANOPEN_SDO_BLK_NBYTE_PER_SEG],
            &pMsg->data[CANOPEN_SDO_BLK_DATA_SEG_OFFSET], CANOPEN_SDO_BLK_NBYTE_PER_SEG);
    pTmRecord->curBlk++;
    abortCode = OK; /* not significant */
  }
  return abortCode;
}

/***********************************************************************/
/**
 * @brief  coBlkUlReqQueueNodeRemove - remove the Upload request for a node
 * 
 * @param[in,out] pCtx  The pointer to the context of a CAN Bus Manager.
 * @param[in] node      The node searched 
 * @return N/A
 *
 ***********************************************************************/ 
PRIVATE void coBlkUlReqQueueNodeRemove(CoCtx *pCtx, U08 node) 
{
  SdoBlkUlReq *pCurReq;
  SdoBlkUlReq *pSrcReq;
  Uint reqIdx;
  Uint i;
  Uint searched;
  Uint toBeSearched;

  if (pCtx->sdoUlIn > pCtx->sdoUlOut)
  {
    /* check request overwritten */
    /* %COVER%TRUE% Defensive programming - Queue for upload requests full. */
    if ((pCtx->sdoUlIn - pCtx->sdoUlOut) > CO_EXPDT_SDO_UL_QUEUE_LENGTH)
    {
      /* if request queue overwritten */
      pCtx->sdoUlOut = pCtx->sdoUlIn - CO_EXPDT_SDO_UL_QUEUE_LENGTH;
    }
    
    toBeSearched = pCtx->sdoUlIn - pCtx->sdoUlOut;
    searched = 0;
    while (searched < toBeSearched)
    {
      /* get the queued Upload request */
      reqIdx = (pCtx->sdoUlOut+searched)%CO_EXPDT_SDO_UL_QUEUE_LENGTH;
      pCurReq = &pCtx->sdoBlkUlReq[reqIdx%CO_BLK_SDO_UL_QUEUE_LENGTH];
      
      /* check its nodeId */ 
      if (node == pCurReq->node)
      {
        /* move the following requests to the current position => the current one overwritten  */
        for (i = searched; i < toBeSearched-1; i++)
        {
          reqIdx = (pCtx->sdoUlOut+i)%CO_EXPDT_SDO_UL_QUEUE_LENGTH;
          pCurReq = &pCtx->sdoBlkUlReq[reqIdx%CO_BLK_SDO_UL_QUEUE_LENGTH];
          
          reqIdx = (pCtx->sdoUlOut+i+1)%CO_EXPDT_SDO_UL_QUEUE_LENGTH;
          pSrcReq = &pCtx->sdoBlkUlReq[reqIdx%CO_BLK_SDO_UL_QUEUE_LENGTH];
          memcpy (pCurReq, pSrcReq, sizeof(SdoBlkUlReq)); 
        }
        
        /* one less request in the queue and to be checked */
        pCtx->sdoUlIn--;
        toBeSearched--;
      }
      else
      {
        /* one more node checked */
        searched++;
      }
    } /* while */
  } /* if */
}
/***********************************************************************/
/**
 * @brief  coBlkSdoDlDataMsgsSend - Build up Block SDO Download data messages
 * 
 * @param[in,out] pCtx    The pointer to the context of a CAN Bus Manager.
 * @param[in] nBlk        The number of the data messages to send.
 * @param[in,out] pDlReq  The pointer to the SDO block Download Request Buffer.
 * @return N/A
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0070 [Message with ARRAY (out)]
 * - SRS.DMS.CAN.FUNC.0270 [SDO Block Download data size sent]
 * - SRS.DMS.CAN.FUNC.0290
 ***********************************************************************/ 
PRIVATE void coBlkSdoDlDataMsgSend(CoCtx *pCtx, Uint nBlk, SdoBlkDlReq *pDlReq)
{
  CoStatus coSts;
  CoMsg coMsg;
  Int offset;
  U08 remainBytes;
  Uint i;

  /* build the message for Start SDO Block download */
  coMsg.cobId     = CANOPEN_COB_RSDO(pCtx->blkSdoDlNode);
  coMsg.rtr       = CANOPEN_SDO_RTR;
  coMsg.dataBytes = CANOPEN_SDO_DATA_LENGTH;
  
  /* value range check */
  /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */  
  if (pDlReq->blks < (pDlReq->curBlk + nBlk))
  {
    ERROR_REPORT(SW_ERROR, pCtx->busId, nBlk, pDlReq->blks);
  }
  else
  {
    /* now, build the messages */
    for (i = 0; i < nBlk; i++)
    {
      /* for the last one */
      if ((pDlReq->curBlk+1) == pDlReq->blks)
      {
        /* clear buffer */
        memset (&coMsg.data[CANOPEN_SDO_BLK_DATA_SEG_OFFSET], 
                    0, CANOPEN_SDO_BLK_NBYTE_PER_SEG);

        /* copy only remaining bytes */
        remainBytes = pDlReq->nBytes - (CANOPEN_SDO_BLK_NBYTE_PER_SEG *pDlReq->curBlk);
        offset = pDlReq->curBlk * CANOPEN_SDO_BLK_NBYTE_PER_SEG;
        memcpy (coMsg.data+CANOPEN_SDO_BLK_DATA_SEG_OFFSET, 
                pDlReq->data+offset, remainBytes);
        
        /* add segment end flag with seqno */
        pDlReq->curBlk++;
        coMsg.data[CANOPEN_SDO_BLK_DATA_HEAD_OFFSET] = pDlReq->curBlk | CANOPEN_SDO_BLK_DATA_HEAD_SEQ_END;
      }
      else
      {
        /* copy data from Download data buffer into message */
        offset = pDlReq->curBlk * CANOPEN_SDO_BLK_NBYTE_PER_SEG;
        memcpy (coMsg.data+CANOPEN_SDO_BLK_DATA_SEG_OFFSET, 
                pDlReq->data+offset, CANOPEN_SDO_BLK_NBYTE_PER_SEG);
        
        /* seqno */
        pDlReq->curBlk++;
        coMsg.data[CANOPEN_SDO_BLK_DATA_HEAD_OFFSET] = pDlReq->curBlk;
      }
      
      /* build the message in the list */
      coSts = CanOpenBus_putMsgInList(pCtx->busId, pCtx->list,
                                      coMsg.cobId, coMsg.rtr, coMsg.dataBytes, coMsg.data);
      /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */      
      if (coSts == E_COSTATUS_OK)
      {
        /* one message added in the list */
        pCtx->msgsInCurList++;
        pCtx->sdoMsgsOut++;
      }
      else
      {
        ERROR_REPORT(SW_ERROR, pCtx->busId, coSts, pCtx->chanId);
      } 
    }
  }
  return;
}

/***********************************************************************/
/**
 * @brief  coBlkSdoDlEnd - Finish the Block SDO Download transfer
 * 
 * @param[in,out] pCtx      The pointer to the context of a CAN Bus Manager.
 * @param[in] cliAbortCode  The client's reason for the abort.
 * @param[in] serAbortCode  The server's reason for the abort.
 * @return N/A
 
 ***********************************************************************/ 
PRIVATE void coBlkSdoDlEnd(CoCtx *pCtx, U32 cliAbortCode, U32 serAbortCode)
{
  SdoBlkExec *pExec;
  NodeStat *pNode;
  Uint nodeIdx;

  /* get its index in the node list and update its state */
  nodeIdx = pCtx->nodeToBusNodeIdx[pCtx->blkSdoDlNode];
  pNode = &pCtx->pNodeStat[nodeIdx];
 
  pNode->sdoBlkAbtCliCode = OK;
  pNode->sdoBlkAbtSerCode = OK;
 
  if (cliAbortCode != OK)
  {
    coAbortSdoMsgBuild(pCtx, pCtx->blkSdoDlNode, pCtx->lastSdoMtx, cliAbortCode);
    pNode->sdoBlkAbtCliCnt++;
    pNode->sdoBlkAbtCliCode = cliAbortCode;
    pNode->sdoBlkStatus = cliAbortCode;
    pCtx->blkSdoAbt++;
  }
  else if (serAbortCode != OK)
  {
    pNode->sdoBlkAbtSerCnt++;
    pNode->sdoBlkAbtSerCode = serAbortCode;
    pNode->sdoBlkStatus = serAbortCode;
    pCtx->blkSdoAbt++;
  }
  else
  {
    pNode->sdoBlkStatus = OK;
  }

  /* consider it is finished, then go to the next TC request */
  pCtx->sdoDlOut++;
  pCtx->blkSdoDlNode = 0;
  memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);

  /* complete execution result */
  pExec = &pCtx->sdoDlExecQueue[pCtx->sdoDlExecIn%CO_BLK_SDO_DL_EXEC_QUEUE_LENGTH];
  pExec->cycle  = pCtx->cycles;
  pExec->result = pNode->sdoBlkStatus;
  
  /* Buffer Support Object Timeout Event Data */
  pCtx->sdoBlkTimeoutEvt.busId = (U08)pCtx->busId; //Cast is safe as range of busId is [0;1]
  pCtx->sdoBlkTimeoutEvt.nodeId = pExec->node;
  pCtx->sdoBlkTimeoutEvt.nodeIdx = pExec->objIdx;
  pCtx->sdoBlkTimeoutEvt.sdoBlkSize = pExec->nBytes;
  
  /* Go to next SDO Dl request in the queue */
  pCtx->sdoDlExecIn++;

  pNode->sdoBlkDlTotal++;
  
  /* store the last handled request number */
  pCtx->sdoDlReqLast = pExec->reqCnt;
}
/***********************************************************************/
/**
 * @brief  coBlkSdoUlEnd - Finish the Block SDO Upload transfer
 * 
 * @param[in,out] pCtx      The pointer to the context of a CAN Bus Manager.
 * @param[in] cliAbortCode  The client's reason for the abort.
 * @param[in] serAbortCode  The server's reason for the abort.
 * @return N/A
 ***********************************************************************/ 
PRIVATE void coBlkSdoUlEnd(CoCtx *pCtx, U32 cliAbortCode, U32 serAbortCode)
{
  SdoBlkExec *pExec;
  NodeStat *pNode;
  Uint nodeIdx;

  /* get its index in the node list and update its state */
  nodeIdx = pCtx->nodeToBusNodeIdx[pCtx->blkSdoUlNode];
  pNode = &pCtx->pNodeStat[nodeIdx];
 
  pNode->sdoBlkAbtCliCode = OK;
  pNode->sdoBlkAbtSerCode = OK;
  
  if (cliAbortCode != OK)
  {
    coAbortSdoMsgBuild(pCtx, pCtx->blkSdoUlNode, pCtx->lastSdoMtx, cliAbortCode);
    pNode->sdoBlkAbtCliCnt++;
    pNode->sdoBlkAbtCliCode = cliAbortCode;
    pNode->sdoBlkStatus = cliAbortCode;
    pCtx->blkSdoAbt++;
  }
  else if (serAbortCode != OK)
  {
    pNode->sdoBlkAbtSerCnt++;
    pNode->sdoBlkAbtSerCode = serAbortCode;
    pNode->sdoBlkStatus = serAbortCode;
    pCtx->blkSdoAbt++;
 }
  else
  {
    pNode->sdoBlkStatus = OK;
  }

  /* consider it is finished, then go to the next TC request */
  pCtx->blkSdoUlNode = 0;
  memset (pCtx->lastSdoMtx, 0, CANOPEN_SDO_MULTIPLEXOR_SIZE);

  /* complete execution result */
  pExec = &pCtx->sdoUlExecQueue[pCtx->sdoUlExecIn%CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH];

  pExec->cycle  = pCtx->cycles;
  pExec->result = pNode->sdoBlkStatus;
  pExec->sdoUpRecNum = pCtx->pSdoBlkTmArea->written;
  pCtx->sdoUlExecIn++;
  
  pNode->sdoBlkUlTotal++;
   
  /* store the last handled request number */
  pCtx->sdoUlReqLast = pExec->reqCnt;
  
  /* consider it is finished, then go to the next TM buffer */
  pCtx->pSdoBlkTmArea->written++;
 
}
/*------------------ ooOoo End of file ooOoo --------------------------*/
