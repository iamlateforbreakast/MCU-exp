/* CanOpenMgt.h - header file for CanOpenMgt.c */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenMgt_
#define _CanOpenMgt_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenMgt.h - header file for CanOpenMgt module.
 *
 * The file provides the declaration of public services of CanOpenMgt module 
 */

/*---------- Standard libraries includes ------------------------------*/
#if PORT
#include <rtems.h> /* %RELAX<FIL-120-PLE> Include used */
#endif
/*---------- FSW includes ---------------------------------------------*/
#include "util/basicTypes.h"

/*---------- Component includes ---------------------------------------*/

/*---------- Defines & macro ------------------------------------------*/

/*---------- Types definitions ----------------------------------------*/

/*---------- Variables exported by the module -------------------------*/

#ifdef COMGT_UT_SUPPORT
#include "coMgt/CanOpenCommon.h"
PUBLIC rtems_id    CoMgt_SlotSyncSemId[ROV_CANBUS_NUM];;
PUBLIC Uint        CoMgt_itSlotInCycle;
PUBLIC Uint        CoMgt_SlotInCycle;
PUBLIC Uint        CoMgt_Cycles;
PUBLIC Uint        CoMgt_MstState[ROV_CANBUS_NUM];
#endif

/*
 * CoMgr_ticksPerSecond is the current setting of ticks in a second.
 */
PUBLIC U32 CoMgr_ticksPerSecond;


/*---------- Functions exported by the module -------------------------*/
#ifdef COMGT_UT_SUPPORT
PUBLIC U32 CanOpenMgt_getRtRelax(void);
#endif

/*
 * CanOpenMgr_Init - Initialisation of the CANopen management service
 */
PUBLIC void CanOpenMgt_init(U16 evtPid);

/*
 * CanOpenMgt_modifyDefaultChannel - modify the default initial channel 
 */
PUBLIC U32 CanOpenMgt_modifyDefaultChannel(U32 busId, U32 chanId);

/*
 * CanOpenMgt_getCurrentChannel - return the current channel for the bus 
 */
PUBLIC Bool CanOpenMgt_getCurrentChannel(U32 busId, U32* pChanId);

PUBLIC void CanOpenMgt_setCanBusInitialised(void);

/*
 * CanOpenMgt_SyncTaskBody - Synchronisation handler task
 * of the CANopen management service
 */
PUBLIC void CanOpenMgt_syncTaskBody(rtems_task_argument unused);

/*
 * CanOpenMgt_BusMgr - Bus Manager task of a CAN Bus
 */
PUBLIC void CanOpenMgt_busMgr(rtems_task_argument busId);


#endif /* _CanOpenMgt_ */
