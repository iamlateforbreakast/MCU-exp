/* CanOpenConfigTest.h - CANopen configuration file for unit tests */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenConfigTest_
#define _CanOpenConfigTest_

/***********************************************************************/
/**
 * 
 * CanOpenConfigTest.h - CANopen configuration file for unit tests.
 *
 * This file includes a set of ROVER-specific definitions as well as
 * configuration parameters for Platform & Payload Buses. 
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------------*/

/*---------- Defines & macro ------------------------------------------*/

/* CAN BUS Configuration parameters for unit tests (covers/qualifies all cases) */

/* In instrumented version, real time shall be 21 times slower */
#ifdef NO_REALTIME
#define RT_RELAX (21)
#else
#define RT_RELAX (1)
#endif

/*
 * Node ID and number on Platform Bus
 * Ref: Platform CANBus IRD 
 */
#define CO_PF_NODE_NUM (10) /* for slave */

#define CO_PF_SPARE1_NAME ("SPARE1")
#define CO_PF_SPARE1_NID  (8)
#define CO_PF_SPARE1_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_SPARE1_NID)

#define CO_PF_SPARE2_NAME ("SPARE2")
#define CO_PF_SPARE2_NID (16)
#define CO_PF_SPARE2_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_SPARE2_NID)

#define CO_PF_PCDE_NAME ("PCDE")
#define CO_PF_PCDE_NID (24)
#define CO_PF_PCDE_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_PCDE_NID)

#define CO_PF_SPARE3_NAME ("SPARE3")
#define CO_PF_SPARE3_NID (32)
#define CO_PF_SPARE3_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_SPARE3_NID)

#define CO_PF_UHFA_NAME ("UHFA")
#define CO_PF_UHFA_NID (48)
#define CO_PF_UHFA_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_UHFA_NID)

#define CO_PF_UHFB_NAME ("UHFB")
#define CO_PF_UHFB_NID (56)
#define CO_PF_UHFB_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_UHFB_NID)

#define CO_PF_ADE_L_NOM_NAME ("ADE_L_N")
#define CO_PF_ADE_L_NOM_NID (72)
#define CO_PF_ADE_L_NOM_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_L_NOM_NID)

#define CO_PF_ADE_R_NOM_NAME ("ADE_R_N")
#define CO_PF_ADE_R_NOM_NID (88)
#define CO_PF_ADE_R_NOM_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_R_NOM_NID)

#define CO_PF_ADE_L_RED_NAME ("ADE_L_R")
#define CO_PF_ADE_L_RED_NID (112)
#define CO_PF_ADE_L_RED_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_L_RED_NID)

#define CO_PF_ADE_R_RED_NAME ("ADE_R_R")
#define CO_PF_ADE_R_RED_NID (120)
#define CO_PF_ADE_R_RED_COBID_RET (CANOPEN_COB_RPDO1_BASE+CO_PF_ADE_R_RED_NID)

/*
 * Node ID and number on Payload Bus
 * all of them shall be updated according to last IRD
 */
#define CO_PL_NODE_NUM (6) /* for slave */

#define CO_PL_CTPUA_NAME ("CTPU_A")
#define CO_PL_CTPUA_NID  (2) 
#define CO_PL_CTPUA_NMSK CO_PL_OBC_NMSK

#define CO_PL_CTPUB_NAME ("CTPU_B")
#define CO_PL_CTPUB_NID (3)   
#define CO_PL_CTPUB_NMSK CO_PL_OBC_NMSK

#define CO_PL_WISDOM_NAME ("WISDOM")
#define CO_PL_WISDOM_NID (4)
#define CO_PL_WISDOM_NMSK CO_NMSK_NID_1
#define CO_PL_WISDOM_COBID_RET (CANOPEN_COB_RPDO4_BASE+CO_PL_WISDOM_NID)

#define CO_PL_RAMAN_NAME ("RAMAN")
#define CO_PL_RAMAN_NID (6)
#define CO_PL_RAMAN_NMSK CO_NMSK_NID_2
#define CO_PL_RAMAN_COBID_RET (CANOPEN_COB_RPDO4_BASE+CO_PL_RAMAN_NID)

#define CO_PL_MOMA_NAME ("MOMA")
#define CO_PL_MOMA_NID (16)
#define CO_PL_MOMA_NMSK CO_NMSK_NID_16
#define CO_PL_MOMA_COBID_RET (CANOPEN_COB_RPDO4_BASE+CO_PL_MOMA_NID)


#define CO_PL_DSEU_NAME ("DSEU")
#define CO_PL_DSEU_NID (64)
#define CO_PL_DSEU_NMSK CO_NMSK_NID_32
#define CO_PL_DSEU_COBID_RET (CANOPEN_COB_RPDO4_BASE+CO_PL_DSEU_NID)

#define CO_PL_XRD_NAME ("XRD")
#define CO_PL_XRD_NID (100)
#define CO_PL_XRD_NMSK CO_NMSK_NID_4
#define CO_PL_XRD_COBID_RET (CANOPEN_COB_RPDO4_BASE+CO_PL_XRD_NID)

#define CO_PL_RTB_NAME ("RTB")
#define CO_PL_RTB_NID (112)
#define CO_PL_RTB_NMSK CO_NMSK_NID_8
#define CO_PL_RTB_COBID_RET (CANOPEN_COB_RPDO4_BASE+CO_PL_RTB_NID)


/***********************************************************/
/*
 * Node descriptor list on:
 * - Platform Bus
 * - Payload bus 
 */
#define PF_NODE01_DESC {.devName=CO_PF_SPARE1_NAME, .baseNid=CO_PF_SPARE1_NID,\
                       .nodeMsk=CO_PF_SLAVE_NMSK, \
                       .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_SPARE1_COBID_RET},
#define PF_NODE02_DESC {.devName=CO_PF_SPARE2_NAME, .baseNid=CO_PF_SPARE2_NID,\
                       .nodeMsk=CO_PF_SLAVE_NMSK,\
                       .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_SPARE2_COBID_RET},
#define PF_NODE03_DESC {.devName=CO_PF_PCDE_NAME,  .baseNid=CO_PF_PCDE_NID,\
                       .nodeMsk=CO_PF_SLAVE_NMSK,\
                       .needDummyPdo=1, .isUhf=0, .cobIdRet=CO_PF_PCDE_COBID_RET},
#define PF_NODE04_DESC {.devName=CO_PF_SPARE3_NAME, .baseNid=CO_PF_SPARE3_NID,\
                       .nodeMsk=CO_PF_SLAVE_NMSK,\
                       .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_SPARE3_COBID_RET},
#define PF_NODE05_DESC {.devName=CO_PF_UHFA_NAME, .baseNid=CO_PF_UHFA_NID,\
                       .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=1, .cobIdRet=CO_PF_UHFA_COBID_RET},
#define PF_NODE06_DESC {.devName=CO_PF_UHFB_NAME,   .baseNid=CO_PF_UHFB_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=1, .cobIdRet=CO_PF_UHFB_COBID_RET},
#define PF_NODE07_DESC {.devName=CO_PF_ADE_L_NOM_NAME, .baseNid=CO_PF_ADE_L_NOM_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_L_NOM_COBID_RET},
#define PF_NODE08_DESC {.devName=CO_PF_ADE_R_NOM_NAME,\
                        .baseNid=CO_PF_ADE_R_NOM_NID, .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_R_NOM_COBID_RET},
#define PF_NODE09_DESC {.devName=CO_PF_ADE_L_RED_NAME, .baseNid=CO_PF_ADE_L_RED_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_L_RED_COBID_RET},
#define PF_NODE10_DESC {.devName=CO_PF_ADE_R_RED_NAME, .baseNid=CO_PF_ADE_R_RED_NID,\
                        .nodeMsk=CO_PF_SLAVE_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PF_ADE_R_RED_COBID_RET}  /* last one, without comma , */

#define PL_NODE01_DESC {.devName=CO_PL_WISDOM_NAME, .baseNid=CO_PL_WISDOM_NID,\
                        .nodeMsk=CO_PL_WISDOM_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_WISDOM_COBID_RET},
#define PL_NODE02_DESC {.devName=CO_PL_RAMAN_NAME, .baseNid=CO_PL_RAMAN_NID,\
                        .nodeMsk=CO_PL_RAMAN_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_RAMAN_COBID_RET},
#define PL_NODE03_DESC {.devName=CO_PL_MOMA_NAME, .baseNid=CO_PL_MOMA_NID,\
                        .nodeMsk=CO_PL_MOMA_NMSK,\
                         .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_MOMA_COBID_RET},
#define PL_NODE04_DESC {.devName=CO_PL_DSEU_NAME,   .baseNid=CO_PL_DSEU_NID,\
                        .nodeMsk=CO_PL_DSEU_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_DSEU_COBID_RET},
#define PL_NODE05_DESC {.devName=CO_PL_XRD_NAME, .baseNid=CO_PL_XRD_NID,\
                        .nodeMsk=CO_PL_XRD_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_XRD_COBID_RET},
#define PL_NODE06_DESC {.devName=CO_PL_RTB_NAME, .baseNid=CO_PL_RTB_NID,\
                        .nodeMsk=CO_PL_RTB_NMSK,\
                        .needDummyPdo=0, .isUhf=0, .cobIdRet=CO_PL_RTB_COBID_RET}  /* last one, without comma , */


/* maximum number of pending NMT commands for master (buffer length): design feature, >= 8 for test */
#define CO_MST_CMD_QUEUE_LENGTH (8)

/*
 * maximum number of expedited SDO message stored per node: size hard-coded in test
 */
#define CO_SDO_MSG_PER_NODE (20)

/* Block SDO Upload request queue length: hard-coded in the test */
#define CO_BLK_SDO_UL_QUEUE_LENGTH (16)

/* Length of execution result queue for Block SDO upload request */
#define CO_BLK_SDO_UL_EXEC_QUEUE_LENGTH (CO_BLK_SDO_UL_QUEUE_LENGTH)

/**
 * Timeout period to receive Buffer Support PDO message after
 * End of SDO Block Download
 *
 ***********************************************************************/ 
/** Platform bus: Timeout period in cycle to receive Buffer Support PDO */
#define CO_PF_BLK_SDO_DL_PDO_TIMEOUT (1)

/** Payload bus: Timeout period in cycle to receive Buffer Support PDO */
#define CO_PL_BLK_SDO_DL_PDO_TIMEOUT  (2)


/*
 * maximum number of block SDO TM stored on platform bus: 
 * design feature, storage capacity > 1 second
 */
#define CO_PF_SDO_BLK_TM_QUEUE_LENGTH ((CO_CYCLE_IN_1SEC+1) * CO_PF_SDO_BLK_MAX_IN_CYCLE)
#define CO_PL_SDO_BLK_TM_QUEUE_LENGTH ((CO_CYCLE_IN_1SEC+1) * CO_PL_SDO_BLK_MAX_IN_CYCLE)


/* SDO block download (TC) request */

/**
 * Communication Cycle Period (multiple of 100 ms)
 *
 ***********************************************************************/ 
/* platform: 1 cycle => 100 ms */
#define CO_PF_COMM_CYCLE_PERIOD (1)

/* payload: 3 cycles => 300 ms */
#define CO_PL_COMM_CYCLE_PERIOD (3)

/*
 * Platform master Producer Heart beat Time 
 * in unit of 100 ms: e.g: 9 cycles=900 ms
 */
#define CO_PF_MST_PRD_HBT (9)

/*
 * Payload master Producer Heart beat Time 
 * in unit of 100 ms:  e.g: 7 cycles=700 ms
 */
#define CO_PL_MST_PRD_HBT (7)

/** 
 * Master Toggle time
 * in multiple Heart beat producer time
 */
/** Platform master: e.g: 4 timeout=4*900 ms */
#define CO_PF_TOGGLE_CYC (4)

/** Payload master: e.g: 3 timeout=3*700 ms */
#define CO_PL_TOGGLE_CYC (3)

    
/*---------- Types definitions ----------------------------------------*/

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

#endif /* _CanOpenConfigTest_ */
