/* CanOpenMgt.c - CanOpenMgt body */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */


/***********************************************************************/
/**
 * @file
 *  @brief CanOpenMgt.c - implementation of CanOpenMgt module.
 *
 * This module implements the CANopen manager for the Platform and
 * Payload buses and synchronisation task to supports the bus managers. 
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0500 
 * 
 ***********************************************************************/

/**
 * @addtogroup coMgr
 * @{
 * 
 * @par CANOpen management overview
 * 
 * CanOpenMgt module implements CANopen managers for platform & payload
 * CAN Buses. A CANopen manager works as an automaton based on the standard
 * CANopen state machine and trigger, as illustrated  in the following figure :
 *
 * @image html "coMgr_CANOpenStateMachine.png" "Figure 1: CANOpen State Machine"
 * @image rtf "coMgr_CANOpenStateMachine.png" "Figure 1: CANOpen State Machine"
 * @image latex "coMgr_CANOpenStateMachine.png" "Figure1: CANOpen State Machine"
 * 
 * This ROVER's CANopen Manager realises such automaton, with some Rover-specific
 * tailoring, as showed in bty the next figure:
 * 
 * @image html "coMgr_RoverCANOpenStateMachine.png" "Figure 2: Rover's CANOpen State Machine/trigger"
 * @image rtf "coMgr_RoverCANOpenStateMachine.png" "Figure 2: Rover's CANOpen State Machine/trigger"
 * @image latex "coMgr_RoverCANOpenStateMachine.png" "Figure2: Rover's CANOpen State Machine/trigger"
 * 
 * @par CANOpen management architecture
 * 
 * There are 3 tasks for the CANopen managers itself.
 * - CANopen synchronisation task, implemented by CanOpenMgt_SyncTaskBody()
 * - CANopen manager for platform bus, implemented by CanOpenMgt_BusMgr()
 * - CANopen manager for payload bus, implemented also by CanOpenMgt_BusMgr()
 * 
 * The synchronisation task cyclically takes timing event from OBT (100 ms cycle).
 * It then receives subsequent 200Hz activations from the RtcCplr, up to the end 
 * of the 100ms cycle. These events are re-distributed to the 2 bus managers. 
 * 
 * The two bus managers share the same codes, but they work with different
 * configuration parameters and contexts. The CANopen state machine & trigger (event)
 * is implemented by the transition tables defined following the standard
 * CANopen and Rover's tailoring.
 * 
 * The transition table for the bus manager is defined the CanOpenMgt module. All
 * specified actions are provided by the CanOpenAction module. The management of
 * different CANOpen protocols are ensured by the adequate actions associated to
 * the corresponding state.  
 * 
 * CanOpenMgt module defines the transition table for the bus managers, it
 * includes also a function dedicated to set up the specific configuration and
 * working context for the 2 buses (CanOpenMgt_Init()).
 * 
 * The bus manager is scheduled by timing event (10Hz and 200 Hz), when activated,
 * a bus manager takes any incoming application's NMT command and performs adequate
 * actions according to the pre-defined transition table.
 * 
 * The next schema depicts the such implementation:
 * 
 * @image html "coMgr_CANopenMgtArchi.png" "Figure 3: CANopen management diagram"
 * @image rtf "coMgr_CANopenMgtArchi.png" "Figure 3: CANopen management diagram"
 * @image latex "coMgr_CANopenMgtArchi.png" "Figure 3: CANopen management diagram"
 * 
 * The CanOpen managers provide 2 kinds of external interface for its usage by applications:
 * - a set of API available for any on-board applications, implemented by CanApis module,
 * - a set of ROVER's CAN specific TM/TC, as part of PUS service #2, implemented by
 *   CanOenTc module.
 * - in addition, a set of HouseKeeping parameters are created and maintained.    
 * 
 * At another hand, all access to the CANBus controller for any message exchanges
 * with external CAN Bus are ensured by CanOpenBus module, based on the ROVER OBC's
 * HDSW layer. 
 * 
 * @note The creation of the necessary tasks of CANopen managers shall be
 * performed at ASW level:
 * - synchronisation task as cyclic task
 * - two bus manager tasks as asynchronous tasks
 *
 * CanOpenMgt_Init() shall be invoked once and only once before the creation
 * of the these tasks.
 * 
 * @par FDIR
 *
 * On each CAN Bus, the FDIR handling is base on the monitoring of a couple of
 * HK TM parameters: CANBUS_ACTPM_HEALTH and CANBUS_EXT_HEALTH. The handling is
 * as follows:
 * 
 * - once any of CANBUS_ACTPM_HEALTH and CANBUS_EXT_HEALTH of a bus becomes FAILED,
 *   no Bus Manager's actions will be invoked anymore,
 *   
 * - as the couple of HK parameters are only updated by Bus Manager's actions, no action
 *   means no parameters updating, leading the corresponding Bus Manager
 *   to non-functional state, 
 * 
 * Note: in the current design, this couple of HK parameters will stay in FALSE state
 * until next OBC reboot.
 *
 * The CANBUS_ACTPM_HEALTH and CANBUS_EXT_HEALTH HK parameters on each CAN bus are
 * updated at 200 Hz, based on the checking of controller's statuses on each bus performed
 * by actions for cycle & slot events. The controller's statuses are handled as follows:
 * 
 *   - check the status of the message transmitted in the previous period,
 *     -- if an error FCG_ACTPM is detected, HKTM CANBUS_ACTPM_HEALTH flag 
 *        is set to FALSE;
 *     -- if an error FCG_EXTCAN/FCG_BUSY is detected, HKTM CANBUS_EXT_HEALTH
 *        flag is set to FALSE.
 *     -- if transmission state is FCG_BUSY, two cases applies:
 *         --- no messages received => master is alone on bus, no slave acknowledge the messages, 
 *             This is normal case, where we want no error raised until first slave is active, 
 *             therefore HB monitor has to be disabled to prevent false triggering, but the master needs not to start new transfer on the bus 
 *         --- some messages are received, meaning that they have higher than master messages that cannot be sent 
 *         (typically the master HB has less priority than a SDO slave).
 *             This is typical to a babbling idiot slave case, therefore  HKTM CANBUS_EXT_HEALTH is set to false without relying on HB triggering.
 *     
 *     Note that reception state is always busy as we program and endless reception on a circular buffer.
 *     
 *   - check the status of the message received in the previous period,
 *     -- if an error FCG_ACTPM is detected, HKTM CANBUS_ACTPM_HEALTH flag is set to FALSE;
 *     -- if an error FCG_EXTCAN is detected, HKTM CANBUS_EXT_HEALTH flag is set to FALSE.
 *
 * @}
 */

/*---------- Standard libraries includes ------------------------------*/
#ifdef PORT
#include <rtems.h>
#endif
/*---------- FSW includes ---------------------------------------------*/
#ifdef PORT
#include "initLib.h"
#endif
#include "errorLib.h"
#include "cyclicMgr.h"
#ifdef PORT
#include "rtcCplr/RtcCplrHk.h"
#include "rtcCplr/RtcCplr.h"
#endif
/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenCommon.h"
#include "coMgt/CanOpenAction.h"
#include "coMgt/CanOpenMgt.h"
#include "coMgt/CanOpenBus.h"

/*---------- Local defines & macro ------------------------------------*/

/* Event received by CanOpenMgt synchronisation task */
#define COMGT_FAST_RTC_EVENT    (0x40000000)

/* All events received by Bus manager tasks */  
#define ALL_SYNC_EVENTS (0xFFFFFFFF)

/* Build a different event according bus ID and slot number 
 * 0xFC00000 -> 2  
 * 0xFFFFFF -> 20bits for 20 different IT interrupts */
#define EVENT_FROM_BUS_SLOT(bus, interruptSlot) (((1<<(22+((bus)&1)))&0xFC00000) | ((1<<(interruptSlot))&0xFFFFF))

/*---------- Local types definitions ----------------------------------*/

/*
 * RtcSynCtx: RTC based synchronisation Context descriptor 
 */
typedef struct RtcSyncCtx
{ 
  Bool     syncTaskActive; /**< @brief flag indicating if the synchronisation task is active */
  rtems_id syncTaskId;     /**< @brief task ID of sync task */
  Uint     cycleCount;     /**< @brief synchronisation cycle count since the beginning */
  Uint     curSlot;        /**< @brief current slot count in the current cycle */
  Uint     itCurSlot;      /**< @brief current IT slot count in the current cycle */
  Uint     coarseTime32B;  /**< @brief CCSDS time coarse time part in 32 bits */
  U16      fineTime16B;    /**< @brief CCSDS time fine part in 16 bits (LSB) */
} RtcSynCtx;

/*---------- Definition of variables exported by the module -----------*/

/* exported slot-based synchronisation data structure for (unit test purpose) */

#ifdef COMGT_UT_SUPPORT
#include <stdio.h>
rtems_id    CoMgt_SlotSyncSemId[ROV_CANBUS_NUM]= {0,0};
Uint        CoMgt_itSlotInCycle = 0;
Uint        CoMgt_SlotInCycle = 0;
Uint        CoMgt_Cycles = 0;
Uint        CoMgt_MstState[ROV_CANBUS_NUM];
rtems_id    CoMgt_MstWakeUpSemId[ROV_CANBUS_NUM];
#endif

/**
 * @brief CoMgr_ticksPerSecond is the current setting of ticks in a second.
 */
U32 CoMgr_ticksPerSecond;

/**
 * @brief CoMgr_canBusInitialised - flag to say if the CAN bus managers are initialised or not.
 */
T_BOOL CoMgr_canBusInitialised = FALSE;

/**
 * @brief CoMgr_isFirstActivation - flag to say if the this is the first activation of the CAN cyclic manager.
 */
T_BOOL CoMgr_isFirstActivation = TRUE;

/*---------- Definition of local variables and constants --------------*/

/*
 * The CAN Bus Management Synchronisation context
 * The synchronisation context is used by CAN Bus Management
 * for RTC-based synchronisation event handling
 */
PRIVATE RtcSynCtx rtcSynCtx =
{
  .syncTaskActive = FALSE,
  .syncTaskId = 0,
  .cycleCount = 0,
  .curSlot = 0,
  .itCurSlot = 0,
  .coarseTime32B = 0,
  .fineTime16B = 0
};

/*---------- Declarations of local functions --------------------------*/

PRIVATE void cycleScetGet(U32 *pCoarseU32B, U16 *pFineU16B);
PRIVATE Bool busMgrRestart(void);

/*------------------ ooOoo Inline functions (if any) ooOoo ------------*/

/*------------------ ooOoo Global functions ooOoo ---------------------*/

/**
 * @addtogroup coMgr
 * @{
 */
/***********************************************************************/
/**
 * @brief  CanOpenMgt_init - Initialisation of the CANopen management service
 * 
 * This function is the entry point of the CANopen management service. 
 * It shall be invoked during SW start-up operation once and only once.
 *  
 * This function performs the global initialisation operations for
 * CANopen management for both the Platform and Payload CAN Bus. In particular,
 * it sets up the configuration parameters and working context specific 
 * for each bus using parameter coming from external configuration files via
 * specific header files.
 *
 * @param[in] evtPid    Application Process ID to be used when generating events
 *
 * @return N/A
 *
 ***********************************************************************/ 
void CanOpenMgt_init(U16 evtPid)
{
  Uint bus;
  CoCtx *pCtx;

  rtems_clock_get(RTEMS_CLOCK_GET_TICKS_PER_SECOND, (void*)&CoMgr_ticksPerSecond);
  /* setup automaton start-up context for all CAN busses */
  for (bus = 0; bus < ROV_CANBUS_NUM; bus++)
  {
    pCtx = &CoMgr_ctx[bus];
    (void)CanOpenAction_setup(pCtx, evtPid);
#ifdef COMGT_UT_SUPPORT
    /* no essential node for "remove" test purpose */
    pCtx->nodeSwitchOnMsk = 0;
#endif
  }  
  
  /* Initialise RTC Coupler interface context */
  rtcSynCtx.syncTaskActive = FALSE;
  rtcSynCtx.syncTaskId = 0;
  rtcSynCtx.cycleCount = 0;
  rtcSynCtx.curSlot = 0;
  rtcSynCtx.itCurSlot = 0;
  rtcSynCtx.coarseTime32B = 0;
  rtcSynCtx.fineTime16B = 0;
  
#ifdef COMGT_UT_SUPPORT
  {
    rtems_attribute attribute;
    rtems_name      semName;
    rtems_id        semId;
    rtems_status_code rtSts;
    
    CoMgt_SlotInCycle = 0;
    CoMgt_itSlotInCycle = 0;
    CoMgt_Cycles = 0;
    
    for (bus = 0; bus < ROV_CANBUS_NUM; bus++)
    {
      /* create synchronising semaphore for slot synchronization for all bus slaves */
      attribute = RTEMS_PRIORITY;
      semName   = rtems_build_name('S', 'L', 'O', 'T'+bus);
      rtSts     = rtems_semaphore_create(semName, 0,
                  attribute|RTEMS_SIMPLE_BINARY_SEMAPHORE, 0, &semId);

      CoMgt_SlotSyncSemId[bus] = semId;

      /* create synchronising semaphore for slot synchronization for all bus slaves */
      attribute = RTEMS_PRIORITY;
      semName   = rtems_build_name('W', 'A', 'K', bus);
      rtSts     = rtems_semaphore_create(semName, 0,
                  attribute|RTEMS_SIMPLE_BINARY_SEMAPHORE, 0, &semId);
      CoMgt_MstWakeUpSemId [bus] = semId; 
    }
  }
#endif
}

/***********************************************************************/
/**
 * @brief  CanOpenMgt_modifyDefaultChannel - modify the default initial channel 
 * 
 * This function is dedicated to modify the channel used at bus manager
 * start-up. It is useful only if the default initial channel is the redundant
 * one, instead of the nominal one.
 * 
 * It shall be invoked before CANopen Manager task for the specified
 * CAN Bus is started.
 *
 * @param[in] busId   The bus Identifier
 *                    - \@link CANBUS_ID_PF \@endlink or
 *                    - \@link CANBUS_ID_PL \@endlink
 * @param[in] chanId  The channel ID
 *                    - \@link CANBUS_NOM_CHAN \@endlink or
 *                    - \@link CANBUS_RED_CHAN \@endlink
 * @return            - \@link OK \@endlink or
 *                    - \@link ERROR \@endlink 
 ***********************************************************************/ 
U32 CanOpenMgt_modifyDefaultChannel(U32 busId, U32 chanId)
{
  U32 result;
  
  /* check Bus ID */
  if (!CO_BUS_ID_VALID(busId))
  {
    result = ERROR;
  }
  /* check Bus ID */
  else if (!CO_CHAN_ID_VALID(chanId))
  {
    result = ERROR;
  }
  /* all checks OK, modify the default setting and working context */
  else
  {
    CoMgr_defaultBus[busId] = chanId;
    CoMgr_ctx[busId].chanId = chanId;
    result = OK;
  }
  return result;
}

/***********************************************************************/
/**
 * @brief  CanOpenMgt_getCurrentChannel - return the current channel for a bus 
 * 
 * This function returns the current channel for the input bus, retrieved 
 * from the bus context.
 *
 * @param[in] busId      The bus Identifier
 *                       - \@link CANBUS_ID_PF \@endlink or
 *                       - \@link CANBUS_ID_PL \@endlink
 * @param[out] pChanId   The channel ID
 *                       - \@link CANBUS_NOM_CHAN \@endlink or
 *                       - \@link CANBUS_RED_CHAN \@endlink
 * @return               TRUE if channel Id has changed since last call 
 *                       to function, FALSE otherwise
 ***********************************************************************/ 
Bool CanOpenMgt_getCurrentChannel(U32 busId, U32* pChanId)
{
  Bool outputStatus = FALSE;
  
  /* check Bus ID */
  if ((!CO_BUS_ID_VALID(busId)) || (pChanId == NULL_VOID_PTR))
  {
    /* if invalid, raise a SW ERROR */
    ERROR_REPORT(SW_ERROR, busId, 0, 0);
  }
  else
  {
    /* return the current channel for that bus */
    *pChanId = CoMgr_ctx[busId].chanId;
    
    /* return the output flag for channel Id switch */
    outputStatus = CoMgr_ctx[busId].busChanIdSwitched;
    
    /* reset the flag for channel Id switch */
    CoMgr_ctx[busId].busChanIdSwitched = FALSE;
  }
  
  return outputStatus;
}

/***********************************************************************/
/**
 * @brief  CanOpenMgt_setCanBusInitialised - set the CanBus managers as initialised 
 * 
 * This function sets the flag CoMgr_canBusInitialised to TRUE.
 * 
 * It shall be invoked before CANopen Manager task for the specified
 * CAN Bus is started.
 *
 * @return N/A
 ***********************************************************************/ 
void CanOpenMgt_setCanBusInitialised(void)
{
  CoMgr_canBusInitialised = TRUE;
}

/***********************************************************************/
/**
 * @brief  CanOpenMgt_syncTaskBody - Synchronisation handler task
 * of the CANopen management service
 * 
 * This function implements the CANopen synchronisation task. It works as
 * cyclic task and activated by CDHS cyclic task manager upon event from OBT
 * (expected as 100 ms cycle).  
 * 
 * Upon its activation, the synchronisation task registers for the reception 
 * of the 200Hz event from the rtcCplr. When the first CDHS cyclic task event 
 * is received, the following 19 events from the RtcCplr are processed, then 
 * the CDHS cyclic event is waited again, and so on.
 * 
 * The task re-distributes to the 2 bus managers the 100 ms and 5 ms timing
 * events as well as CUC time of the 100 ms cycle.  
 * 
 * @param[in] unused  Parameter as per RTEMS task create protocol 
 * @return N/A
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0900 [First Slot synchronised with RTC]
 * 
 ***********************************************************************/ 
void CanOpenMgt_syncTaskBody(rtems_task_argument unused)
{
#ifdef COMGT_UT_SUPPORT
  Uint bus;
  CoCtx *pCtx;
  Uint loop = 0;
#endif
  Uint cyclicHdl; 
  Bool waitRTC = TRUE;
  Bool go = TRUE;
  
  PARAM_NOT_USED(unused);
  
  /* retrieve its own task Id */
  (void) rtems_task_ident (RTEMS_SELF, RTEMS_SEARCH_LOCAL_NODE, &rtcSynCtx.syncTaskId);
  
  /* store it in the RTC synchronisation context */
  rtcSynCtx.syncTaskActive = TRUE;
 
  /* Wait for the end of initialisation of all the tasks */
  cdhsInitWait();
  
  /* Register to the cyclic manager */
  cyclicHdl = cdhsCyclicRegister(1,0,1);
  
  /* Register to the RTC coupler to receive Fast RTC notifications */
  RtcCplr_registerTaskForFastRTC(COMGT_FAST_RTC_EVENT);
      
  waitRTC = TRUE;
  /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro already called for this error case. */
  while (go)
  {
    /* Wait for Correct timing Event */
    if (waitRTC == TRUE)
    {
      /* first slot: started by SW cycle at 10 Hz */ 
      
      /* Wait for the cycle activation: expected as 10HZ (100 ms) */
      cdhsCyclicWait(cyclicHdl);
      
      /* update counters */
      rtcSynCtx.cycleCount++;
      rtcSynCtx.curSlot = 0;
      rtcSynCtx.itCurSlot = 0;
      
      /* update the SCET time */
      cycleScetGet (&rtcSynCtx.coarseTime32B, &rtcSynCtx.fineTime16B);
      
      /* Waiting for Fast RTC */ 
      waitRTC = FALSE;
    }
    else
    {
      /* Following slots: started by Fast RTC */
      
      /* Wait for the slot activation */      
      go = RtcCplr_waitForFastRTCSlotEvt(RTEMS_NO_TIMEOUT);
      
      /* if a wrong event is received, stop */
      /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro called here. */
      if (go)
      {
        /* update counters */
        rtcSynCtx.itCurSlot = RtcCplr_getFastRTCSlot();        
        if((rtcSynCtx.itCurSlot > 0) && (rtcSynCtx.itCurSlot % 2) == 0)
        {
          rtcSynCtx.curSlot = (rtcSynCtx.itCurSlot / 2);
        }        
      
        /* Waiting for Nominal RTC if this is the last Fast RTC slot */
        if (rtcSynCtx.itCurSlot == (FAST_RTC_SLOTS_IN_RTC -1))
        {
          waitRTC = TRUE;
        }
      }
      else
      {
         ERROR_REPORT(SW_ERROR, rtcSynCtx.itCurSlot, rtcSynCtx.curSlot, 0);
      }
    }
      
    /* %COVER%FALSE% Defensive programming - ERROR_REPORT macro already called before. */
    if (go)
    {
      /* send the event to the Bus managers */
      if (CoMgr_canBusInitialised == TRUE)
      {
        /* wake up for the first time the bus managers in slot 0 */ 
        if ((CoMgr_isFirstActivation == FALSE) || (rtcSynCtx.itCurSlot == 0))
        {
          CoMgr_isFirstActivation = FALSE;
          go = busMgrRestart();
        }
      }
#ifdef COMGT_UT_SUPPORT
      
      CoMgt_SlotInCycle = rtcSynCtx.curSlot;
      CoMgt_itSlotInCycle = rtcSynCtx.itCurSlot;
      CoMgt_Cycles = rtcSynCtx.cycleCount;
      
      for (bus = 0; bus < ROV_CANBUS_NUM; bus++)
      {
        /* %COVER%TRUE% Defensive programming - ERROR_REPORT macro called here. */            
        if (rtems_semaphore_flush(CoMgt_SlotSyncSemId[bus]) != RTEMS_SUCCESSFUL)
        {
          pCtx = &CoMgr_ctx[bus];
          ERROR_REPORT(SW_ERROR, bus, pCtx->taskId, loop);
        }
      }
#endif
    }
  }
  
  /* Suspended to be analysed or deleted */
  rtems_task_suspend(RTEMS_SELF);
}

/***********************************************************************/
/**
 * @brief  CanOpenMgt_busMgr - CANopen Manager task for CAN Bus
 * 
 * 
 * This function implements the CANopen manager, working as an automaton
 * following the transition table CANopen state machine & trigger graph defined
 * by the CANopen Standard and tailored for Rover project. 
 * 
 * The manager uses transition table of the bus manager to identify
 * the significant events and then invokes specified actions to 
 * perform necessary operations.
 * 
 * The bus manager is activated on timing event (10Hz or 200 Hz), it takes
 * incoming application's NMT command and performs adequate action
 * following pre-defined transition table.
 * 
 * The CANopen managers for Platform and Payload buses are supported by this function.
 * A manager uses the input bus identifier to get the corresponding configuration and
 * working context of the specified bus and works independently of the another one. 
 * 
 * @param[in] busId The bus identifier
 *            - \@link CANBUS_ID_PF \@endlink or
 *            - \@link CANBUS_ID_PL \@endlink
 * @return N/A
 * 
 * @requirements
 * - SRS.DMS.CAN.FUNC.0010
 * - SRS.DMS.CAN.FDIR.0100 [stop the link if ACTPM fail]
 * - SRS.DMS.CAN.FDIR.0200 [stop the link if EXT CAN fail]
 ***********************************************************************/ 
void CanOpenMgt_busMgr(rtems_task_argument busId)
{
  CoCtx *pCtx;
  rtems_status_code rtStatus;
  rtems_event_set rtEvtOut;
  rtems_event_set expRtEvt;
  Bool go = TRUE;
  Uint slotToWait;

  /* check specified bus ID */
  /* %COVER%TRUE% Defensive programming:
   * case when invalid bus Id is used to create bus manager
   * ERROR_REPORT is invoked
   */
  if ((busId != CANBUS_ID_PF) && (busId != CANBUS_ID_PL))
  {
    ERROR_REPORT(SW_ERROR, busId, 0, 0);
    pCtx = NULL;
    go = FALSE;
  }
  else
  {
    /* initialise its context pointer */
    pCtx = &CoMgr_ctx[busId];
    
    /* retrieve & update its own task in its context
     * This function call is not expected to fail and no
     * actions are deemed necessary/adequate in case of failure.
     * Therefore the return value can be safely ignored
     */
    (void)rtems_task_ident (RTEMS_SELF, RTEMS_SEARCH_LOCAL_NODE, &pCtx->taskId);
    
    /* prepare the first incoming event */    
    slotToWait = 0;
    
    /* wait for the first Slot (0) */
    rtEvtOut = 0;
    expRtEvt = EVENT_FROM_BUS_SLOT(busId, slotToWait);
    rtStatus = rtems_event_receive (expRtEvt, RTEMS_WAIT|RTEMS_EVENT_ANY,
                                    RTEMS_NO_TIMEOUT, &rtEvtOut);
    /* %COVER%TRUE% Defensive programming:
     * case when an unexpected rtems error occurs, or unexpected event is received
     * ERROR_REPORT is invoked
     */
    if ((rtStatus != RTEMS_SUCCESSFUL) || (rtEvtOut != expRtEvt))
    {
      ERROR_REPORT(SW_ERROR, rtStatus, rtEvtOut, expRtEvt);
      go = FALSE;
    }
    else
    {
      /* First cycle */
      pCtx->cycles = 0;
      pCtx->itInCycle = 0;
    }
    
  }
  
  /* Start Loop until RTEMS problems. At this point the task is synchronised with 
   * the Nominal RTC */           
  /* %COVER%FALSE% Defensive programming: ERROR REPORT already called when the go variable is set to FALSE */
  while (go)
  {
    /* update current Bus Cycle count */    
    if(pCtx->itInCycle == 0)
    {
      pCtx->cycles++;
    }
    
    /* update current slots Cycle count */
    
    /* Update slots (Half Fast RTC counts) */ 
    if(pCtx->itInCycle%2 == 0)  
    {
      pCtx->slots++;
    }
    
    /* store the number of elapsed it Slots in the Bus context */
    CanOpenBus_storeItFromStart(pCtx->busId, ((pCtx->cycles * FAST_RTC_SLOTS_IN_RTC) + pCtx->itInCycle));
       
    /* Invoke state machine if both active PM and external can Bus are safe
     * otherwise, no operation */
    if ((pCtx->actPmHealth == E_CO_PM_HEALTH_SAFE) &&
        (pCtx->extCanHealth == E_CO_EXTCAN_HEALTH_SAFE))
    {
      CanOpenAction_busMgrAutom(pCtx);
    }
    else
    {
      /* update the HK at the beginning of a cycle */
      if ((pCtx->curState != E_COSTATE_OFF) && (pCtx->itInCycle == 0))
      {
        pCtx->curState = E_COSTATE_OFF;
        CanOpenAction_updateHkArea(pCtx,  E_COSTATE_OFF);
      }
    }
      
#ifdef COMGT_UT_SUPPORT
    if (pCtx->curState != CoMgt_MstState[pCtx->busId])
    {
      CoMgt_MstState[pCtx->busId] = pCtx->curState;
    }
#endif
   
    /* wait for the next IT sync event */
    slotToWait = (pCtx->itInCycle + 1) % FAST_RTC_SLOTS_IN_RTC;
    rtEvtOut = 0;
    expRtEvt = EVENT_FROM_BUS_SLOT(busId, slotToWait); 
    
    rtStatus = rtems_event_receive (ALL_SYNC_EVENTS, RTEMS_WAIT|RTEMS_EVENT_ANY,
                                    RTEMS_NO_TIMEOUT, &rtEvtOut);       
    /* %COVER%TRUE% Defensive programming: unexpected event received - loss of synchronisation */
    if ((rtStatus != RTEMS_SUCCESSFUL) || (rtEvtOut != expRtEvt))
    {
      ERROR_REPORT(SW_ERROR, rtStatus, slotToWait, 0);
      ERROR_REPORT(SW_ERROR, expRtEvt, rtEvtOut, 0);
            
      go = FALSE;
    }
  } /* while */
  
  /* suspended to be analysed or deleted */
  rtems_task_suspend(RTEMS_SELF);
}

/** @} */
/*------------------ ooOoo Local functions ooOoo ----------------------*/

/***********************************************************************/
/**
 * @brief cycleScetGet - get the cycle's CUC time
 * 
 * This function retrieves, from RTC coupler, the SCET time of the
 * starting time of the current cycle in format defined by CCSDS
 *
 * @param[out] pCoarseU32B  The buffer to store 32-bit coarse time
 * @param[out] pFineU16B    The buffer to store retrieved fine time of 16 bits
 * @return    N/A 
 *
 ***********************************************************************/ 
PRIVATE void cycleScetGet(U32 *pCoarseU32B, U16 *pFineU16B)
{
  U32 coarse = 0;
  U32 fine = 0;
  
#ifdef COMGT_UT_SUPPORT
  Uint cycle = 0;
  /* simulation: default starting time: coarse: 0 fine: n*100ms + 2
   * note: +2 => to get carry when calculating next cycle time */
  cycle = rtcSynCtx.cycleCount;
  coarse = (cycle/CO_CYCLE_IN_1SEC);
  fine = 2 + (U16_MAX * (cycle%CO_CYCLE_IN_1SEC))/ CO_CYCLE_IN_1SEC;
#else
  /* get OBT from RtcCplr */
  coarse = RtcCplr_syncObt.coarseOBT;
  fine = RtcCplr_syncObt.subSeconds;
#endif
  *pCoarseU32B = coarse;
  *pFineU16B = fine & U16_MSK;
}

/***********************************************************************/
/**
 * @brief  busMgrRestart - restart the Bus Managers in the current Interrupt slot.
 *
 * This function restarts Bus Managers with the events corresponding to
 * the current 200Hz clock Interrupt slot number [0-19].
 *
 * @return            TRUE or FALSE
 *
 ***********************************************************************/ 
PRIVATE Bool busMgrRestart(void)
{
  Uint bus;
  CoCtx *pCtx;
  rtems_status_code rtStatus;
  rtems_event_set rtEvt;
  Bool go = TRUE;
  
  /* send the event to the Bus managers */
  for (bus = 0; ((bus < ROV_CANBUS_NUM) && go); bus++)
  {
    pCtx = &CoMgr_ctx[bus];
   
    /* transmit cycle SCET time at the beginning of a cycle */
    if (rtcSynCtx.itCurSlot == 0)
    {
      pCtx->cucC32B = rtcSynCtx.coarseTime32B;
      pCtx->cucF16B = rtcSynCtx.fineTime16B;
    }
    
    /* Update the Fast RTC slot and Half RTC slot */
    pCtx->itInCycle = rtcSynCtx.itCurSlot;
    pCtx->slotInCycle = rtcSynCtx.curSlot;
    
    /* Notify both CAN Buses of a new RTC or Fast RTC slot.
     * Use a different rtems event for each Fast RTC slot */
    rtEvt = EVENT_FROM_BUS_SLOT(bus, rtcSynCtx.itCurSlot);    
    rtStatus =  rtems_event_send(pCtx->taskId, rtEvt);    

    /* %COVER%TRUE% Defensive programming:
       Case when the rtems primitive "rtems_event_send" call has failed. 
       ERROR_REPORT macro called at end of procedure*/
    if (rtStatus != RTEMS_SUCCESSFUL)
    {
      ERROR_REPORT(SW_ERROR, rtStatus, pCtx->taskId, rtEvt);
      go = FALSE;
    }
  }
  return go;
}

#ifdef COMGT_UT_SUPPORT
U32 CanOpenMgt_getRtRelax(void)
{
  return RT_RELAX;
}
#endif

/*------------------ ooOoo End of file ooOoo --------------------------*/
