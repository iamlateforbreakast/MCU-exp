/* CoMgtHk.h - CANopen Management House Keeping Definitions */

/* Copyright (c) 2014 - AIRBUS Defence & Space */

/* Project : Exomars Rover Vehicle */

#ifndef _CoMgtHk_
#define _CoMgtHk_

/***********************************************************************/
/**
 * @file
 * @brief CoMgtHk.h - header file for CANopen Management House Keeping 
 * parameters description.
 *
 * There are two data areas contenting all House keeping parameters for
 * the platform bus and payload bus (CoMgr_hkArea[ROV_CANBUS_NUM]). A
 * HK data area is managed as a structure @link CoBusHkArea @endlink.
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenConfig.h"
#include "coMgt/CanOpenCommon.h"

/*---------- Defines & macro ------------------------------------------*/

/* Common defines for HK parameter's calibration: as defined in SWDB */
#define CO_STATUS_FAIL  (0)
#define CO_STATUS_SAFE  (1)

/* Definition related to CanOpenMaganement Observability parameters:
 * - Housekeeping
 * - Monitoring
 */

/* for activeSide 
 * values are defined in accordance with SWDB
 */
#define CO_BUS_NOM (0x0)  
#define CO_BUS_RED (0x1)

/**
 * @brief CoNodeHealthSts: Node Status
 *
 * The CoNodeHealthSts is a enum type representing the status of
 * a node on the CAN bus for slaves as well so for master.
 * 
 * @note The values are defined in accordance with SWDB
 * 
 */
typedef enum
{
  E_CO_NODE_HEALTH_FAIL     = CO_STATUS_FAIL, /**< @brief Node Failed */
  E_CO_NODE_HEALTH_SAFE     = CO_STATUS_SAFE  /**< @brief Node Healthy */
} CoNodeHealthSts;

/**
 * @brief CoPmHealthSts: PM healthy Status
 *
 * The CoPmHealthSts is a enum type representing the status of the PM
 * 
 * @note The values are defined in accordance with SWDB
 * 
 */
typedef enum
{
  E_CO_PM_HEALTH_FAIL     = CO_STATUS_FAIL, /**< @brief PM Failed */
  E_CO_PM_HEALTH_SAFE     = CO_STATUS_SAFE  /**< @brief PM Healthy */
} CoPmHealthSts;

/**
 * @brief CoExtCanHealthSts: Can External Status
 *
 * The CoExtCanHealthSts is a enum type representing the status of
 * external can
 * 
 * @note The values are defined in accordance with SWDB
 * 
 */
typedef enum
{
  E_CO_EXTCAN_HEALTH_FAIL     = CO_STATUS_FAIL, /**< @brief EXTCAN Failed */
  E_CO_EXTCAN_HEALTH_SAFE     = CO_STATUS_SAFE  /**< @brief EXTCAN Healthy */
} CoExtCanHealthSts;

/**
 * @brief CoBusSts: Bus State
 *
 * The CoBusSts is a enum type representing the status of
 * CAN Bus
 * 
 * @note The values are defined in accordance with SWDB
 * 
 */
typedef enum
{
  E_CO_BUS_FAIL     = CO_STATUS_FAIL, /**< @brief Bus Failed */
  E_CO_BUS_OK       = CO_STATUS_SAFE  /**< @brief Bus OK */
} CoBusSts;

/**
 * @brief CoNodeSts: Node CANOpen State
 *
 * The CoBusSts is a enum type representing the CANOpen status of
 * CAN node
 * 
 * @note The values are defined in accordance CANOpen Standard
 * 
 */
typedef enum
{
  E_CO_NODE_STS_OFF  = E_COSTATE_OFF, /**< @brief CANOpen Off state */
  E_CO_NODE_STS_INIT = E_COSTATE_INIT, /**< @brief CANOpen Init state*/
  E_CO_NODE_STS_PRE_OP = E_COSTATE_PRE_OP, /**< @brief CANOpen Pre-operational state */
  E_CO_NODE_STS_OP     = E_COSTATE_OP, /**< @brief CANOpen Operational state */
  E_CO_NODE_STS_STOP   = E_COSTATE_STOP /**< @brief CANOpen Stop state */
} CoNodeSts;

  
#define CO_PDO_TM_MAX_PER_NODE (CO_COBID_COUNT_MAX*CANOPEN_TPDO_PER_NODE)

/*---------- Types definitions ----------------------------------------*/

/**
 * @brief CoNodeInfo: Node Information 
 */
typedef struct CoNodeInfo
{
  U08 nodeId;        /**< @brief device base node ID */
  U08 nodeIdCnt;     /**< @brief device node ID count */
  U08 switchOn;      /**< @brief device state as notified by application */
  U08 state;         /**< @brief device state as announced by its last HB message */
  U32 hbTotal;       /**< @brief the HB received from the node */
  U32 lastHbCycle;   /**< @brief cycle of last received HB message */
  U32 nmtCnt;        /**< @brief NMT messages sent to the node TC */
  U32 retCnt;        /**< @brief RET messages sent to the node TC */
  U32 pdoTcCnt;      /**< @brief PDO TC counter */
  U32 pdoTmCnt;      /**< @brief PDO TM counter */
  U32 sdoExpdtUlCnt; /**< @brief Expedited SDO upload transfer counter */
  U32 sdoExpdtDlCnt; /**< @brief Expedited SDO download transfer counter */
  U32 sdoExpdtAbtCliCnt;/**< @brief Expedited SDO Aborted transfer counter by client */
  U32 sdoExpdtAbtSerCnt;/**< @brief Expedited SDO Aborted transfer counter by server */
  U32 sdoExpdtAbtCliCode;/**< @brief latest cycle Expedited SDO Aborted transfer code by client */
  U32 sdoExpdtAbtSerCode;/**< @brief latest cycle Expedited SDO Aborted transfer code by server */
  U32 sdoBlkUlCnt;   /**< @brief Block SDO upload transfer counter */
  U32 sdoBlkDlCnt;   /**< @brief Block SDO download transfer counter */
  U32 sdoBlkAbtCliCnt;  /**< @brief Block SDO aborted transfer counter by client */
  U32 sdoBlkAbtSerCnt;  /**< @brief Block SDO aborted transfer counter by server */
  U32 sdoBlkAbtCliCode;  /**< @brief latest cycle Block SDO aborted transfer code by client */
  U32 sdoBlkAbtSerCode;  /**< @brief latest cycle Block SDO aborted transfer code by server */
  U32 sdoBlkStatus;  /**< @brief last Block SDO transfer execution result */
  
  /* FDIR status for monitoring */
  U32 canHbFr;       /**<@brief CAN HB Failures register of the node */
} CoNodeInfo;

/**
 * @brief CoBusHkArea: CANopen Bus HK Area
 * 
* @requirements
* - SRS.DMS.CAN.OBS.0010
* 
 */
typedef struct CoBusHkArea
{
  /* master management */
  U32 cycle;        /**< @brief current cycle */
  U32 busStateTrans;/**< @brief master state transitions occurred */
  U08 activeSide;   /**< @brief Nominal or Redundant */
  U08 busState;     /**< @brief CANopen Master (NMT) state */
  U08 healthStatus; /**< @brief master health status */
  U08 ctoggle;      /**< @brief Ctoggle counter */
  U32 cucCoarse32B; /**< @brief CUC Time coarse part of the current cycle */
  U16 cucFine16B;   /**< @brief CUC Time fine part of the current cycle */
  U08 actPmHealth;  /**< @brief active PM health status */
  U08 extCanHealth; /**< @brief external CAN Bus health status */
  U32 canStat;      /**< @brief CAN IF status register content */

  /* equipment management */
  U08 nodes;        /**< @brief number of slave node on the bus */
  U08 toggleNode;   /**< @brief latest triggered node */
  U08 uhfHailNode;  /**< @brief latest hail node */
  U08 unexpHbNode;  /**< @brief unexpected HB message cycle */
  U32 toggleCycle;  /**< @brief latest triggered cycle */
  U32 uhfHailCycle; /**< @brief latest Hail cycle */
  U32 unexpHbCycle; /**< @brief unexpected HB message cycle */
  
  U32 switchMsk;    /**< @brief current switch-on node mask */
  U32 hbRegMsk;     /**< @brief current HB message reception mask */
  U32 lastHbCycle;  /**< @brief cycle number at last HB generation time */

  /* traffic statistics */
  U32 canTxMsgs;      /**< @brief total transmitted CAN messages */
  U32 canRxMsgs;      /**< @brief total received CAN messages */
  U32 tcCount;        /**< @brief total TC handled */
  U32 tmCount;        /**< @brief total TM handled */
  U32 expdtSdoUl;     /**< @brief total Expedited SDO upload transfer */
  U32 expdtSdoDl;     /**< @brief total Expedited SDO download transfer */
  U32 expdtSdoAbt;    /**< @brief total Expedited SDO aborted transfer */
  U32 blkSdoUl;       /**< @brief total Block SDO upload transfer */
  U32 blkSdoDl;       /**< @brief total Block SDO download transfer */
  U32 blkSdoAbt;      /**< @brief total Block SDO Aborted transfer */
  U32 hbMsgsIn;       /**< @brief Received Heart Beat messages */
  U32 hbMsgsOut;      /**< @brief Transmitted Heart Beat messages */
  U32 pdoMsgsIn;      /**< @brief Received Heart Beat messages */
  U32 pdoMsgsOut;     /**< @brief Transmitted Heart Beat messages */
  U32 sdoMsgsIn;      /**< @brief Received Heart Beat messages */
  U32 sdoMsgsOut;     /**< @brief Transmitted Heart Beat messages */
  U32 nmtMsgs;        /**< @brief Transmitted NMT messages */
  U32 syncMsgs;       /**< @brief Transmitted SYNC messages */
  U32 retMsgs;        /**< @brief Transmitted RET messages */
  
  /* FDIR status for monitoring */
  U32 canErrSts;      /**< @brief CAN error status */
  U32 canHbFc;        /**< @brief CAN HB failure count */
  U32 canTotHbF;      /**< @brief CAN total HB failure */

  U32 dummyPdoCnt;    /**< @brief Number of dummy PDO sent on the bus by the driver */
  
  CoNodeInfo nodeInfo[CO_SLV_NODES_MAX];      /**< @brief node info description */

} CoBusHkArea;


/*---------- Variables exported by the module -------------------------*/

/*
 * CoMgr_hkArea: Housekeeping area for both CAN Buses
 */
PUBLIC CoBusHkArea CoMgr_hkArea[ROV_CANBUS_NUM];

/**
 * @brief CoMgr_canNodeIdSdoDlOverwite: node identifier for the SDO download operations
 * when receiving a TC(2,130), whose node identifier field is set to 0
 *  
 * @requirements
 * - SRS.DMS.S2.OBS.0020
 * 
 */
PUBLIC U08 CoMgr_canNodeIdSdoDlOverwrite; 

/* Node State On platform bus */
PUBLIC NodeStat CoMgr_pfNodeStat[CO_PF_NODE_NUM];

/* Node State On payload bus*/
PUBLIC NodeStat CoMgr_plNodeStat[CO_PL_NODE_NUM];



/*---------- Functions exported by the module -------------------------*/

#endif /* _CoMgtHk_ */
