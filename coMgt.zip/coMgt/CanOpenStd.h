/* CanOpenStd.h - CANopen standard definition file */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenStd_
#define _CanOpenStd_

/***********************************************************************/
/** @file
 * @brief CanOpenStd.h - header file for CANopen modules.
 *
 * This file contains common definitions of CANopen standard.
 * 
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/

/*---------- Defines & macro ------------------------------------------*/
/*
 *------------------------------------
 * CAN specification definition
 *------------------------------------
 */
/*
 * CAN Message data length
 */
#define CAN_MSG_SIZE (8)

/*
 * CAN Message RTR definition 
 */
#define CAN_MSG_RTR_DATA_FRAME (0)   /**< @brief data frame */
#define CAN_MSG_RTR_REMOTE_FRAME (1) /**< @brief remote frame */

/*------------------------------------
 * CANopen Standard definition
 *------------------------------------
 */

/*
 * Node ID definition
 */ 	
#define CANOPEN_NODE_BRDCST     (0)

/**
 * @brief CanOpenStd - Master Node Id Definition 
 * 
 * @requirements
 * - SRS.DMS.CAN.FUNC.0030
 * - SRS.DMS.CAN.FUNC.0040
 */
#define CANOPEN_NODE_MASTER	    (1)
#define CANOPEN_BASE_NODE_MIN	  (0)
#define CANOPEN_BASE_NODE_MAX   (127)
#define CANOPEN_NODE_MAX        (0x77F)

/**
 * sub index range for CANopen 
 */
#define CANOPEN_OD_SUB_IDX_MIN (0)
#define CANOPEN_OD_SUB_IDX_MAX (254)

 
/**
 * @brief CanOpenStd - COB ID definition
 *
 * Applicable part list of COB ID of CANopen Standard
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0080
 * - SRS.DMS.CAN.FUNC.0090
 * - SRS.DMS.CAN.FUNC.0100
 * - SRS.DMS.CAN.FUNC.0600 [Sync Message COB ID]
 ***********************************************************************/

#define CANOPEN_COB_NMT		(0)
#define CANOPEN_COB_SYNC	(0x80)

#define CANOPEN_COB_TPDO1_BASE	(0x180)
#define CANOPEN_COB_TPDO2_BASE	(0x280)
#define CANOPEN_COB_TPDO3_BASE	(0x380)
#define CANOPEN_COB_TPDO4_BASE	(0x480)

#define CANOPEN_COB_RPDO1_BASE	(0x200)
#define CANOPEN_COB_RPDO2_BASE	(0x300)
#define CANOPEN_COB_RPDO3_BASE	(0x400)
#define CANOPEN_COB_RPDO4_BASE	(0x500)

#define CANOPEN_COB_TSDO_BASE	(0x580)
#define CANOPEN_COB_TSDO(nodeId) (CANOPEN_COB_TSDO_BASE+(nodeId))
#define CANOPEN_COB_RSDO_BASE	(0x600)
#define CANOPEN_COB_RSDO(nodeId) (CANOPEN_COB_RSDO_BASE+(nodeId))

#define CANOPEN_COB_HB_BASE	(0x700)
#define CANOPEN_COB_HB(nodeId) (CANOPEN_COB_HB_BASE+(nodeId))

#define CANOPEN_RPDO_PER_NODE  (4)
#define CANOPEN_TPDO_PER_NODE  (4)

#define CANOPEN_COBID_TO_BASE(nodeId) ((nodeId)&0x780)

/* 
 * Heartbeat/Bootup protocols related definitions
 */
#define CANOPEN_HB_MASTER_ID CANOPEN_COB_HB(CANOPEN_NODE_MASTER)
#define CANOPEN_HB_RTR       CAN_MSG_RTR_DATA_FRAME /**< @brief always data */
#define CANOPEN_HB_DATA_LEGNTH (1)   /**< @brief always 1 byte */
#define CANOPEN_HB_DATA_STS_IDX (0)  /**< @brief first data byte: state */

#define CANOPEN_HB_ST_BOOT_UP  (0)  /**< @brief heartbeat protocol: state = boot-up */ 
#define CANOPEN_HB_ST_STOP     (4)  /**< @brief heartbeat protocol: state = stopped */ 
#define CANOPEN_HB_ST_OP       (5)  /**< @brief heartbeat protocol: state = operational */ 
#define CANOPEN_HB_ST_PRE_OP   (0x7F) /**< @brief heartbeat protocol: state = pre-operational */

/* 
 * NMT protocol related definitions
 */
/** */
#define CANOPEN_NMT_CS_START        (1)  /** NMT protocol; command specifier = START_REMOTE_NODE */ 
#define CANOPEN_NMT_CS_STOP         (2)  /* NMT protocol; cs = STOP_REMOTE_NODE */ 
#define CANOPEN_NMT_CS_ENTER_PRE_OP (0x80)  /* NMT protocol; cs = ENTRY_PRE_OP */ 
#define CANOPEN_NMT_CS_RESET_NODE   (0x81) /* NMT protocol; cs = RESET_NODE */ 
#define CANOPEN_NMT_CS_RESET_COM    (0x82) /* NMT protocol; cs = RESET_COM */ 

#define CANOPEN_NMT_RTR       CAN_MSG_RTR_DATA_FRAME /* always data */

#define CANOPEN_NMT_DATA_LENGTH     (2)    /* 2 data bytes */
#define CANOPEN_NMT_DATA_CS_IDX     (0)    /* first data byte: Command Specifier */
#define CANOPEN_NMT_DATA_NID_IDX    (1)    /* second data byte: Node Id */

/*
 * SYNC protocol related definitions
 */
#define CANOPEN_SYNC_RTR       CAN_MSG_RTR_DATA_FRAME /**< @brief always data */
#define CANOPEN_SYNC_DATA_LENGTH (0)   /* no data word */

/* **************************************************************
 * SDO protocol general definitions
 */
#define CANOPEN_SDO_DATA_LENGTH     (8)    /**< @brief always 8 data bytes */
#define CANOPEN_SDO_RTR       CAN_MSG_RTR_DATA_FRAME /**< @brief always data */
#define CANOPEN_SDO_MULTIPLEXOR_SIZE (3)  /**< @brief 3-byte field */

#define CANOPEN_SDO_CCS_OFFSET       (0)
#define CANOPEN_SDO_SCS_OFFSET       (0)

#define CANOPEN_SDO_CCS_INDEX_LSB_OFFSET  (1)
#define CANOPEN_SDO_CCS_INDEX_MSB_OFFSET  (2)
#define CANOPEN_SDO_CCS_SUBIDX_OFFSET     (3)

#define CANOPEN_SDO_SCS_INDEX_LSB_OFFSET  (1)
#define CANOPEN_SDO_SCS_INDEX_MSB_OFFSET  (2)
#define CANOPEN_SDO_SCS_SUBIDX_OFFSET     (3)

/* **************************************************************
 * 
 * SDO expedited transfer definitions
 */
/*
 * SDO expedited exchange definition:
 * - field offset
 */
#define CANOPEN_SDO_EXPDT_DATA_OFFSET    (4)

/* 
 * SDO expedited exchange definition: 
 * - size range
 */
#define CANOPEN_SDO_EXPDT_DATA_MIN (1)    /**< @brief 1-byte */ 
#define CANOPEN_SDO_EXPDT_DATA_MAX (4)    /**< @brief 4-byte */ 

/*
 * SDO expedited exchange definition: 
 * - Initiate SDO Download Protocol: CCS fields definitions
 */
#define CANOPEN_SDO_CCS_EXPDT_DL_UNKWN_SZ (0x22)  /* 1-byte expedited transfer */ 
#define CANOPEN_SDO_CCS_EXPDT_DL_1BYTE (0x2F)  /* 1-byte expedited transfer */ 
#define CANOPEN_SDO_CCS_EXPDT_DL_2BYTE (0x2B)  /* 2-byte expedited transfer */ 
#define CANOPEN_SDO_CCS_EXPDT_DL_3BYTE (0x27)  /* 3-byte expedited transfer */ 
#define CANOPEN_SDO_CCS_EXPDT_DL_4BYTE (0x23)  /* 4-byte expedited transfer */ 

/*
 * SDO expedited exchange definition: 
 * - Server Command Specifier for download transfer and mask applied for checking
 */
#define CANOPEN_SDO_SCS_EXPDT_DL        (0x60) /* server command specifier (OK) for expedited transfer */
#define CANOPEN_SDO_SCS_EXPDT_DL_MSK    (0xFF) /* mask applied to check SCS */

/*
 * SDO expedited exchange definition: 
 * - Initiate SDO Download Protocol: CCS fields definitions
 */
#define CANOPEN_SDO_CCS_EXPDT_UL        (0x40)  /* initiate upload request */ 
 
/*
 * SDO expedited exchange definition: 
 * - Server Command Specifier for upload transfer and mask applied for checking
 */
#define CANOPEN_SDO_SCS_EXPDT_UL        (0x42) 
#define CANOPEN_SDO_SCS_EXPDT_UL_MSK    (0xF2)

/*
 * SDO expedited exchange definition: 
 * - Server Command Specifier and data size for upload transfer
 */
#define CANOPEN_SDO_SCS_EXPDT_UL_UNKWN_SZ  CANOPEN_SDO_SCS_EXPDT_UL /* unknown size expedited transfer */
#define CANOPEN_SDO_SCS_EXPDT_UL_1BYTE     (0x4F) /* 1-byte expedited transfer */
#define CANOPEN_SDO_SCS_EXPDT_UL_2BYTE     (0x4B) /* 2-byte expedited transfer */
#define CANOPEN_SDO_SCS_EXPDT_UL_3BYTE     (0x47) /* 3-byte expedited transfer */
#define CANOPEN_SDO_SCS_EXPDT_UL_4BYTE     (0x43) /* 4-byte expedited transfer */


/* **************************************************************
 * 
 * SDO ABORT message definitions
 */

/*
 * SDO ABORT message
 * - Command Specifier
 */
#define CANOPEN_SDO_CS_ABORT   (0x80) /* Command Specifier (abort) for SDO transfer */ 

/*
 * SDO ABORT message
 * - fields offset,/size definition
 */
#define CANOPEN_SDO_ABORT_DATA_OFFSET      (4)
#define CANOPEN_SDO_ABORT_DATA_LENGTH      (4)

/*
 * SDO ABORT message: abort codes defined by the CANOpen standard 
 * Note
 * - they are in Little Endian format
 */

#define CANOPEN_SDO_ABORT_TGL_BIT_ERR  (0x00000305) /* Toggle bit not alternated */

#define CANOPEN_SDO_ABORT_TIMEOUT      (0x00000405) /* SDO protocol timed out */
#define CANOPEN_SDO_ABORT_CS_ERR       (0x01000405) /* Command specifier invalid or unknown */
#define CANOPEN_SDO_ABORT_BLK_SIZE_ERR (0x02000405) /* Invalid block size (block mode) */
#define CANOPEN_SDO_ABORT_SEQ_NUM_ERR  (0x03000405) /* Invalid sequence number (block mode) */

#define CANOPEN_SDO_ABORT_CRC_ERR      (0x04000405) /* CRC error (block mode only) */
#define CANOPEN_SDO_ABORT_OUT_OF_MEM   (0x05000405) /* Out of memory */
#define CANOPEN_SDO_ABORT_UNSUP_ACCESS (0x00000106) /* Unsupported access to an object */
#define CANOPEN_SDO_ABORT_WRONLY_OBJ   (0x01000106) /* Attempt to read a write-only object */
#define CANOPEN_SDO_ABORT_RDONLY_OBJ   (0x02000106) /* Attempt to write a read-only object */
#define CANOPEN_SDO_ABORT_NO_OBJ       (0x00000206) /* Object does not exist in the object dictionary */
#define CANOPEN_SDO_ABORT_OBJ_NO_PDO   (0x41000406) /* Object cannot be mapped to the PDO */
#define CANOPEN_SDO_ABORT_OBJ_EXCEED_PDO (0x42000406) /* Object to be mapped exceeds PDO length */
#define CANOPEN_SDO_ABORT_PARAM_ERR    (0x43000406) /* General parameter imcompatibility reason */
#define CANOPEN_SDO_ABORT_DEVICE_ERR   (0x47000406) /* General internal imcompatibility in the device */

#define CANOPEN_SDO_ABORT_ACCESS_HW_ERR  (0x00000606) /* Access failed due to an hardware error */
#define CANOPEN_SDO_ABORT_DTYPE_NO_MATCH (0x10000706) /* Data type does not match, length of the service param. does not match  */
#define CANOPEN_SDO_ABORT_DTYPE_TOO_HIGH (0x12000706) /* Data type does not match, length of the service param. too high */
#define CANOPEN_SDO_ABORT_DTYPE_TOO_LOW  (0x13000706) /* Data type does not match, length of the service param. too low */
#define CANOPEN_SDO_ABORT_NO_SUBIDX      (0x11000906) /* Sub-index does not exist */

#define CANOPEN_SDO_ABORT_VAL_EXCEED     (0x30000906) /* Value range of param. exceeded (only for WR) */
#define CANOPEN_SDO_ABORT_VAL_TOO_HIGH   (0x31000906) /* Value of parameter written too high */
#define CANOPEN_SDO_ABORT_TOO_LOW        (0x32000906) /* Value of parameter written too high */
#define CANOPEN_SDO_ABORT_VAL_MAX_ERR    (0x36000906) /* Maximum value is less than minimun value */
#define CANOPEN_SDO_ABORT_GENERAL_ERR    (0x00000008) /* General Error */
#define CANOPEN_SDO_ABORT_DATA_STORE_ERR (0x20000008) /* Data cannot be transfered or stored to the application */
#define CANOPEN_SDO_ABORT_DATA_STORE_DENY (0x21000008) /* Data cannot be transfered or stored to the application due to local control */
#define CANOPEN_SDO_ABORT_DEV_STATE_ERR  (0x22000008) /* Data cannot be transfered or stored to the application due to the present device state */
#define CANOPEN_SDO_ABORT_DYN_OBJ_FAIL   (0x23000008) /* Object dictionary dynamic generation fails  */



/* **************************************************************
 * 
 * SDO block transfers definitions
 */

/*
 * SDO block transfer
 * - data block definitions
 */
#define CANOPEN_SDO_BLK_NBYTE_PER_SEG    (7)  /* 7-byte data in a segment */
#define CANOPEN_SDO_BLK_SEGS_MAX         (127)  /* 127 data segments for a block transfer */
#define CANOPEN_SDO_BLK_DATA_HEAD_OFFSET (0)  /* first byte: header */
#define CANOPEN_SDO_BLK_DATA_SEG_OFFSET  (1) /* from second byte: data */

/*
 * SDO block transfer
 * - data block header definitions
 */
#define CANOPEN_SDO_BLK_DATA_HEAD_SEQNO_MSK (0x7F)  /* sequence number mask */
#define CANOPEN_SDO_BLK_DATA_HEAD_SEQ_END   (0x80)  /* sequnece ending flag */

/*
 * SDO Block Upload exchange:
 * - client/server command specifiers
 */
#define CANOPEN_SDO_CCS_BLK_UL_INIT      (0xA0) /* initiate block upload */
#define CANOPEN_SDO_CCS_BLK_UL_CRC_INIT  (0xA4) /* initiate block upload (support data CRC ) */

#define CANOPEN_SDO_SCS_BLK_UL_INIT      (0xC0) /* initiate block upload */
#define CANOPEN_SDO_SCS_BLK_UL_CRC_INIT  (0xC4) /* initiate block upload (support data CRC) */
#define CANOPEN_SDO_SCS_BLK_UL_SIZE_INIT (0xC2) /* initiate block upload (with data size) */
#define CANOPEN_SDO_SCS_BLK_UL_CRC_SIZE_INIT (0xC6) /* initiate block upload (with data size and CRC) */

#define CANOPEN_SDO_CCS_BLK_UL_START    (0xA3) /* start block upload */
#define CANOPEN_SDO_CCS_BLK_UL_SEG_END  (0xA2)  /* block upload segment end */

#define CANOPEN_SDO_SCS_BLK_UL_END      (0xC1) /* end block upload */
#define CANOPEN_SDO_CCS_BLK_UL_END      (0xA1) /* end block upload */

/*
 * SDO Block Upload exchange: 
 * - Server Command Specifier and mask applied for checking
 */

/* for SDO block upload init confirm message and its mask */
#define CANOPEN_SDO_BLK_UL_INIT_CFM     (0xC0)
#define CANOPEN_SDO_BLK_UL_INIT_CFM_MSK (0xF9)

/* for SDO block upload End indication message and its mask */
#define CANOPEN_SDO_BLK_UL_END_IND      (0xC1)
#define CANOPEN_SDO_BLK_UL_END_IND_MSK  (0xE3)

/*
 * SDO Block Upload exchange:
 * - Initiate upload request: fields offsets
 */
#define CANOPEN_SDO_BLK_UL_REQ_BLKSZ_OFFSET (4)
#define CANOPEN_SDO_BLK_UL_REQ_PST_OFFSET   (5)

/*
 * SDO Block Upload exchange:
 * - field definition: PST 
 */
#define CANOPEN_SDO_BLK_PST_NOT_ALLOWED   (0) /* PST not allowed */

/*
 * SDO Block Upload exchange:
 * - upload request confirmation from server: field offset
 */
#define CANOPEN_SDO_BLK_UL_CFM_SIZE_OFFSET  (4)

/*
 * SDO Block Upload exchange:
 * - upload request response to server: field offset
 */
#define CANOPEN_SDO_BLK_UL_RESP_ACKSEQ_OFFSET   (1)
#define CANOPEN_SDO_BLK_UL_RESP_BLKSZ_OFFSET    (2)

/*
 * SDO Block Upload exchange:
 * - upload indication for End SDO Block Upload service: field offset (bit 4-2)
 */
#define CANOPEN_SDO_BLK_UL_IND_NBYTES_IN_LAST_SEG_SHIFT   (2) 
#define CANOPEN_SDO_BLK_UL_IND_NBYTES_IN_LAST_SEG_MSK     (0x7)
 
/*
 * SDO Block Download exchange:
 * - initiate download request: field offsets
 */
#define CANOPEN_SDO_BLK_DL_REQ_SIZE_OFFSET  (4)


/*
 * SDO Block Download exchange:
 * - Segment protocol confirm message from server: field offset
 */
#define CANOPEN_SDO_BLK_DL_SEG_CFM_ACKSEQ_OFFSET   (1)
#define CANOPEN_SDO_BLK_DL_SEG_CFM_BLKSZ_OFFSET    (2)

/*
 * SDO Block Download exchange:
 * - DO Block download client/server command specifiers
 */

#define CANOPEN_SDO_CCS_BLK_DL_INIT      (0xC0)  /* initiate block download */
#define CANOPEN_SDO_CCS_BLK_DL_SIZE_INIT (0xC2)  /* initiate block download with size */
#define CANOPEN_SDO_CCS_BLK_DL_CRC_INIT  (0xC4)  /* initiate block download (support data CRC ) */

/* for SDO block download End request message and its mask */
#define CANOPEN_SDO_CCS_BLK_DL_END       (0xC1) 
#define CANOPEN_SDO_CCS_BLK_DL_END_MSK   (0xE3)

/* for SDO block download init confirm message and its mask */
#define CANOPEN_SDO_BLK_DL_INIT_CFM      (0xA0)
#define CANOPEN_SDO_BLK_DL_INIT_CFM_MSK  (0xFB)

/* for SDO block download segment confirm message and its mask */
#define CANOPEN_SDO_BLK_DL_SEG_CFM       (0xA2)
#define CANOPEN_SDO_BLK_DL_SEG_CFM_MSK   (0xFF)

/* for SDO block download segment confirm message and its mask */
#define CANOPEN_SDO_BLK_DL_END_CFM       (0xA1)
#define CANOPEN_SDO_BLK_DL_END_CFM_MSK   (0xFF)

#define CANOPEN_SDO_BLK_NONE_MSG         (0xFF)

/*
 * SDO Block Download exchange:
 * - Initiate download request: field offset
 */
#define CANOPEN_SDO_BLK_DL_CFM_BLKSZ_OFFSET (4)

/*
 * SDO Block Download exchange:
 * - End CCS request: bit offset and mask for n Byte field 
 */
#define CANOPEN_SDO_CCS_BLK_DL_END_NBYTE_LSB (2)    /* LSB: bit 2 */
#define CANOPEN_SDO_CCS_BLK_DL_END_NBYTE_MSK (0x1C) /* bit 2-4 */


/*
 * PDO protocol related definitions
 */
#define CANOPEN_RPDO_RTR       CAN_MSG_RTR_REMOTE_FRAME /* read: request */
#define CANOPEN_WPDO_RTR       CAN_MSG_RTR_DATA_FRAME /* write: data */
#define CANOPEN_PDO_DATA_LENGTH_MAX     (8)    /* 8 data bytes */

/*---------- Types definitions ----------------------------------------*/

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

#endif /* _CanOpenStd_ */
