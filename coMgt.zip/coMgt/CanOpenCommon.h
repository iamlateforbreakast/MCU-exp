/* CanOpenCommon.h - common header file for CANopen modules */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenCommon_
#define _CanOpenCommon_

/***********************************************************************/
/**
 * @file
 * @brief CanOpenCommon.h - header file for CANopen modules.
 *
 * This file contains common definitions of CANopen management
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/

/*---------- FSW includes ---------------------------------------------*/
#include "cdhsTypes.h"

/*---------- Component includes ---------------------------------------*/
#include "coMgt/CanOpenStd.h"
#include "util/basicTypes.h"

/*---------- Defines & macro ------------------------------------------*/

/* This section contains common defines */

/* preliminary check */
#if (OK != 0)
#error "OK must be defined as 0"
#endif

/** NELEMENTS - number of elements in an array */
#ifndef NELEMENTS
#define NELEMENTS(array) (sizeof (array) / sizeof ((array) [0]))
#endif
/**
 * SWAP32 - swap a 32 bit integer from/to big or little-endian
 * representation
 */
#define SWAP32(value)   ( (((value) & 0xFF000000) >> 24) \
	                        | (((value) & 0x00FF0000) >> 8) \
	                        | (((value) & 0x0000FF00) << 8) \
	                        | (((value) & 0x000000FF) << 24) )

/**
 * SWAP16 - swap a 16 bit integer from/to big or little-endian
 * representation
 */
#define SWAP16(value)   ( (((value) & 0xFF00) >> 8) \
                          | (((value) & 0xFF) << 8) )

/** INVALID_CHAR_PTR - check pointer of char (8bit) */
#ifndef INVALID_U08_PTR
#define INVALID_U08_PTR(ptr)  (((ptr) != NULL) ? FALSE : TRUE)
#endif

/** INVALID_SHORT_PTR - check pointer of short (16bit) */
#ifndef INVALID_U16_PTR
#define INVALID_U16_PTR(ptr)  ((((ptr) != NULL) && ((int) (ptr) % 2) == 0) \
                                  ? FALSE : TRUE)
#endif

/** INVALID_INT_PTR - check pointer of int (32bit) */
#ifndef INVALID_U32_PTR
#define INVALID_U32_PTR(ptr)  ((((ptr) != NULL) && ((int) (ptr) % 4) == 0) \
                                 ? FALSE : TRUE)
#endif

/** INVALID_LONGLONG_PTR(ptr) - check pointer of long long (64bit) */
#ifndef INVALID_U64_PTR
#define INVALID_U64_PTR(ptr)  ((((ptr) != NULL) && ((int) (ptr) % 8) == 0) \
                                          ? FALSE : TRUE)
#endif

/** IS_OUTSIDE - check value with its allowed range */
#ifndef IS_OUTSIDE
#define IS_OUTSIDE(value,llimit,hlimit)  ((((value)<(llimit)) || ((value)>(hlimit))) \
                                          ? TRUE : FALSE)
#endif

/** NULL_VOID_PTR - This define is used to declare an null void pointer */
#ifndef NULL_VOID_PTR
#define NULL_VOID_PTR (void *)0
#endif

/** max - maximum among 2 values */
#ifndef MAX
#define MAX(x, y)       (((x) < (y)) ? (y) : (x))
#endif

/** min - minimum among 2 values */
#ifndef MIN
#define MIN(x, y)       (((x) < (y)) ? (x) : (y))
#endif

/** U16_MSK - bit-mask for an U16 value */
#define U16_MAX (0xFFFF)

/** U16_MAX - maximum value for an U16 value */
#define U16_MSK (0xFFFF)

/** U08_MSK - bit-mask for an U08 value */
#define U08_MAX (0xFF)

/** U04_MSK - bit-mask for an U04 value */
#define U04_MAX (0x0F)

/** U02_MSK - bit-mask for an U02 value */
#define U02_MAX (0x03)

/** SHF_8BIT - value for 8-bit shift */
#define SHF_8BIT (8)

/** SHF_8BIT - value for 8-bit shift */
#define SHF_2BIT (2)

/** BYTE_IN_32BIT - 4 bytes in 32-bit word */
#define BYTE_IN_32BIT (4)

/* This section contains CANopen Common defines */

/*
 * CAN Bus Identifier 
 * The CAN BUS ID values are specified in SW ICD
 */
/** PlatForm CAN Bus ID */ 
#define CANBUS_ID_PF (0)

/** PayLoad CAN Bus ID */ 
#define CANBUS_ID_PL (1)

/** There are 2 CAN Buses */ 
#define ROV_CANBUS_NUM (2)

/* common define for ABORTED */
#define CAN_STS_ABORTED (-10) 

/*
 * CAN Bus Channel Identifier 
 * The CAN BUS Channel ID values are selected arbitrarily 
 */
/** Channel Identifier for Nominal CAN Bus Channel */
#define CANBUS_NOM_CHAN (100) 

/** Channel Identifier for Redundant CAN Bus Channel */
#define CANBUS_RED_CHAN (101)

/** there are 2 Channels */ 
#define CANBUS_CHAN_NUM (2)

/** Channel Identifier of the opposite Channel */
#define CANBUS_OPPOSITE_CHAN(chan) (((chan)==CANBUS_NOM_CHAN) \
           ? CANBUS_RED_CHAN : CANBUS_NOM_CHAN)

/** get the node IDs occupied by a node from its mask */
#define CO_MGT_NMSK_TO_NIDS(nmsk) (128-(nmsk))

/** number of cycle in 1 second */
#define CO_CYCLE_IN_SECOND (10)

/* This section contains CANopen Management Specific defines */

/** CO_BUS_ID_VALID - check if CANopen Bus ID is VALID */
#define CO_BUS_ID_VALID(bus) ((((bus)==CANBUS_ID_PF) || ((bus)==CANBUS_ID_PL)) \
                                          ? TRUE : FALSE)

/** CO_CHAN_ID_VALID - check if CANopen Channel ID is VALID */
#define CO_CHAN_ID_VALID(ch) ((((ch)==CANBUS_NOM_CHAN) || ((ch)==CANBUS_RED_CHAN)) \
                                          ? TRUE : FALSE)

/** CO_BASE_NODE_VALID - check base node ID value */
#define CO_BASE_NODE_VALID(node)  (((node)<CANOPEN_NODE_MASTER||((node)>CANOPEN_BASE_NODE_MAX)) \
                                   ? FALSE : TRUE)

/** CO_SLV_BASE_NODE_VALID - check slave base node ID value */
#define CO_SLV_BASE_NODE_VALID(node)  (((node)<=CANOPEN_NODE_MASTER||((node)>CANOPEN_BASE_NODE_MAX)) \
                                   ? FALSE : TRUE)

/** INVALID_NODE_ID - check slave node ID value */
#define CO_NODE_VALID(node)  (((node)<CANOPEN_NODE_MASTER||((node)>CANOPEN_NODE_MAX)) \
                                   ? FALSE : TRUE)

/** INVALID_COB_ID - check COB-ID value */
#define CO_COB_VALID(cobId)  (((cobId)<(CANOPEN_COB_HB_BASE+CANOPEN_BASE_NODE_MAX)) \
                                   ? TRUE : FALSE)

/** CO_NODE_TO_BASE - convert a node id to its base node id */
#define CO_NODE_TO_BASE(node) ((node)&0x007F)

/** INVALID_SLV_BASE_NODE_ID - check slave base node ID value */
#define CO_SLV_BASE_NODE_VALID(node)  (((node)<=CANOPEN_NODE_MASTER||((node)>CANOPEN_BASE_NODE_MAX)) \
                                   ? FALSE : TRUE)

/** CO_BUS_ID_VALID - check if CANopen NMT command specifier is VALID */
#define CO_NMT_CMD_VALID(cmd) ((((cmd)==CANOPEN_NMT_CS_START)||((cmd)==CANOPEN_NMT_CS_STOP) \
                              ||((cmd)==CANOPEN_NMT_CS_ENTER_PRE_OP)||((cmd)==CANOPEN_NMT_CS_RESET_NODE) \
                              ||((cmd)==CANOPEN_NMT_CS_RESET_COM)) \
                                          ? TRUE : FALSE)

/** INVALID_SHORT_PTR - check HB status value */
#define CO_HB_ST_INVALID(sts)  ((((sts)==CANOPEN_HB_ST_BOOT_UP)||((sts)==CANOPEN_HB_ST_STOP) \
                                ||((sts)==CANOPEN_HB_ST_OP)||((sts) == CANOPEN_HB_ST_PRE_OP)) \
                                ? FALSE : TRUE)

/** CO_SUB_IDX_VALID - check sub index value */
#define CO_SUB_IDX_VALID(subIdx)  ((((subIdx)>CANOPEN_OD_SUB_IDX_MAX)) \
                                   ? FALSE : TRUE)

/** CO_SDO_EXPDT_DATA_SIZE_VALID - check data bytes for SDO expedited transfer */
#define CO_SDO_EXPDT_DATA_SIZE_VALID(nBytes)  (((nBytes)<CANOPEN_SDO_EXPDT_DATA_MIN||((nBytes)>CANOPEN_SDO_EXPDT_DATA_MAX)) \
                                    ? FALSE : TRUE)

/** CO_RPDO_COBID_VALID - check if the cobId is valid for RPDO: TC ->Slave */
#define CO_RPDO_COBID_VALID(cobId) \
  ((((cobId)&0xFF80) == CANOPEN_COB_RPDO1_BASE) || \
   (((cobId)&0xFF80) == CANOPEN_COB_RPDO2_BASE) || \
   (((cobId)&0xFF80) == CANOPEN_COB_RPDO3_BASE) || \
   (((cobId)&0xFF80) == CANOPEN_COB_RPDO4_BASE))
  

/** CO_TPDO_COBID_VALID - check if the cobId is valid for TPDO: TM Slave-> */
#define CO_TPDO_COBID_VALID(cobId) \
  ((((cobId)&0xFF80) == CANOPEN_COB_TPDO1_BASE) || \
   (((cobId)&0xFF80) == CANOPEN_COB_TPDO2_BASE) || \
   (((cobId)&0xFF80) == CANOPEN_COB_TPDO3_BASE) || \
   (((cobId)&0xFF80) == CANOPEN_COB_TPDO4_BASE))


/** CO_SDO_REQ_COBID_VALID - check if the cobId for SDO request is valid */
#define CO_SDO_REQ_COBID_VALID(cobId) (((cobId)&0xFF80) == CANOPEN_COB_RSDO_BASE)


/** CO_EXPDT_CCS_SDO_DL_VALID - check if the CCS for expedited SDO download is valid */
#define CO_EXPDT_CCS_SDO_DL_VALID(ccs) \
  (((ccs) == CANOPEN_SDO_CCS_EXPDT_DL_UNKWN_SZ) || \
   ((ccs) == CANOPEN_SDO_CCS_EXPDT_DL_1BYTE) || \
   ((ccs) == CANOPEN_SDO_CCS_EXPDT_DL_2BYTE) || \
   ((ccs) == CANOPEN_SDO_CCS_EXPDT_DL_3BYTE) || \
   ((ccs) == CANOPEN_SDO_CCS_EXPDT_DL_4BYTE))

/** CO_EXPDT_SCS_SDO_UL_VALID - check if the SCS for expedited SDO upload is valid */
#define CO_EXPDT_SCS_SDO_UL_VALID(scs) \
  (((scs) == CANOPEN_SDO_SCS_EXPDT_UL_UNKWN_SZ) || \
   ((scs) == CANOPEN_SDO_SCS_EXPDT_UL_1BYTE) || \
   ((scs) == CANOPEN_SDO_SCS_EXPDT_UL_2BYTE) || \
   ((scs) == CANOPEN_SDO_SCS_EXPDT_UL_3BYTE) || \
   ((scs) == CANOPEN_SDO_SCS_EXPDT_UL_4BYTE))

/** CO_EXPDT_CCS_SDO_DL_VALID - check if the CCS for expedited SDO upload is valid */
#define CO_EXPDT_CCS_SDO_UL_VALID(ccs)  ((ccs) == CANOPEN_SDO_CCS_EXPDT_UL)

/** CO_OD_BSP_STS_VALID - check if the type of a Buffer Support PDO is valid */
#define CO_OD_BSP_STS_VALID(sts) (((sts)==CO_OD_BSP_STS_READY_UL) || ((sts)==CO_OD_BSP_STS_READY_DL))

/** CO_OD_BSP_TYPE_VALID - check if the status of a Buffer Support PDO is valid */
#define CO_OD_BSP_TYPE_VALID(type) (((type)==CO_OD_BSP_TYPE_HK_UL)||((type)==CO_OD_BSP_TYPE_DUMP_UL)||\
                                    ((type)==CO_OD_BSP_TYPE_SC_UL))

/** Among the 2 buses: 2 block SDO transfers in a cycle */
//#define CO_SDO_BLK_MAX_IN_CYCLE  (MAX(CO_PF_SDO_BLK_MAX_IN_CYCLE, CO_PL_SDO_BLK_MAX_IN_CYCLE))
#define CO_SDO_BLK_MAX_IN_CYCLE  (CO_PL_SDO_BLK_MAX_IN_CYCLE)

/** CO_OD_IDX_VALID - check if the index is valid for RVSW */
#define CO_OD_IDX_VALID(idx) (!IS_OUTSIDE((idx),CO_OD_STATIC_DATA_FIRST_IDX,CO_OD_STATIC_DATA_LAST_IDX) || \
                              !IS_OUTSIDE((idx),CO_OD_PROFILE_AREA_FIRST_IDX,CO_OD_PROFILE_AREA_LAST_IDX))

/** CO_OD_SUB_IDX_VALID - check if the a SubIndex is valid for RVSW */
#define CO_OD_SUB_IDX_VALID(subIdx) (!IS_OUTSIDE((subIdx), CO_OD_SDO_BLK_SUBIDX, CO_OD_SDO_BLK_SIZE_MAX) )

/*---------- Types definitions ----------------------------------------*/
/**
 * @brief CoMsg: CANopen message descriptor 
 *
 * This structure defines a CANopen message:
 * - its description
 * - its data bytes
 **/
typedef struct CoMsg
{
  U16 cobId;              /**< @<brief COB ID */
  U08 rtr;                /**< @<brief rtr bit */
  U08 dataBytes;          /**< @brief data size in bytes */
  U08 data[CAN_MSG_SIZE]; /**< @brief data byte buffer */
} CoMsg;

/**
 * @brief CoState: state list of CANopen state machine 
 * 
 * The CoState is a enum type as identified in CANopen Standard.
 * The numerical value of each items are specified in SW ICD.
 *
 * @requirements
 * - SRS.DMS.CAN.FUNC.0400 [state definition]
 *
 */
typedef enum
{
  E_COSTATE_OFF = 0,     /**< @brief OFF state */
  E_COSTATE_INIT = 1,    /**< @brief Initialisation state */
  E_COSTATE_PRE_OP = 2,  /**< @brief Pre-Operational state */
  E_COSTATE_OP = 3,      /**< @brief Operational state */
  E_COSTATE_STOP = 4,    /**< @brief Stopped state */
  E_COSTATE_END		       /**< @brief limit marker */
} CoState;

/**
 * @brief CoEvt: event list for CANopen manager 
 *
 * The CoEvt is a enum type associated at any events that 
 * the Bus manager handles. The list includes CANopen NMT commands
 * and other ROVER-specific events.
 * The numerical value of each items are arbitrary
 * 
 */
typedef enum
{
  E_COEVT_10HZ = 20,	/**< @brief 10Hz RTC event */
  E_COEVT_200HZ,	/**< @brief 200Hz Timer event */
  E_COEVT_START,	/**< @brief Start (NMT) command event */
  E_COEVT_STOP,		/**< @brief Stop (NMT) command event */
  E_COEVT_ENTER_PRE_OP, /**< @brief EntryPreOp (NMT) command event */
  E_COEVT_RESET,	/**< @brief Reset (NMT) command event */
  E_COEVT_SWITCH_BUS,	/**< @brief Switch Bus (TC) command event */
  E_COEVT_TT_TIMEOUT,	/**< @brief TToggle Timeout event */
  E_COEVT_IGNORED,	/**< @brief ignored event */
  E_COEVT_END		/**< @brief limit marker */
} CoEvt;

/**
 * @brief CoStatus: status code list of CANopen management 
 * 
 * The CoStatus is an enum type used by the components of CoMgt.
 *
 */
typedef enum
{
  E_COSTATUS_OK = 0,		     /**< @brief success */
  E_COSTATUS_ERROR = 0x100,  /**< @brief general error */
  E_COSTATUS_PARAM_ERROR,	   /**< @brief Input parameter error */
  E_COSTATUS_MSG_LIST_FULL,  /**< @brief message list full */
  E_COSTATUS_CAN_IF_ERROR,	 /**< @brief Unexpected error from Can Interface */
  E_COSTATUS_EXTCAN_ERROR,   /**< @brief External CAN FCG failure */
  E_COSTATUS_ACTPM_ERROR,    /**< @brief Active PM FCG failure */
  E_COSTATUS_BUS_BUSY        /**< @brief Previous request still ongoing */
} CoStatus;

/**
 * @brief NodeStat: Node Status 
 *
 * The descriptor is used to contain working context
 * of a slave node
 *
 **/
typedef struct NodeStat
{
  U32 nodeState;         /**< @brief device state as announced by its last HB message */
  U32 lastCycle;         /**< @brief cycle of last received HB message */
  U16 bufSupPdoCobId;    /**< @brief COB_ID for buffer support message (index: 0x6001) */
  U16 bufSupPdoIdxUpl;   /**< @brief OD index to upload on reception of the buffer support PDO message */
  U16 bufSupPdoIdxDwnl;  /**< @brief OD index to download on reception of the buffer support PDO message */
  U16 bufSupPdoSubIdxUpl;   /**< @brief OD index to upload on reception of the buffer support PDO message */
  U16 bufSupPdoSubIdxDwnl;  /**< @brief OD index to download on reception of the buffer support PDO message */
  U32 retDistInSyncCyc;  /**< @brief RET distribution cycle in current SYNC period */
  U32 hbTotal;           /**< @brief total HB messages received from */
  U32 nmtTotal;          /**< @brief total NMT messages sent to */
  U32 retTotal;          /**< @brief total RET messages sent to */
  U32 pdoTcTotal;        /**< @brief total expedited SDO Upload transfer performed */
  U32 pdoTmTotal;        /**< @brief total expedited SDO Download transfer performed */
  U32 sdoExpdtUlTotal;   /**< @brief total expedited SDO Upload transfer performed */
  U32 sdoExpdtDlTotal;   /**< @brief total expedited SDO Download transfer performed */
  U32 sdoExpdtAbtCliCnt;/**< @brief Expedited SDO Aborted transfer counter by client */
  U32 sdoExpdtAbtSerCnt;/**< @brief Expedited SDO Aborted transfer counter by server */
  U32 sdoExpdtAbtCliCode;/**< @brief latest cycle Expedited SDO Aborted transfer code by client */
  U32 sdoExpdtAbtSerCode;/**< @brief latest cycle Expedited SDO Aborted transfer code by server */
  U32 sdoBlkUlTotal;     /**< @brief total Block SDO Upload transfer performed */
  U32 sdoBlkDlTotal;     /**< @brief total Block SDO Download transfer performed */
  U32 sdoBlkAbtCliCnt;  /**< @brief Block SDO aborted transfer counter by client */
  U32 sdoBlkAbtSerCnt;  /**< @brief Block SDO aborted transfer counter by server */
  U32 sdoBlkAbtCliCode;  /**< @brief latest cycle Block SDO aborted transfer code by client */
  U32 sdoBlkAbtSerCode;  /**< @brief latest cycle Block SDO aborted transfer code by server */
  U32 sdoBlkStatus;      /**< @brief last block SDO transfer status */
  Boolean uhfHail;       /**< @brief flag indicating if an Hail has been received (only valid for URT equipment) */
  U32 uhfHailCycle;      /**< @brief cycle of the last received Hail (only valid for URT equipment) */
} NodeStat;

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

#endif /* _CanOpenCommon_ */
