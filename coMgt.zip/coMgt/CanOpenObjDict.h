/* CanOpenObjDict.h - CANopen Object Dictionary definitions file */

/* Copyright (c) 2014 - AIRBUS Defence & Space */
 
/* Project : Exomars Rover Vehicle */

#ifndef _CanOpenObjDict_
#define _CanOpenObjDict_

/***********************************************************************/
/** 
 * @file
 * @brief CanOpenObjDict.h - header file for CANopen modules.
 *
 * This file contains elements of CANopen Object Dictionary
 * used by CANopen Management. They come from CANopen Standard and
 * CAN Controller IP Core Data Sheet
 *
 ***********************************************************************/

/*---------- Standard libraries includes ------------------------------*/
#include "util/basicTypes.h"

/*---------- FSW includes ---------------------------------------------*/
#include "coMgt/CanOpenStd.h"

/*---------- Defines & macro ------------------------------------------*/
/*
 *------------------------------------
 * CANopen Standard definitions
 *------------------------------------
 */

/* Can Open OD index ranges definitions */

/* Static Data Types */
#define CO_OD_STATIC_DATA_FIRST_IDX (0x0001) 
#define CO_OD_STATIC_DATA_LAST_IDX  (0x001F) 

/* Complex Data Types */
#define CO_OD_COMPLEX_DATA_FIRST_IDX (0x0020) 
#define CO_OD_COMPLEX_DATA_LAST_IDX  (0x003F) 

/* Manufacturer Complex Data Types */
#define CO_OD_MANUF_COMPLEX_DATA_FIRST_IDX (0x0040) 
#define CO_OD_MANUF_COMPLEX_DATA_LAST_IDX  (0x005F) 

/* Device Profile Static Data Types */
#define CO_OD_DEV_STATIC_DATA_FIRST_IDX (0x0060) 
#define CO_OD_DEV_STATIC_DATA_LAST_IDX  (0x007F) 

/* Device Profile Complex Data Types */
#define CO_OD_DEV_COMPLEX_DATA_FIRST_IDX (0x0080) 
#define CO_OD_DEV_COMPLEX_DATA_LAST_IDX  (0x009F) 

/* Reserved for further use */
#define CO_OD_RSVD1_FIRST_IDX (0x00A0) 
#define CO_OD_RSVD1_LAST_IDX  (0x0FFF) 

/* Communication Profile Area */
#define CO_OD_COMM_AREA_FIRST_IDX (0x1000) 
#define CO_OD_COMM_AREA_LAST_IDX  (0x1FFF) 

/* Manufacturer Specific Profile Area */
#define CO_OD_MANUF_AREA_FIRST_IDX (0x2000) 
#define CO_OD_MANUF_AREA_LAST_IDX  (0x5FFF) 

/* Standardised Device Profile Area */
#define CO_OD_STD_DEV_AREA_FIRST_IDX (0x6000) 
#define CO_OD_STD_DEV_AREA_LAST_IDX  (0x9FFF) 

/* Standardised Interface Profile Area */
#define CO_OD_STD_IF_AREA_FIRST_IDX (0xA000) 
#define CO_OD_STD_IF_AREA_LAST_IDX  (0xBFFF) 

/* Reserved for further use */
#define CO_OD_RSVD2_FIRST_IDX (0xC000) 
#define CO_OD_RSVD2_LAST_IDX  (0xFFFF) 

/* global range for profile areas */
#define CO_OD_PROFILE_AREA_FIRST_IDX CO_OD_COMM_AREA_FIRST_IDX
#define CO_OD_PROFILE_AREA_LAST_IDX CO_OD_STD_IF_AREA_LAST_IDX

/* Error register */
#define CO_OD_ERR_REG_IDX (0x1001)  /* index */

#define CO_OD_ERR_REG     (0x0)  /* sub-index: the only one */
#define CO_OD_ERR_REG_SIZE (1)   /* object type: U8 */

/*------------------------------------
 * CCIPC-specific definitions
 *------------------------------------
 */

/* CCIPC Registers */
#define CO_OD_CCIPC_REGS_IDX (0x2003)  /* index */

#define CO_OD_CCIPC_REGS_STS_CFG (0)  /* sub-index: Status and configuration */
#define CO_OD_CCIPC_REGS_STS_CFG_SZ (1)   /* object type: U8 */

#define CO_OD_CCIPC_REGS_HCAN_STS (2)  /* sub-index: Hurricane CCIPC Status */
#define CO_OD_CCIPC_REGS_HCAN_STS_SZ (4)   /* object type: U32 */

#define CO_OD_CCIPC_REGS_SDO_ERR (3)  /* sub-index: CCIPC-SDO errors */
#define CO_OD_CCIPC_REGS_SDO_ERR_SZ (4)   /* object type: U32 */

#define CO_OD_CCIPC_REGS_EDAC_ERR (0xE)  /* sub-index: EDAC error */
#define CO_OD_CCIPC_REGS_EDAC_ERR_SE (4)   /* object type: U32 */

/* Buffer Support PDO Object */
#define CO_OD_BSP_IDX (0x6001)  /* index */
#define CO_OD_BSP_DATA_LENGTH (8) /* PDO message size in byte: always 8  */

#define CO_OD_BSP_SUBX (0)  /* sub-index: Number of sub-entries */
#define CO_OD_BSP_SUBX_SZ (1)   /* object type: U8 */

#define CO_OD_BSP_BUF_STS (1)  /* sub-index: buffer status */
#define CO_OD_BSP_BUF_STS_OFFSET (0)  /* offset in message */
#define CO_OD_BSP_BUF_STS_SZ (1)   /* object type: U8 */

#define CO_OD_BSP_CONTENT (2)  /* sub-index: SDO content */
#define CO_OD_BSP_CONTENT_OFFSET (1)  /* offset in message */
#define CO_OD_BSP_CONTENT_SZ (1)   /* object type: U8 */

#define CO_OD_BSP_NBYTES (3)  /* sub-index: data size in byte */
#define CO_OD_BSP_NBYTES_OFFSET (2)  /* offset in message */
#define CO_OD_BSP_NBYTES_SZ (4)   /* object type: U32 */

#define CO_OD_BSP_STS_READY_UL (1) /* buffer status field: Ready for Uploading */
#define CO_OD_BSP_STS_READY_DL (2) /* buffer status field: Ready for Downloading */

#define CO_OD_BSP_TYPE_HK_UL (0)   /* SDO content field: HK data for Uploading */
#define CO_OD_BSP_TYPE_DUMP_UL (1) /* SDO content field: Dump data for Uploading */
#define CO_OD_BSP_TYPE_SC_UL (2) /* SDO content field: Dump data for Uploading */


/** 
 * @brief CO_OD_SDO_BLK_SUBIDX - SDO block upload / download sub index
 * @requirements
 * - SRS.DMS.CAN.FUNC.0280 [definition of sub index]
 */
#define CO_OD_SDO_BLK_SUBIDX (1) 
#define CO_OD_SDO_BLK_SIZE_MAX (888)

/* (Write) PDO TM length is always 8-byte */
#define CO_OD_PDO_LENGTH CANOPEN_PDO_DATA_LENGTH_MAX

/** 
 * @brief CO_OD_RET_DIST_RTR - RET distribution Message Format
 * @requirements
 * - SRS.DMS.CAN.FUNC.0650 [definition of Message Format]
 */
#define CO_OD_RET_DIST_RTR CANOPEN_WPDO_RTR
#define CO_OD_RET_DIST_DATA_LENGTH (6) /* Coarse Time (32-bit) + Fine Time (16-bit) */

#define CO_OD_BUF_SUP_PDO_RESV_FIELD (CO_OD_PDO_LENGTH - CO_OD_RET_DIST_DATA_LENGTH)

/*---------- Types definitions ----------------------------------------*/
/**
 * @brief CoBufSupPdo: Buffer Support PDO message definition
 * @requirements
 * - SRS.DMS.CAN.FUNC.0210 [definition of Message Format]
 *  Note: the field bufferSize contains an unsigned integer encoded in little endian
 **/
typedef struct CoBufSupPdo
{
  U08 bufferStatus;
  U08 sdoContent;
  U08 bufferSize[sizeof(U32)]; /* little endian format */
  U08 reserved[CO_OD_BUF_SUP_PDO_RESV_FIELD];
} CoBufSupPdo;

/*---------- Variables exported by the module -------------------------*/

/*---------- Functions exported by the module -------------------------*/

#endif /* _CanOpenObjDict_ */
